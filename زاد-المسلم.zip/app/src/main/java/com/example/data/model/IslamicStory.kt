package com.example.data.model

enum class StoryCategory(val title: String) {
    PROPHETS("قصص الأنبياء"),
    COMPANIONS("سير الصحابة والصالحين"),
    WISDOM("عبر ومواعظ إيمانية")
}

data class IslamicStory(
    val id: String,
    val title: String,
    val category: StoryCategory,
    val summary: String,
    val content: String,
    val moral: String,
    val readTimeMinutes: Int
)
