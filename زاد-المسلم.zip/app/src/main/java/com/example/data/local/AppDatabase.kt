package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.AthkarProgressDao
import com.example.data.local.dao.FavoriteDao
import com.example.data.local.dao.UserSettingsDao
import com.example.data.local.entity.AthkarProgress
import com.example.data.local.entity.FavoriteItem
import com.example.data.local.entity.UserSettingsEntity

@Database(
    entities = [
        FavoriteItem::class,
        AthkarProgress::class,
        UserSettingsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun favoriteDao(): FavoriteDao
    abstract fun athkarProgressDao(): AthkarProgressDao
    abstract fun userSettingsDao(): UserSettingsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "zad_almuslim_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
