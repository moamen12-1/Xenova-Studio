package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "athkar_progress")
data class AthkarProgress(
    @PrimaryKey val thikrId: String,
    val currentCount: Int,
    val targetCount: Int,
    val isCompleted: Boolean,
    val dateEpochDay: Long
)
