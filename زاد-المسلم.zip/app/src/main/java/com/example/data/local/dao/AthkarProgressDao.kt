package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.AthkarProgress
import kotlinx.coroutines.flow.Flow

@Dao
interface AthkarProgressDao {
    @Query("SELECT * FROM athkar_progress WHERE dateEpochDay = :epochDay")
    fun getProgressForDay(epochDay: Long): Flow<List<AthkarProgress>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProgress(progress: AthkarProgress)

    @Query("DELETE FROM athkar_progress WHERE dateEpochDay = :epochDay")
    suspend fun resetDayProgress(epochDay: Long)

    @Query("UPDATE athkar_progress SET currentCount = 0, isCompleted = 0 WHERE thikrId = :thikrId")
    suspend fun resetThikr(thikrId: String)
}
