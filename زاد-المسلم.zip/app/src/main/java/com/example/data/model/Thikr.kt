package com.example.data.model

enum class ThikrCategory(val displayName: String) {
    MORNING("أذكار الصباح"),
    EVENING("أذكار المساء")
}

data class Thikr(
    val id: String,
    val category: ThikrCategory,
    val text: String,
    val repetition: Int,
    val virtue: String,
    val reference: String,
    val note: String = ""
)
