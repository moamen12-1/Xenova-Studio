package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_settings")
data class UserSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val themeMode: String = "SYSTEM", // SYSTEM, LIGHT, DARK, SEPIA
    val fontSizeScale: Float = 1.0f,
    val displayMode: String = "CARDS", // CARDS, LIST
    val hapticEnabled: Boolean = true,
    val morningReminderEnabled: Boolean = true,
    val morningHour: Int = 6,
    val morningMinute: Int = 30,
    val eveningReminderEnabled: Boolean = true,
    val eveningHour: Int = 17,
    val eveningMinute: Int = 30
)
