package com.example.data.model

enum class HadithCategory(val title: String) {
    IKHLAS("الإخلاص والنية"),
    PRAYER_THIKR("فضل الذكر والدعاء"),
    CHARACTER("مكارم الأخلاق والبر"),
    FAITH_SCIENCE("التفكر والإعجاز العلمي"),
    PATIENCE("الصبر والرضا")
}

data class HadithItem(
    val id: String,
    val title: String,
    val category: HadithCategory,
    val hadithText: String,
    val narrator: String,
    val explanation: String,
    val reference: String,
    val authenticity: String = "صحيح"
)
