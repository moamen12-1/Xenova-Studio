package com.example.data.repository

import com.example.data.local.dao.AthkarProgressDao
import com.example.data.local.dao.FavoriteDao
import com.example.data.local.dao.UserSettingsDao
import com.example.data.local.entity.AthkarProgress
import com.example.data.local.entity.FavoriteItem
import com.example.data.local.entity.UserSettingsEntity
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

class UserDataRepository(
    private val favoriteDao: FavoriteDao,
    private val athkarProgressDao: AthkarProgressDao,
    private val userSettingsDao: UserSettingsDao
) {
    val allFavorites: Flow<List<FavoriteItem>> = favoriteDao.getAllFavorites()

    fun getFavoritesByType(type: String): Flow<List<FavoriteItem>> =
        favoriteDao.getFavoritesByType(type)

    fun isFavorite(targetId: String): Flow<Boolean> =
        favoriteDao.isFavorite(targetId)

    suspend fun toggleFavorite(targetId: String, itemType: String, title: String, snippet: String) {
        val favId = "${itemType.lowercase()}_$targetId"
        // Check manually or insert
        val item = FavoriteItem(
            id = favId,
            itemType = itemType,
            targetId = targetId,
            title = title,
            snippet = snippet
        )
        favoriteDao.insertFavorite(item)
    }

    suspend fun removeFavorite(targetId: String) {
        favoriteDao.deleteByTargetId(targetId)
    }

    fun getTodayEpochDay(): Long {
        return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            LocalDate.now().toEpochDay()
        } else {
            System.currentTimeMillis() / (1000 * 60 * 60 * 24)
        }
    }

    fun getTodayProgress(): Flow<List<AthkarProgress>> {
        return athkarProgressDao.getProgressForDay(getTodayEpochDay())
    }

    suspend fun incrementThikrCount(thikrId: String, currentCount: Int, targetCount: Int) {
        val newCount = currentCount + 1
        val isCompleted = newCount >= targetCount
        val progress = AthkarProgress(
            thikrId = thikrId,
            currentCount = newCount,
            targetCount = targetCount,
            isCompleted = isCompleted,
            dateEpochDay = getTodayEpochDay()
        )
        athkarProgressDao.saveProgress(progress)
    }

    suspend fun resetThikr(thikrId: String, targetCount: Int) {
        val progress = AthkarProgress(
            thikrId = thikrId,
            currentCount = 0,
            targetCount = targetCount,
            isCompleted = false,
            dateEpochDay = getTodayEpochDay()
        )
        athkarProgressDao.saveProgress(progress)
    }

    suspend fun resetAllTodayProgress() {
        athkarProgressDao.resetDayProgress(getTodayEpochDay())
    }

    val userSettings: Flow<UserSettingsEntity?> = userSettingsDao.getSettings()

    suspend fun saveSettings(settings: UserSettingsEntity) {
        userSettingsDao.saveSettings(settings)
    }
}
