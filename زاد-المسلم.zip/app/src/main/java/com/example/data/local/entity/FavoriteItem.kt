package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorites")
data class FavoriteItem(
    @PrimaryKey val id: String, // e.g. "thikr_m1", "story_1", "hadith_1"
    val itemType: String, // "THIKR", "STORY", "HADITH"
    val targetId: String,
    val title: String,
    val snippet: String,
    val createdAt: Long = System.currentTimeMillis()
)
