package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ThikrCategory
import com.example.ui.screens.MainAppScreen
import com.example.ui.screens.NavigationTab
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.ZadAlMuslimTheme
import com.example.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val openTabExtra = intent?.getStringExtra("OPEN_TAB")
        if (openTabExtra == "MORNING") {
            viewModel.selectThikrCategory(ThikrCategory.MORNING)
        } else if (openTabExtra == "EVENING") {
            viewModel.selectThikrCategory(ThikrCategory.EVENING)
        }

        setContent {
            val settings by viewModel.userSettings.collectAsStateWithLifecycle()
            val currentTheme = try {
                AppThemeMode.valueOf(settings?.themeMode ?: "SYSTEM")
            } catch (_: Exception) {
                AppThemeMode.SYSTEM
            }

            // Request Notification Permission on Android 13+ (API 33+)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { _ -> }

                LaunchedEffect(Unit) {
                    if (ContextCompat.checkSelfPermission(
                            this@MainActivity,
                            Manifest.permission.POST_NOTIFICATIONS
                        ) != PackageManager.PERMISSION_GRANTED
                    ) {
                        permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
            }

            ZadAlMuslimTheme(themeMode = currentTheme) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MainAppScreen(
                        viewModel = viewModel,
                        initialTab = NavigationTab.ATHKAR
                    )
                }
            }
        }
    }
}
