package com.example.ui.screens

import android.app.TimePickerDialog
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DividerDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.AppThemeMode
import com.example.ui.viewmodel.MainViewModel

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val settings by viewModel.userSettings.collectAsStateWithLifecycle()

    val currentTheme = try {
        AppThemeMode.valueOf(settings?.themeMode ?: "SYSTEM")
    } catch (_: Exception) {
        AppThemeMode.SYSTEM
    }

    val currentFontSize = settings?.fontSizeScale ?: 1.0f
    val isCardsMode = settings?.displayMode != "LIST"
    val hapticEnabled = settings?.hapticEnabled ?: true

    val morningEnabled = settings?.morningReminderEnabled ?: true
    val morningHour = settings?.morningHour ?: 6
    val morningMinute = settings?.morningMinute ?: 30

    val eveningEnabled = settings?.eveningReminderEnabled ?: true
    val eveningHour = settings?.eveningHour ?: 17
    val eveningMinute = settings?.eveningMinute ?: 30

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("settings_scroll_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Title
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.Settings,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = "التذكير والتخصيص",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        // Section 1: Automatic Reminders (التذكير التلقائي)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("reminders_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.NotificationsActive,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "التذكير التلقائي بالأذكار",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(Modifier.height(14.dp))

                    // Morning Reminder Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "تذكير أذكار الصباح ☀️",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp
                            )
                            val timeStr = formatTime(morningHour, morningMinute)
                            Text(
                                text = "الموعد: $timeStr (انقر للتعديل)",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier
                                    .clickable {
                                        TimePickerDialog(
                                            context,
                                            { _, h, m ->
                                                viewModel.updateMorningReminder(morningEnabled, h, m)
                                            },
                                            morningHour,
                                            morningMinute,
                                            false
                                        ).show()
                                    }
                                    .padding(vertical = 2.dp)
                            )
                        }

                        Switch(
                            checked = morningEnabled,
                            onCheckedChange = { enabled ->
                                viewModel.updateMorningReminder(enabled, morningHour, morningMinute)
                            },
                            modifier = Modifier.testTag("morning_switch")
                        )
                    }

                    Spacer(Modifier.height(12.dp))
                    HorizontalDivider(color = DividerDefaults.color.copy(alpha = 0.5f))
                    Spacer(Modifier.height(12.dp))

                    // Evening Reminder Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "تذكير أذكار المساء 🌙",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp
                            )
                            val timeStr = formatTime(eveningHour, eveningMinute)
                            Text(
                                text = "الموعد: $timeStr (انقر للتعديل)",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier
                                    .clickable {
                                        TimePickerDialog(
                                            context,
                                            { _, h, m ->
                                                viewModel.updateEveningReminder(eveningEnabled, h, m)
                                            },
                                            eveningHour,
                                            eveningMinute,
                                            false
                                        ).show()
                                    }
                                    .padding(vertical = 2.dp)
                            )
                        }

                        Switch(
                            checked = eveningEnabled,
                            onCheckedChange = { enabled ->
                                viewModel.updateEveningReminder(enabled, eveningHour, eveningMinute)
                            },
                            modifier = Modifier.testTag("evening_switch")
                        )
                    }

                    Spacer(Modifier.height(16.dp))

                    // Test Reminder Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.triggerTestNotification("MORNING") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("test_morning_notification_btn")
                        ) {
                            Text("تجربة تنبيه الصباح", fontSize = 12.sp)
                        }
                        OutlinedButton(
                            onClick = { viewModel.triggerTestNotification("EVENING") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("test_evening_notification_btn")
                        ) {
                            Text("تجربة تنبيه المساء", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Section 2: Eye-Comfort & Themes (واجهة مريحة للعين والوضع الليلي)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("theme_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Palette,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "المظهر ونمط راحة العين",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(Modifier.height(14.dp))

                    ThemeOptionItem(
                        title = "تلقائي (حسب إعدادات النظام)",
                        subtitle = "يتكيف مع الوضع الداكن أو الفاتح للهاتف",
                        selected = currentTheme == AppThemeMode.SYSTEM,
                        onClick = { viewModel.updateThemeMode(AppThemeMode.SYSTEM) }
                    )

                    ThemeOptionItem(
                        title = "الوضع النهاري المشرق ☀️",
                        subtitle = "ألوان زمردية دافئة مع خلفية ورقية هادئة",
                        selected = currentTheme == AppThemeMode.LIGHT,
                        onClick = { viewModel.updateThemeMode(AppThemeMode.LIGHT) }
                    )

                    ThemeOptionItem(
                        title = "الوضع الليلي الهادئ (Dark Mode) 🌙",
                        subtitle = "مريح جداً للعين في الظلام وموفر للطاقة",
                        selected = currentTheme == AppThemeMode.DARK,
                        onClick = { viewModel.updateThemeMode(AppThemeMode.DARK) }
                    )

                    ThemeOptionItem(
                        title = "وضع راحة العين (دافئ Sepia) 📜",
                        subtitle = "نغمات كهرمانية خافتة للقراءة الهادئة بدون إجهاد",
                        selected = currentTheme == AppThemeMode.SEPIA,
                        onClick = { viewModel.updateThemeMode(AppThemeMode.SEPIA) }
                    )
                }
            }
        }

        // Section 3: Customization (تصميم قابل للتخصيص بين الأذكار)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("customization_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.FormatSize,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "تخصيص الخط ونمط العرض",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(Modifier.height(14.dp))

                    Text(
                        text = "حجم خط الأذكار والقصص:",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )

                    Spacer(Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FontSizeChip(
                            label = "صغير",
                            scale = 0.9f,
                            isSelected = currentFontSize == 0.9f,
                            onClick = { viewModel.updateFontSize(0.9f) },
                            modifier = Modifier.weight(1f)
                        )
                        FontSizeChip(
                            label = "قياسي",
                            scale = 1.0f,
                            isSelected = currentFontSize == 1.0f,
                            onClick = { viewModel.updateFontSize(1.0f) },
                            modifier = Modifier.weight(1f)
                        )
                        FontSizeChip(
                            label = "كبير",
                            scale = 1.15f,
                            isSelected = currentFontSize == 1.15f,
                            onClick = { viewModel.updateFontSize(1.15f) },
                            modifier = Modifier.weight(1f)
                        )
                        FontSizeChip(
                            label = "كبير جداً",
                            scale = 1.35f,
                            isSelected = currentFontSize == 1.35f,
                            onClick = { viewModel.updateFontSize(1.35f) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(Modifier.height(16.dp))
                    HorizontalDivider(color = DividerDefaults.color.copy(alpha = 0.5f))
                    Spacer(Modifier.height(14.dp))

                    // Athkar Display Style
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "نمط بطاقات الأذكار التفاعلية",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = if (isCardsMode) "بطاقات واسعة مع زر تسبيح كبير" else "قائمة متتابعة سريعة",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }

                        Switch(
                            checked = isCardsMode,
                            onCheckedChange = { isCard ->
                                viewModel.updateDisplayMode(if (isCard) "CARDS" else "LIST")
                            }
                        )
                    }

                    Spacer(Modifier.height(12.dp))
                    HorizontalDivider(color = DividerDefaults.color.copy(alpha = 0.5f))
                    Spacer(Modifier.height(14.dp))

                    // Vibration / Haptic
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "الاهتزاز التفاعلي عند التسبيح 📳",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "نبضة اهتزاز خفيفة عند كل تسبيحة واهتزاز مميز عند الإتمام",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }

                        Switch(
                            checked = hapticEnabled,
                            onCheckedChange = { enabled ->
                                viewModel.updateHaptic(enabled)
                            }
                        )
                    }
                }
            }
        }

        // About Footer
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "زاد المسلم 🌿",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "تطبيق إسلامي شامل - أذكار الصباح والمساء والقصص والمكتبة العلمية",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.outline,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "صدقة جارية لكل مسلم ومسلمة",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        item {
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
fun ThemeOptionItem(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 8.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                fontSize = 14.sp
            )
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.outline
            )
        }

        RadioButton(
            selected = selected,
            onClick = onClick
        )
    }
}

@Composable
fun FontSizeChip(
    label: String,
    scale: Float,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
        contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
    ) {
        Box(
            modifier = Modifier.padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                fontSize = (13 * scale).sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}

private fun formatTime(hour: Int, minute: Int): String {
    val isPm = hour >= 12
    val displayHour = when {
        hour == 0 -> 12
        hour > 12 -> hour - 12
        else -> hour
    }
    val minuteStr = if (minute < 10) "0$minute" else "$minute"
    val period = if (isPm) "م" else "ص"
    return "$displayHour:$minuteStr $period"
}
