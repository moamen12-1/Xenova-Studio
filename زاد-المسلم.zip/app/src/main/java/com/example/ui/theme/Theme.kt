package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldDarkPrimary,
    onPrimary = EmeraldDarkOnPrimary,
    primaryContainer = EmeraldDarkPrimaryContainer,
    onPrimaryContainer = EmeraldDarkOnPrimaryContainer,
    secondary = GoldDarkSecondary,
    onSecondary = GoldDarkOnSecondary,
    secondaryContainer = GoldDarkSecondaryContainer,
    onSecondaryContainer = GoldDarkOnSecondaryContainer,
    background = NightDarkBackground,
    onBackground = NightDarkOnBackground,
    surface = NightDarkSurface,
    onSurface = NightDarkOnSurface,
    surfaceVariant = NightDarkSurfaceVariant,
    onSurfaceVariant = NightDarkOnSurfaceVariant
)

private val LightColorScheme = lightColorScheme(
    primary = EmeraldLightPrimary,
    onPrimary = EmeraldLightOnPrimary,
    primaryContainer = EmeraldLightPrimaryContainer,
    onPrimaryContainer = EmeraldLightOnPrimaryContainer,
    secondary = GoldLightSecondary,
    onSecondary = GoldLightOnSecondary,
    secondaryContainer = GoldLightSecondaryContainer,
    onSecondaryContainer = GoldLightOnSecondaryContainer,
    background = PaperLightBackground,
    onBackground = PaperLightOnBackground,
    surface = PaperLightSurface,
    onSurface = PaperLightOnSurface,
    surfaceVariant = PaperLightSurfaceVariant,
    onSurfaceVariant = PaperLightOnSurfaceVariant
)

private val SepiaColorScheme = lightColorScheme(
    primary = SepiaPrimary,
    onPrimary = PaperLightSurface,
    primaryContainer = SepiaSurfaceVariant,
    onPrimaryContainer = SepiaOnBackground,
    secondary = GoldLightSecondary,
    onSecondary = PaperLightSurface,
    secondaryContainer = SepiaSurfaceVariant,
    onSecondaryContainer = SepiaOnBackground,
    background = SepiaBackground,
    onBackground = SepiaOnBackground,
    surface = SepiaSurface,
    onSurface = SepiaOnBackground,
    surfaceVariant = SepiaSurfaceVariant,
    onSurfaceVariant = SepiaOnSurfaceVariant
)

enum class AppThemeMode {
    SYSTEM,
    LIGHT,
    DARK,
    SEPIA
}

@Composable
fun ZadAlMuslimTheme(
    themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val isDark = when (themeMode) {
        AppThemeMode.SYSTEM -> systemDark
        AppThemeMode.LIGHT -> false
        AppThemeMode.DARK -> true
        AppThemeMode.SEPIA -> false
    }

    val colorScheme: ColorScheme = when (themeMode) {
        AppThemeMode.SEPIA -> SepiaColorScheme
        AppThemeMode.DARK -> DarkColorScheme
        AppThemeMode.LIGHT -> LightColorScheme
        AppThemeMode.SYSTEM -> {
            if (dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val context = LocalContext.current
                if (systemDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
            } else {
                if (systemDark) DarkColorScheme else LightColorScheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    ZadAlMuslimTheme(
        themeMode = if (darkTheme) AppThemeMode.DARK else AppThemeMode.LIGHT,
        dynamicColor = dynamicColor,
        content = content
    )
}
