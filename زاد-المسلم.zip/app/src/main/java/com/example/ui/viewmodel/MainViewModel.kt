package com.example.ui.viewmodel

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AthkarProgress
import com.example.data.local.entity.FavoriteItem
import com.example.data.local.entity.UserSettingsEntity
import com.example.data.model.HadithCategory
import com.example.data.model.HadithItem
import com.example.data.model.IslamicStory
import com.example.data.model.Thikr
import com.example.data.model.ThikrCategory
import com.example.data.repository.IslamicContentRepository
import com.example.data.repository.UserDataRepository
import com.example.reminder.ReminderScheduler
import com.example.ui.theme.AppThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = UserDataRepository(
        favoriteDao = db.favoriteDao(),
        athkarProgressDao = db.athkarProgressDao(),
        userSettingsDao = db.userSettingsDao()
    )

    val allFavorites: StateFlow<List<FavoriteItem>> = repository.allFavorites
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val todayProgressList: StateFlow<List<AthkarProgress>> = repository.getTodayProgress()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userSettings: StateFlow<UserSettingsEntity?> = repository.userSettings
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            UserSettingsEntity()
        )

    private val _selectedThikrCategory = MutableStateFlow(ThikrCategory.MORNING)
    val selectedThikrCategory: StateFlow<ThikrCategory> = _selectedThikrCategory.asStateFlow()

    private val _selectedStory = MutableStateFlow<IslamicStory?>(null)
    val selectedStory: StateFlow<IslamicStory?> = _selectedStory.asStateFlow()

    private val _selectedHadith = MutableStateFlow<HadithItem?>(null)
    val selectedHadith: StateFlow<HadithItem?> = _selectedHadith.asStateFlow()

    private val _librarySearchQuery = MutableStateFlow("")
    val librarySearchQuery: StateFlow<String> = _librarySearchQuery.asStateFlow()

    private val _selectedHadithCategory = MutableStateFlow<HadithCategory?>(null)
    val selectedHadithCategory: StateFlow<HadithCategory?> = _selectedHadithCategory.asStateFlow()

    init {
        // Initialize default settings if not existing
        viewModelScope.launch {
            repository.saveSettings(
                UserSettingsEntity(
                    id = 1,
                    themeMode = "SYSTEM",
                    fontSizeScale = 1.0f,
                    displayMode = "CARDS",
                    hapticEnabled = true,
                    morningReminderEnabled = true,
                    morningHour = 6,
                    morningMinute = 30,
                    eveningReminderEnabled = true,
                    eveningHour = 17,
                    eveningMinute = 30
                )
            )
            // Schedule default alarms
            ReminderScheduler.scheduleReminder(application, "MORNING", 6, 30)
            ReminderScheduler.scheduleReminder(application, "EVENING", 17, 30)
        }
    }

    fun selectThikrCategory(category: ThikrCategory) {
        _selectedThikrCategory.value = category
    }

    fun selectStory(story: IslamicStory?) {
        _selectedStory.value = story
    }

    fun selectHadith(hadith: HadithItem?) {
        _selectedHadith.value = hadith
    }

    fun setLibrarySearchQuery(query: String) {
        _librarySearchQuery.value = query
    }

    fun selectHadithCategory(category: HadithCategory?) {
        _selectedHadithCategory.value = category
    }

    fun getProgressForThikr(thikrId: String, targetCount: Int): AthkarProgress {
        val list = todayProgressList.value
        return list.firstOrNull { it.thikrId == thikrId }
            ?: AthkarProgress(
                thikrId = thikrId,
                currentCount = 0,
                targetCount = targetCount,
                isCompleted = false,
                dateEpochDay = repository.getTodayEpochDay()
            )
    }

    fun incrementThikr(thikr: Thikr) {
        val currentProgress = getProgressForThikr(thikr.id, thikr.repetition)
        if (currentProgress.currentCount >= thikr.repetition) {
            // Already completed, can reset or tap again
            return
        }

        val newCount = currentProgress.currentCount + 1
        val isCompleted = newCount >= thikr.repetition

        viewModelScope.launch {
            repository.incrementThikrCount(thikr.id, currentProgress.currentCount, thikr.repetition)
        }

        // Haptic feedback
        if (userSettings.value?.hapticEnabled != false) {
            triggerVibration(isCompleted)
        }
    }

    fun resetThikr(thikr: Thikr) {
        viewModelScope.launch {
            repository.resetThikr(thikr.id, thikr.repetition)
        }
    }

    fun resetAllCategoryAthkar(category: ThikrCategory) {
        val list = if (category == ThikrCategory.MORNING) {
            IslamicContentRepository.morningAthkar
        } else {
            IslamicContentRepository.eveningAthkar
        }
        viewModelScope.launch {
            list.forEach { thikr ->
                repository.resetThikr(thikr.id, thikr.repetition)
            }
        }
    }

    private fun triggerVibration(isCompleted: Boolean) {
        val app = getApplication<Application>()
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager =
                    app.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }

            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    if (isCompleted) {
                        vibrator.vibrate(
                            VibrationEffect.createWaveform(
                                longArrayOf(0, 70, 80, 140),
                                intArrayOf(0, 200, 0, 255),
                                -1
                            )
                        )
                    } else {
                        vibrator.vibrate(
                            VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE)
                        )
                    }
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(if (isCompleted) 180L else 30L)
                }
            }
        } catch (_: Exception) {
            // Safe fallback
        }
    }

    fun toggleFavorite(targetId: String, type: String, title: String, snippet: String) {
        viewModelScope.launch {
            val isFav = allFavorites.value.any { it.targetId == targetId }
            if (isFav) {
                repository.removeFavorite(targetId)
                Toast.makeText(getApplication(), "تمت الإزالة من المفضلة", Toast.LENGTH_SHORT).show()
            } else {
                repository.toggleFavorite(targetId, type, title, snippet)
                Toast.makeText(getApplication(), "تمت الإضافة إلى المفضلة ⭐", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun isFavorite(targetId: String): Boolean {
        return allFavorites.value.any { it.targetId == targetId }
    }

    fun updateThemeMode(themeMode: AppThemeMode) {
        viewModelScope.launch {
            val current = userSettings.value ?: UserSettingsEntity()
            repository.saveSettings(current.copy(themeMode = themeMode.name))
        }
    }

    fun updateFontSize(scale: Float) {
        viewModelScope.launch {
            val current = userSettings.value ?: UserSettingsEntity()
            repository.saveSettings(current.copy(fontSizeScale = scale))
        }
    }

    fun updateDisplayMode(mode: String) {
        viewModelScope.launch {
            val current = userSettings.value ?: UserSettingsEntity()
            repository.saveSettings(current.copy(displayMode = mode))
        }
    }

    fun updateHaptic(enabled: Boolean) {
        viewModelScope.launch {
            val current = userSettings.value ?: UserSettingsEntity()
            repository.saveSettings(current.copy(hapticEnabled = enabled))
        }
    }

    fun updateMorningReminder(enabled: Boolean, hour: Int, minute: Int) {
        val app = getApplication<Application>()
        viewModelScope.launch {
            val current = userSettings.value ?: UserSettingsEntity()
            repository.saveSettings(
                current.copy(
                    morningReminderEnabled = enabled,
                    morningHour = hour,
                    morningMinute = minute
                )
            )
            if (enabled) {
                ReminderScheduler.scheduleReminder(app, "MORNING", hour, minute)
            } else {
                ReminderScheduler.cancelReminder(app, "MORNING")
            }
        }
    }

    fun updateEveningReminder(enabled: Boolean, hour: Int, minute: Int) {
        val app = getApplication<Application>()
        viewModelScope.launch {
            val current = userSettings.value ?: UserSettingsEntity()
            repository.saveSettings(
                current.copy(
                    eveningReminderEnabled = enabled,
                    eveningHour = hour,
                    eveningMinute = minute
                )
            )
            if (enabled) {
                ReminderScheduler.scheduleReminder(app, "EVENING", hour, minute)
            } else {
                ReminderScheduler.cancelReminder(app, "EVENING")
            }
        }
    }

    fun triggerTestNotification(type: String) {
        ReminderScheduler.triggerImmediateTestNotification(getApplication(), type)
    }

    fun copyText(text: String, label: String = "نص") {
        val clipboard = getApplication<Application>().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(getApplication(), "تم نسخ النص إلى الحافظة", Toast.LENGTH_SHORT).show()
    }
}
