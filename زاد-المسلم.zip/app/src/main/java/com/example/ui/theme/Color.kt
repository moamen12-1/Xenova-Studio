package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Islamic Emerald & Gold Color Palette (Eye-friendly & Serene)
val EmeraldLightPrimary = Color(0xFF0F513F)
val EmeraldLightOnPrimary = Color(0xFFFFFFFF)
val EmeraldLightPrimaryContainer = Color(0xFFD6EDE3)
val EmeraldLightOnPrimaryContainer = Color(0xFF03261D)

val GoldLightSecondary = Color(0xFFB57F26)
val GoldLightOnSecondary = Color(0xFFFFFFFF)
val GoldLightSecondaryContainer = Color(0xFFFBEFD7)
val GoldLightOnSecondaryContainer = Color(0xFF3F2904)

val PaperLightBackground = Color(0xFFFAF8F3)
val PaperLightOnBackground = Color(0xFF16231E)
val PaperLightSurface = Color(0xFFFFFFFF)
val PaperLightOnSurface = Color(0xFF16231E)
val PaperLightSurfaceVariant = Color(0xFFECF3EE)
val PaperLightOnSurfaceVariant = Color(0xFF405149)

// Dark Theme (Deep Night, Low-Strain OLED Friendly)
val EmeraldDarkPrimary = Color(0xFF5ED3A8)
val EmeraldDarkOnPrimary = Color(0xFF003829)
val EmeraldDarkPrimaryContainer = Color(0xFF114F3D)
val EmeraldDarkOnPrimaryContainer = Color(0xFFA7F3D0)

val GoldDarkSecondary = Color(0xFFF3CD7B)
val GoldDarkOnSecondary = Color(0xFF442D05)
val GoldDarkSecondaryContainer = Color(0xFF5E400A)
val GoldDarkOnSecondaryContainer = Color(0xFFFDE68A)

val NightDarkBackground = Color(0xFF0B1310)
val NightDarkOnBackground = Color(0xFFE2EBE6)
val NightDarkSurface = Color(0xFF13201B)
val NightDarkOnSurface = Color(0xFFE2EBE6)
val NightDarkSurfaceVariant = Color(0xFF1C2F27)
val NightDarkOnSurfaceVariant = Color(0xFFA4B8AE)

// Sepia Warm Mode (Eye Comfort)
val SepiaPrimary = Color(0xFF805220)
val SepiaBackground = Color(0xFFF6EEDC)
val SepiaSurface = Color(0xFFFCF7EB)
val SepiaOnBackground = Color(0xFF2C2016)
val SepiaSurfaceVariant = Color(0xFFEAE0CB)
val SepiaOnSurfaceVariant = Color(0xFF574637)
