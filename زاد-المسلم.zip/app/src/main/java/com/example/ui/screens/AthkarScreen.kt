package com.example.ui.screens

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.NightlightRound
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.FormatSize
import androidx.compose.material.icons.outlined.ViewAgenda
import androidx.compose.material.icons.outlined.ViewStream
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.Thikr
import com.example.data.model.ThikrCategory
import com.example.data.repository.IslamicContentRepository
import com.example.ui.viewmodel.MainViewModel

@Composable
fun AthkarScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val selectedCategory by viewModel.selectedThikrCategory.collectAsStateWithLifecycle()
    val todayProgress by viewModel.todayProgressList.collectAsStateWithLifecycle()
    val userSettings by viewModel.userSettings.collectAsStateWithLifecycle()
    val favorites by viewModel.allFavorites.collectAsStateWithLifecycle()

    val currentAthkarList = if (selectedCategory == ThikrCategory.MORNING) {
        IslamicContentRepository.morningAthkar
    } else {
        IslamicContentRepository.eveningAthkar
    }

    val completedCount = currentAthkarList.count { thikr ->
        val p = todayProgress.firstOrNull { it.thikrId == thikr.id }
        (p?.currentCount ?: 0) >= thikr.repetition
    }
    val progressFraction = if (currentAthkarList.isNotEmpty()) {
        completedCount.toFloat() / currentAthkarList.size
    } else 0f

    val fontSizeScale = userSettings?.fontSizeScale ?: 1.0f
    val isCompactView = userSettings?.displayMode == "LIST"

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("athkar_scroll_list"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Hero Banner
        item {
            AthkarHeaderBanner(
                category = selectedCategory,
                completedCount = completedCount,
                totalCount = currentAthkarList.size,
                progress = progressFraction
            )
        }

        // Category Selector Tabs
        item {
            TabRow(
                selectedTabIndex = if (selectedCategory == ThikrCategory.MORNING) 0 else 1,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .testTag("athkar_category_tabs")
            ) {
                Tab(
                    selected = selectedCategory == ThikrCategory.MORNING,
                    onClick = { viewModel.selectThikrCategory(ThikrCategory.MORNING) },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.WbSunny, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("أذكار الصباح", fontWeight = FontWeight.Bold)
                        }
                    },
                    modifier = Modifier.testTag("tab_morning_athkar")
                )
                Tab(
                    selected = selectedCategory == ThikrCategory.EVENING,
                    onClick = { viewModel.selectThikrCategory(ThikrCategory.EVENING) },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.NightlightRound, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("أذكار المساء", fontWeight = FontWeight.Bold)
                        }
                    },
                    modifier = Modifier.testTag("tab_evening_athkar")
                )
            }
        }

        // Toolbar: Customization Quick Actions
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = {
                            val newMode = if (isCompactView) "CARDS" else "LIST"
                            viewModel.updateDisplayMode(newMode)
                        },
                        modifier = Modifier.testTag("toggle_display_mode_btn")
                    ) {
                        Icon(
                            imageVector = if (isCompactView) Icons.Outlined.ViewAgenda else Icons.Outlined.ViewStream,
                            contentDescription = "تبديل نمط العرض",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Font Size quick switch
                    IconButton(
                        onClick = {
                            val nextScale = when {
                                fontSizeScale < 1.0f -> 1.0f
                                fontSizeScale < 1.15f -> 1.15f
                                fontSizeScale < 1.30f -> 1.35f
                                else -> 0.9f
                            }
                            viewModel.updateFontSize(nextScale)
                        },
                        modifier = Modifier.testTag("quick_font_size_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.FormatSize,
                            contentDescription = "تغيير حجم الخط",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                FilledTonalButton(
                    onClick = { viewModel.resetAllCategoryAthkar(selectedCategory) },
                    contentPadding = ButtonDefaults.ButtonWithIconContentPadding,
                    modifier = Modifier.testTag("reset_all_athkar_btn")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("إعادة ضبط", fontSize = 13.sp)
                }
            }
        }

        // Athkar Items
        items(currentAthkarList, key = { it.id }) { thikr ->
            val progress = viewModel.getProgressForThikr(thikr.id, thikr.repetition)
            val isFav = favorites.any { it.targetId == thikr.id }

            if (isCompactView) {
                CompactThikrCard(
                    thikr = thikr,
                    progress = progress.currentCount,
                    isCompleted = progress.isCompleted,
                    isFavorite = isFav,
                    fontSizeScale = fontSizeScale,
                    onIncrement = { viewModel.incrementThikr(thikr) },
                    onReset = { viewModel.resetThikr(thikr) },
                    onToggleFavorite = {
                        viewModel.toggleFavorite(thikr.id, "THIKR", thikr.text.take(30) + "...", thikr.text)
                    },
                    onCopy = { viewModel.copyText(thikr.text, "الذكر") },
                    onShare = {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, "${thikr.text}\n\n[${thikr.reference}] - تطبيق زاد المسلم")
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "مشاركة الذكر"))
                    }
                )
            } else {
                InteractiveThikrCard(
                    thikr = thikr,
                    progress = progress.currentCount,
                    isCompleted = progress.isCompleted,
                    isFavorite = isFav,
                    fontSizeScale = fontSizeScale,
                    onIncrement = { viewModel.incrementThikr(thikr) },
                    onReset = { viewModel.resetThikr(thikr) },
                    onToggleFavorite = {
                        viewModel.toggleFavorite(thikr.id, "THIKR", thikr.text.take(30) + "...", thikr.text)
                    },
                    onCopy = { viewModel.copyText(thikr.text, "الذكر") },
                    onShare = {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, "${thikr.text}\n\n[${thikr.reference}] - تطبيق زاد المسلم")
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "مشاركة الذكر"))
                    }
                )
            }
        }

        item {
            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
fun AthkarHeaderBanner(
    category: ThikrCategory,
    completedCount: Int,
    totalCount: Int,
    progress: Float
) {
    val isMorning = category == ThikrCategory.MORNING
    val bannerRes = if (isMorning) R.drawable.banner_morning_athkar else R.drawable.banner_evening_athkar

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
        ) {
            Image(
                painter = painterResource(id = bannerRes),
                contentDescription = if (isMorning) "خلفية أذكار الصباح" else "خلفية أذكار المساء",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            // Scrim overlay for clear readability
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.45f))
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isMorning) "أذكار الصباح المأثورة ☀️" else "أذكار المساء المأثورة 🌙",
                        color = Color.White,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )

                    Surface(
                        color = Color.White.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "$completedCount / $totalCount",
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }

                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (progress >= 1.0f) "أحسنت! أتممت جميع أذكار اليوم" else "«ألا بذكر الله تطمئن القلوب»",
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "${(progress * 100).toInt()}%",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = MaterialTheme.colorScheme.secondary,
                        trackColor = Color.White.copy(alpha = 0.3f)
                    )
                }
            }
        }
    }
}

@Composable
fun InteractiveThikrCard(
    thikr: Thikr,
    progress: Int,
    isCompleted: Boolean,
    isFavorite: Boolean,
    fontSizeScale: Float,
    onIncrement: () -> Unit,
    onReset: () -> Unit,
    onToggleFavorite: () -> Unit,
    onCopy: () -> Unit,
    onShare: () -> Unit
) {
    val cardColor by animateColorAsState(
        targetValue = if (isCompleted) {
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
        } else {
            MaterialTheme.colorScheme.surface
        },
        label = "card_color"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .testTag("thikr_card_${thikr.id}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = cardColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp)
        ) {
            // Header Row: repetition badge, completed indicator, favorite button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = if (isCompleted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isCompleted) {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text(
                                text = "مكتمل",
                                color = MaterialTheme.colorScheme.onPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        } else {
                            Text(
                                text = "التكرار: ${thikr.repetition} ${if (thikr.repetition == 1) "مرة" else "مرات"}",
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Row {
                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier.testTag("fav_btn_${thikr.id}")
                    ) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = if (isFavorite) "إزالة من المفضلة" else "إضافة للمفضلة",
                            tint = if (isFavorite) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outline
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // Main Thikr Text with Arabic Tashkeel
            Text(
                text = thikr.text,
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontSize = (18 * fontSizeScale).sp,
                    lineHeight = (34 * fontSizeScale).sp
                ),
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Right,
                modifier = Modifier.fillMaxWidth()
            )

            if (thikr.virtue.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "✨ الفضل: ${thikr.virtue}",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontSize = (13 * fontSizeScale).sp,
                                lineHeight = 22.sp
                            ),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "📖 [${thikr.reference}]",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.outline,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // Counter Button and quick actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Actions
                Row {
                    IconButton(onClick = onCopy) {
                        Icon(Icons.Outlined.ContentCopy, contentDescription = "نسخ الذكر", modifier = Modifier.size(20.dp))
                    }
                    IconButton(onClick = onShare) {
                        Icon(Icons.Default.Share, contentDescription = "مشاركة الذكر", modifier = Modifier.size(20.dp))
                    }
                    if (progress > 0) {
                        IconButton(onClick = onReset) {
                            Icon(Icons.Default.Refresh, contentDescription = "إعادة ضبط العداد", modifier = Modifier.size(20.dp))
                        }
                    }
                }

                // Big Tasbeeh Counter Button
                Button(
                    onClick = onIncrement,
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isCompleted) {
                            MaterialTheme.colorScheme.primaryContainer
                        } else {
                            MaterialTheme.colorScheme.primary
                        },
                        contentColor = if (isCompleted) {
                            MaterialTheme.colorScheme.onPrimaryContainer
                        } else {
                            MaterialTheme.colorScheme.onPrimary
                        }
                    ),
                    modifier = Modifier.testTag("counter_btn_${thikr.id}")
                ) {
                    Text(
                        text = if (isCompleted) {
                            "تم ✓ ($progress / ${thikr.repetition})"
                        } else {
                            "سبّح ($progress / ${thikr.repetition})"
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}

@Composable
fun CompactThikrCard(
    thikr: Thikr,
    progress: Int,
    isCompleted: Boolean,
    isFavorite: Boolean,
    fontSizeScale: Float,
    onIncrement: () -> Unit,
    onReset: () -> Unit,
    onToggleFavorite: () -> Unit,
    onCopy: () -> Unit,
    onShare: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clickable { onIncrement() }
            .testTag("thikr_compact_${thikr.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCompleted) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "التكرار: ${thikr.repetition}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.secondary,
                    fontWeight = FontWeight.Bold
                )

                Row {
                    IconButton(onClick = onToggleFavorite, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = null,
                            tint = if (isFavorite) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(onClick = onCopy, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Outlined.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            Text(
                text = thikr.text,
                fontSize = (16 * fontSizeScale).sp,
                lineHeight = (30 * fontSizeScale).sp,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Right,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = thikr.reference,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.outline
                )

                Surface(
                    color = if (isCompleted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "$progress / ${thikr.repetition}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isCompleted) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}
