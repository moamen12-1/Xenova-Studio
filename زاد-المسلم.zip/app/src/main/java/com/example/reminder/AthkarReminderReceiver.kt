package com.example.reminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R

class AthkarReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // Re-schedule daily reminders
            ReminderScheduler.rescheduleAll(context)
            return
        }

        val type = intent.getStringExtra(ReminderScheduler.EXTRA_REMINDER_TYPE) ?: "MORNING"
        showNotification(context, type)

        // Schedule next day's alarm
        val hour = intent.getIntExtra(ReminderScheduler.EXTRA_HOUR, if (type == "MORNING") 6 else 17)
        val minute = intent.getIntExtra(ReminderScheduler.EXTRA_MINUTE, 30)
        ReminderScheduler.scheduleReminder(context, type, hour, minute)
    }

    private fun showNotification(context: Context, type: String) {
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val channelId = "athkar_daily_reminders"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelName = "تذكير الأذكار اليومية"
            val channelDescription = "إشعارات تنبيهية لأذكار الصباح والمساء"
            val channel = NotificationChannel(
                channelId,
                channelName,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = channelDescription
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val isMorning = type == "MORNING"
        val title = if (isMorning) "حان موعد أذكار الصباح ☀️" else "حان موعد أذكار المساء 🌙"
        val message = if (isMorning) {
            "«ألا بذكر الله تطمئن القلوب» - ابدأ يومك بحفظ الله ونوره."
        } else {
            "حصّن ليلتك بأذكار المساء المأثورة واستودع نفسك للرحمن."
        }

        val activityIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("OPEN_TAB", if (isMorning) "MORNING" else "EVENING")
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            if (isMorning) 101 else 102,
            activityIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val notificationId = if (isMorning) 2001 else 2002
        notificationManager.notify(notificationId, notification)
    }
}
