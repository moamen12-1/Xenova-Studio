package com.example.shadowhouse.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Power
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.shadowhouse.model.InventoryItem
import com.example.shadowhouse.model.ItemType
import com.example.ui.theme.HorrorAmber
import com.example.ui.theme.HorrorBlack
import com.example.ui.theme.HorrorBrown
import com.example.ui.theme.HorrorCrimson
import com.example.ui.theme.HorrorDarkGray
import com.example.ui.theme.HorrorMist
import com.example.ui.theme.HorrorSurface
import com.example.ui.theme.HorrorSurfaceVariant
import com.example.ui.theme.HorrorWhite

@Composable
fun InventoryDialog(
    inventory: List<InventoryItem>,
    onUseItem: (ItemType) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedItem by remember { mutableStateOf(inventory.firstOrNull()?.type) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .height(380.dp)
                .testTag("inventory_dialog"),
            colors = CardDefaults.cardColors(containerColor = HorrorSurface),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, HorrorDarkGray)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "INVENTORY",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = HorrorWhite,
                        letterSpacing = 3.sp,
                        fontFamily = FontFamily.Serif
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = "Close", tint = HorrorMist)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxSize()) {
                    // Left Grid of Items
                    Box(
                        modifier = Modifier
                            .weight(1.2f)
                            .fillMaxSize()
                            .background(HorrorSurfaceVariant, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        if (inventory.isEmpty()) {
                            Text(
                                text = "Pockets are empty.\nExplore to find items.",
                                color = HorrorMist,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.align(Alignment.Center)
                            )
                        } else {
                            LazyVerticalGrid(
                                columns = GridCells.Fixed(3),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(inventory) { item ->
                                    val isSelected = item.type == selectedItem
                                    Box(
                                        modifier = Modifier
                                            .size(68.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(
                                                if (isSelected) HorrorBrown else HorrorDarkGray
                                            )
                                            .border(
                                                width = if (isSelected) 2.dp else 1.dp,
                                                color = if (isSelected) HorrorAmber else Color.Transparent,
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .clickable { selectedItem = item.type }
                                            .padding(6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(
                                                imageVector = getItemIcon(item.type),
                                                contentDescription = item.type.displayName,
                                                tint = if (isSelected) HorrorAmber else HorrorWhite,
                                                modifier = Modifier.size(28.dp)
                                            )
                                            if (item.quantity > 1) {
                                                Text(
                                                    text = "x${item.quantity}",
                                                    fontSize = 10.sp,
                                                    color = HorrorMist
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    // Right Item Description Panel
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        val current = selectedItem?.let { type -> inventory.find { it.type == type } }
                        if (current != null) {
                            Column {
                                Text(
                                    text = current.type.displayName,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = HorrorAmber
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = current.type.description,
                                    fontSize = 12.sp,
                                    color = HorrorWhite,
                                    lineHeight = 18.sp
                                )
                            }

                            if (current.type.isUsable) {
                                Button(
                                    onClick = {
                                        onUseItem(current.type)
                                        onDismiss()
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = HorrorAmber,
                                        contentColor = HorrorBlack
                                    )
                                ) {
                                    Text(
                                        text = if (current.type == ItemType.BATTERY) "USE BATTERY" else "USE ITEM",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        } else {
                            Text(
                                text = "Select an item to inspect details.",
                                fontSize = 12.sp,
                                color = HorrorMist,
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SafeKeypadDialog(
    onCodeSubmitted: (String) -> Boolean,
    onDismiss: () -> Unit
) {
    var code by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .width(340.dp)
                .testTag("safe_keypad_dialog"),
            colors = CardDefaults.cardColors(containerColor = HorrorSurface),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, HorrorDarkGray)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "STORAGE SAFE LOCK",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = HorrorWhite,
                        letterSpacing = 2.sp
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = "Close", tint = HorrorMist)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Display Screen
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .background(HorrorBlack, RoundedCornerShape(6.dp))
                        .border(1.dp, HorrorDarkGray, RoundedCornerShape(6.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (code.isEmpty()) "----" else code.padEnd(4, '-'),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = HorrorAmber,
                        letterSpacing = 8.sp
                    )
                }

                if (errorMsg.isNotEmpty()) {
                    Text(
                        text = errorMsg,
                        color = HorrorCrimson,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Numeric Keypad Grid
                val buttons = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "C", "0", "OK")
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (row in 0..3) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (col in 0..2) {
                                val label = buttons[row * 3 + col]
                                Button(
                                    onClick = {
                                        when (label) {
                                            "C" -> {
                                                code = ""
                                                errorMsg = ""
                                            }
                                            "OK" -> {
                                                if (code.length == 4) {
                                                    val success = onCodeSubmitted(code)
                                                    if (success) {
                                                        onDismiss()
                                                    } else {
                                                        errorMsg = "INVALID COMBINATION"
                                                        code = ""
                                                    }
                                                } else {
                                                    errorMsg = "ENTER 4 DIGITS"
                                                }
                                            }
                                            else -> {
                                                if (code.length < 4) {
                                                    code += label
                                                    errorMsg = ""
                                                }
                                            }
                                        }
                                    },
                                    modifier = Modifier.size(56.dp, 44.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (label == "OK") HorrorAmber else HorrorSurfaceVariant,
                                        contentColor = if (label == "OK") HorrorBlack else HorrorWhite
                                    ),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(text = label, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BreakerPanelDialog(
    isFuseInstalled: Boolean,
    onInstallFuse: () -> Boolean,
    onSwitchToggled: (Int) -> Pair<Boolean, String>,
    onDismiss: () -> Unit
) {
    var statusText by remember { mutableStateOf(if (isFuseInstalled) "Auxiliary Circuit Ready. Enter switch sequence." else "Fuse slot A is empty! Ceramic fuse required.") }
    var fuseState by remember { mutableStateOf(isFuseInstalled) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .width(360.dp)
                .testTag("breaker_panel_dialog"),
            colors = CardDefaults.cardColors(containerColor = HorrorSurface),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, HorrorDarkGray)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "BREAKER PANEL",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = HorrorWhite,
                        letterSpacing = 2.sp
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = "Close", tint = HorrorMist)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Ceramic Fuse Socket status
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(HorrorBlack, RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "FUSE SOCKET A", fontSize = 12.sp, color = HorrorMist)
                            Text(
                                text = if (fuseState) "CERAMIC FUSE INSTALLED" else "NO FUSE DETECTED",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (fuseState) HorrorAmber else HorrorCrimson
                            )
                        }

                        if (!fuseState) {
                            Button(
                                onClick = {
                                    val ok = onInstallFuse()
                                    if (ok) {
                                        fuseState = true
                                        statusText = "Ceramic Fuse installed! Auxiliary sequence unlocked."
                                    } else {
                                        statusText = "You don't have a Ceramic Fuse! Search the Storage Room."
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = HorrorAmber, contentColor = HorrorBlack)
                            ) {
                                Text(text = "INSERT", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // 4 Switch Toggle Buttons
                Text(text = "CIRCUIT SWITCHES", fontSize = 12.sp, color = HorrorMist, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    for (i in 1..4) {
                        Button(
                            onClick = {
                                val (solved, msg) = onSwitchToggled(i)
                                statusText = msg
                                if (solved) {
                                    // Power solved!
                                }
                            },
                            modifier = Modifier.size(60.dp, 50.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = HorrorBrown,
                                contentColor = HorrorWhite
                            ),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(text = "$i", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = statusText,
                    fontSize = 12.sp,
                    color = HorrorAmber,
                    textAlign = TextAlign.Center,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
fun NoteReaderDialog(
    title: String,
    content: String,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .width(360.dp)
                .testTag("note_reader_dialog"),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF26201A)),
            shape = RoundedCornerShape(8.dp),
            border = androidx.compose.foundation.BorderStroke(2.dp, HorrorBrown)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title.uppercase(),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = HorrorAmber,
                        letterSpacing = 1.5.sp
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = "Close", tint = HorrorMist)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(HorrorBrown)
                )

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = content,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Serif,
                    color = Color(0xFFE8DFD0),
                    lineHeight = 22.sp
                )

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.End),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = HorrorBrown,
                        contentColor = HorrorWhite
                    )
                ) {
                    Text(text = "CLOSE", fontSize = 12.sp)
                }
            }
        }
    }
}

private fun getItemIcon(type: ItemType): ImageVector {
    return when (type) {
        ItemType.FLASHLIGHT -> Icons.Filled.FlashlightOn
        ItemType.BATTERY -> Icons.Filled.BatteryChargingFull
        ItemType.BRASS_KEY, ItemType.BASEMENT_KEY, ItemType.MAIN_EXIT_KEY -> Icons.Filled.Key
        ItemType.FUSE -> Icons.Filled.Power
        else -> Icons.Filled.MenuBook
    }
}
