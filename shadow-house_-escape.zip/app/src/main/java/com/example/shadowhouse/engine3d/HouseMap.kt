package com.example.shadowhouse.engine3d

import com.example.shadowhouse.model.ItemType
import kotlin.math.abs
import kotlin.math.sqrt

enum class ObjectType {
    DOOR,
    ITEM_PICKUP,
    NOTE,
    SAFE,
    BREAKER_SWITCH,
    BREAKER_FUSE_SLOT,
    WARDROBE,
    EXIT_GATE,
    SECRET_BOOK
}

data class InteractiveObject(
    val id: String,
    val name: String,
    val type: ObjectType,
    val posX: Float,
    val posY: Float,
    val posZ: Float,
    var isOpen: Boolean = false,
    var isLocked: Boolean = false,
    var isCollected: Boolean = false,
    var requiredKey: ItemType? = null,
    var noteContent: String = "",
    var switchIndex: Int = 0,
    val prompt: String = ""
)

data class Wall(
    val x1: Float, val z1: Float,
    val x2: Float, val z2: Float,
    val yBottom: Float = 0f,
    val yTop: Float = 3.2f,
    val texture: TextureGenerator.TextureType = TextureGenerator.TextureType.WALL
)

data class FloorCeiling(
    val minX: Float, val maxX: Float,
    val minZ: Float, val maxZ: Float,
    val y: Float,
    val isCeiling: Boolean = false,
    val texture: TextureGenerator.TextureType = TextureGenerator.TextureType.WOOD_FLOOR
)

data class RoomDef(
    val name: String,
    val minX: Float, val maxX: Float,
    val minZ: Float, val maxZ: Float,
    val minY: Float = -0.5f, val maxY: Float = 3.5f
)

class HouseMap {

    val rooms = listOf(
        RoomDef("Entrance Foyer", -4.5f, 4.5f, -2f, 6.5f),
        RoomDef("Grand Hallway", -2.2f, 2.2f, -18.5f, -1.8f),
        RoomDef("Living Room", 2.0f, 10.5f, -10.5f, -1.8f),
        RoomDef("Kitchen", -10.5f, -2.0f, -10.5f, -1.8f),
        RoomDef("Bathroom", -8.5f, -2.0f, -18.5f, -11.0f),
        RoomDef("Master Bedroom", 2.0f, 10.5f, -18.5f, -11.0f),
        RoomDef("Storage Room", -7.0f, 0.0f, -26.0f, -18.5f),
        RoomDef("Basement Cellar", 0.0f, 7.5f, -26.0f, -18.5f, minY = -4.5f, maxY = 0.5f),
        RoomDef("Secret Occult Study", 10.5f, 16.5f, -8.5f, -2.0f)
    )

    val walls = mutableListOf<Wall>()
    val floorCeilings = mutableListOf<FloorCeiling>()
    val interactiveObjects = mutableListOf<InteractiveObject>()

    init {
        buildArchitecture()
        setupInteractiveObjects()
    }

    private fun buildArchitecture() {
        walls.clear()
        floorCeilings.clear()

        // 1. Entrance Foyer (-4.5 to 4.5, -2 to 6)
        floorCeilings.add(FloorCeiling(-4.5f, 4.5f, -2f, 6.5f, 0f, false, TextureGenerator.TextureType.WOOD_FLOOR))
        floorCeilings.add(FloorCeiling(-4.5f, 4.5f, -2f, 6.5f, 3.2f, true, TextureGenerator.TextureType.WALL))
        // South wall (with Main Exit gate)
        walls.add(Wall(-4.5f, 6.2f, -1.5f, 6.2f))
        walls.add(Wall(1.5f, 6.2f, 4.5f, 6.2f))
        // East & West walls
        walls.add(Wall(4.5f, -2f, 4.5f, 6.2f))
        walls.add(Wall(-4.5f, -2f, -4.5f, 6.2f))
        // North wall separating foyer from hallway
        walls.add(Wall(-4.5f, -2f, -1.5f, -2f))
        walls.add(Wall(1.5f, -2f, 4.5f, -2f))

        // 2. Grand Hallway (-2.2 to 2.2, -18.5 to -2)
        floorCeilings.add(FloorCeiling(-2.2f, 2.2f, -18.5f, -2f, 0f, false, TextureGenerator.TextureType.WOOD_FLOOR))
        floorCeilings.add(FloorCeiling(-2.2f, 2.2f, -18.5f, -2f, 3.2f, true, TextureGenerator.TextureType.WALL))

        // 3. Living Room (2 to 10.5, -10.5 to -2)
        floorCeilings.add(FloorCeiling(2f, 10.5f, -10.5f, -2f, 0f, false, TextureGenerator.TextureType.WOOD_FLOOR))
        floorCeilings.add(FloorCeiling(2f, 10.5f, -10.5f, -2f, 3.2f, true, TextureGenerator.TextureType.WALL))
        // South, East, North walls
        walls.add(Wall(2f, -2f, 10.5f, -2f))
        walls.add(Wall(10.5f, -2f, 10.5f, -4.5f)) // East wall part 1
        // Secret bookshelf passage between -4.5 and -6.5 on East wall
        walls.add(Wall(10.5f, -6.5f, 10.5f, -10.5f)) // East wall part 2
        walls.add(Wall(2f, -10.5f, 10.5f, -10.5f)) // North wall
        // West wall separating Living Room from Hallway
        walls.add(Wall(2f, -2f, 2f, -4.5f))
        walls.add(Wall(2f, -6.5f, 2f, -10.5f))

        // 4. Kitchen (-10.5 to -2, -10.5 to -2)
        floorCeilings.add(FloorCeiling(-10.5f, -2f, -10.5f, -2f, 0f, false, TextureGenerator.TextureType.WOOD_FLOOR))
        floorCeilings.add(FloorCeiling(-10.5f, -2f, -10.5f, -2f, 3.2f, true, TextureGenerator.TextureType.WALL))
        walls.add(Wall(-10.5f, -2f, -2f, -2f)) // South wall
        walls.add(Wall(-10.5f, -2f, -10.5f, -10.5f)) // West wall
        walls.add(Wall(-10.5f, -10.5f, -2f, -10.5f)) // North wall
        // East wall separating Kitchen from Hallway
        walls.add(Wall(-2f, -2f, -2f, -4.5f))
        walls.add(Wall(-2f, -6.5f, -2f, -10.5f))

        // 5. Bathroom (-8.5 to -2, -18.5 to -11)
        floorCeilings.add(FloorCeiling(-8.5f, -2f, -18.5f, -11f, 0f, false, TextureGenerator.TextureType.BASEMENT_BRICK))
        floorCeilings.add(FloorCeiling(-8.5f, -2f, -18.5f, -11f, 3.2f, true, TextureGenerator.TextureType.WALL))
        walls.add(Wall(-8.5f, -11f, -2f, -11f))
        walls.add(Wall(-8.5f, -11f, -8.5f, -18.5f))
        walls.add(Wall(-8.5f, -18.5f, -2f, -18.5f))
        walls.add(Wall(-2f, -11f, -2f, -13.5f))
        walls.add(Wall(-2f, -15.5f, -2f, -18.5f))

        // 6. Master Bedroom (2 to 10.5, -18.5 to -11)
        floorCeilings.add(FloorCeiling(2f, 10.5f, -18.5f, -11f, 0f, false, TextureGenerator.TextureType.WOOD_FLOOR))
        floorCeilings.add(FloorCeiling(2f, 10.5f, -18.5f, -11f, 3.2f, true, TextureGenerator.TextureType.WALL))
        walls.add(Wall(2f, -11f, 10.5f, -11f))
        walls.add(Wall(10.5f, -11f, 10.5f, -18.5f))
        walls.add(Wall(2f, -18.5f, 10.5f, -18.5f))
        walls.add(Wall(2f, -11f, 2f, -13.5f))
        walls.add(Wall(2f, -15.5f, 2f, -18.5f))

        // 7. North Hallway Partition & Storage / Basement (-7 to 7.5, -26 to -18.5)
        walls.add(Wall(-2.2f, -18.5f, -1.2f, -18.5f))
        walls.add(Wall(1.2f, -18.5f, 2.2f, -18.5f))

        // Storage Room (-7 to 0, -26 to -18.5)
        floorCeilings.add(FloorCeiling(-7f, 0f, -26f, -18.5f, 0f, false, TextureGenerator.TextureType.WOOD_FLOOR))
        floorCeilings.add(FloorCeiling(-7f, 0f, -26f, -18.5f, 3.2f, true, TextureGenerator.TextureType.WALL))
        walls.add(Wall(-7f, -18.5f, -1.5f, -18.5f))
        walls.add(Wall(-7f, -18.5f, -7f, -26f))
        walls.add(Wall(-7f, -26f, 0f, -26f))
        walls.add(Wall(0f, -26f, 0f, -18.5f)) // Wall between storage and basement

        // 8. Basement Cellar (0 to 7.5, -26 to -18.5, Y = -2.5)
        floorCeilings.add(FloorCeiling(0f, 7.5f, -26f, -18.5f, -2.5f, false, TextureGenerator.TextureType.BASEMENT_BRICK))
        floorCeilings.add(FloorCeiling(0f, 7.5f, -26f, -18.5f, 3.2f, true, TextureGenerator.TextureType.BASEMENT_BRICK))
        walls.add(Wall(1.5f, -18.5f, 7.5f, -18.5f, yBottom = -2.5f, yTop = 3.2f, texture = TextureGenerator.TextureType.BASEMENT_BRICK))
        walls.add(Wall(7.5f, -18.5f, 7.5f, -26f, yBottom = -2.5f, yTop = 3.2f, texture = TextureGenerator.TextureType.BASEMENT_BRICK))
        walls.add(Wall(0f, -26f, 7.5f, -26f, yBottom = -2.5f, yTop = 3.2f, texture = TextureGenerator.TextureType.BASEMENT_BRICK))

        // 9. Secret Occult Study (10.5 to 16.5, -8.5 to -2)
        floorCeilings.add(FloorCeiling(10.5f, 16.5f, -8.5f, -2f, 0f, false, TextureGenerator.TextureType.BASEMENT_BRICK))
        floorCeilings.add(FloorCeiling(10.5f, 16.5f, -8.5f, -2f, 3.2f, true, TextureGenerator.TextureType.WALL))
        walls.add(Wall(10.5f, -2f, 16.5f, -2f))
        walls.add(Wall(16.5f, -2f, 16.5f, -8.5f))
        walls.add(Wall(10.5f, -8.5f, 16.5f, -8.5f))
    }

    private fun setupInteractiveObjects() {
        interactiveObjects.clear()

        // --- Entrance Foyer ---
        // Heavy Flashlight on entrance table
        interactiveObjects.add(
            InteractiveObject(
                id = "item_flashlight",
                name = "Heavy Flashlight",
                type = ObjectType.ITEM_PICKUP,
                posX = 0f, posY = 0.8f, posZ = 1.0f,
                prompt = "Take Flashlight"
            )
        )

        // Main Exit Gate
        interactiveObjects.add(
            InteractiveObject(
                id = "exit_gate",
                name = "Main Front Gate",
                type = ObjectType.EXIT_GATE,
                posX = 0f, posY = 1.2f, posZ = 6.0f,
                isLocked = true,
                requiredKey = ItemType.MAIN_EXIT_KEY,
                prompt = "Unlock Front Gate"
            )
        )

        // --- Living Room ---
        // Living Room Door
        interactiveObjects.add(
            InteractiveObject(
                id = "door_living_room",
                name = "Living Room Door",
                type = ObjectType.DOOR,
                posX = 2.0f, posY = 1.2f, posZ = -5.5f,
                isOpen = true,
                prompt = "Living Room Door"
            )
        )

        // Bookshelf Secret Switch Book
        interactiveObjects.add(
            InteractiveObject(
                id = "secret_bookshelf_switch",
                name = "Tilted Leather Book",
                type = ObjectType.SECRET_BOOK,
                posX = 10.4f, posY = 1.5f, posZ = -5.5f,
                prompt = "Examine Tilted Book"
            )
        )

        // --- Kitchen ---
        // Kitchen Door
        interactiveObjects.add(
            InteractiveObject(
                id = "door_kitchen",
                name = "Kitchen Door",
                type = ObjectType.DOOR,
                posX = -2.0f, posY = 1.2f, posZ = -5.5f,
                isOpen = true,
                prompt = "Kitchen Door"
            )
        )

        // Kitchen Journal Scrap (Code clue 1)
        interactiveObjects.add(
            InteractiveObject(
                id = "note_kitchen_clue",
                name = "Kitchen Note",
                type = ObjectType.NOTE,
                posX = -6.0f, posY = 0.9f, posZ = -6.0f,
                noteContent = "Bloodstained Journal Scrap:\n'If the shadow returns, the safe holds the cellar key. The first two digits of the combination are the year we laid the foundation: 18...'",
                prompt = "Read Kitchen Note"
            )
        )

        // Spare Battery in Kitchen
        interactiveObjects.add(
            InteractiveObject(
                id = "item_battery_kitchen",
                name = "Spare Battery",
                type = ObjectType.ITEM_PICKUP,
                posX = -8.0f, posY = 0.9f, posZ = -4.0f,
                prompt = "Pick up Battery"
            )
        )

        // --- Bathroom ---
        // Bathroom Door
        interactiveObjects.add(
            InteractiveObject(
                id = "door_bathroom",
                name = "Bathroom Door",
                type = ObjectType.DOOR,
                posX = -2.0f, posY = 1.2f, posZ = -14.5f,
                isOpen = false,
                prompt = "Open Bathroom Door"
            )
        )

        // Brass Key inside Bathroom Mirror Cabinet (Puzzle 1)
        interactiveObjects.add(
            InteractiveObject(
                id = "item_brass_key",
                name = "Brass Skeleton Key",
                type = ObjectType.ITEM_PICKUP,
                posX = -5.5f, posY = 1.1f, posZ = -15.0f,
                prompt = "Take Brass Key"
            )
        )

        // --- Master Bedroom ---
        // Master Bedroom Door (Locked - Requires Brass Key)
        interactiveObjects.add(
            InteractiveObject(
                id = "door_bedroom",
                name = "Master Bedroom Door",
                type = ObjectType.DOOR,
                posX = 2.0f, posY = 1.2f, posZ = -14.5f,
                isOpen = false,
                isLocked = true,
                requiredKey = ItemType.BRASS_KEY,
                prompt = "Unlock Bedroom Door"
            )
        )

        // Bedroom Note (Code clue 2)
        interactiveObjects.add(
            InteractiveObject(
                id = "note_bedroom_clue",
                name = "Torn Diary Page",
                type = ObjectType.NOTE,
                posX = 6.5f, posY = 0.8f, posZ = -16.0f,
                noteContent = "Torn Diary Page:\n'...the house was completed in 1894. The safe code is that very year: 1 8 9 4. May God forgive what we summoned beneath.'",
                prompt = "Read Bedroom Note"
            )
        )

        // Wardrobe hiding spot (Stealth system!)
        interactiveObjects.add(
            InteractiveObject(
                id = "wardrobe_bedroom",
                name = "Old Oak Wardrobe",
                type = ObjectType.WARDROBE,
                posX = 8.8f, posY = 1.2f, posZ = -13.0f,
                prompt = "Hide Inside Wardrobe"
            )
        )

        // --- Storage Room ---
        // Storage Room Door
        interactiveObjects.add(
            InteractiveObject(
                id = "door_storage",
                name = "Storage Door",
                type = ObjectType.DOOR,
                posX = -0.5f, posY = 1.2f, posZ = -18.5f,
                isOpen = false,
                prompt = "Open Storage Door"
            )
        )

        // Storage Safe (Puzzle 2: 4-digit code 1894)
        interactiveObjects.add(
            InteractiveObject(
                id = "storage_safe",
                name = "Heavy Iron Safe",
                type = ObjectType.SAFE,
                posX = -4.5f, posY = 0.9f, posZ = -22.5f,
                isLocked = true,
                prompt = "Examine Safe Keypad"
            )
        )

        // Spare Fuse on storage shelf
        interactiveObjects.add(
            InteractiveObject(
                id = "item_fuse",
                name = "Ceramic Fuse",
                type = ObjectType.ITEM_PICKUP,
                posX = -2.5f, posY = 1.0f, posZ = -24.5f,
                prompt = "Take Ceramic Fuse"
            )
        )

        // Another battery in storage
        interactiveObjects.add(
            InteractiveObject(
                id = "item_battery_storage",
                name = "Spare Battery",
                type = ObjectType.ITEM_PICKUP,
                posX = -5.8f, posY = 0.9f, posZ = -20.0f,
                prompt = "Pick up Battery"
            )
        )

        // --- Basement Cellar ---
        // Heavy Basement Door (Locked - Requires Basement Key)
        interactiveObjects.add(
            InteractiveObject(
                id = "door_basement",
                name = "Basement Cellar Door",
                type = ObjectType.DOOR,
                posX = 0.5f, posY = 1.2f, posZ = -18.5f,
                isOpen = false,
                isLocked = true,
                requiredKey = ItemType.BASEMENT_KEY,
                prompt = "Unlock Basement Door"
            )
        )

        // Circuit Breaker Fuse Socket & Switches (Puzzle 3)
        interactiveObjects.add(
            InteractiveObject(
                id = "breaker_panel",
                name = "Circuit Breaker Panel",
                type = ObjectType.BREAKER_SWITCH,
                posX = 5.5f, posY = -1.2f, posZ = -24.5f,
                prompt = "Examine Breaker Panel"
            )
        )

        // Maintenance note in basement
        interactiveObjects.add(
            InteractiveObject(
                id = "note_basement_clue",
                name = "Maintenance Clipboard",
                type = ObjectType.NOTE,
                posX = 3.5f, posY = -1.3f, posZ = -21.0f,
                noteContent = "Maintenance Warning:\n'Auxiliary generator sequence: Switch 3, then 1, then 4, then 2. Requires intact ceramic fuse in slot A before toggling.'",
                prompt = "Read Maintenance Log"
            )
        )

        // --- Secret Occult Study ---
        // Hidden Bookshelf Door
        interactiveObjects.add(
            InteractiveObject(
                id = "secret_passage_door",
                name = "Hidden Study Passage",
                type = ObjectType.DOOR,
                posX = 10.5f, posY = 1.2f, posZ = -5.5f,
                isOpen = false,
                isLocked = true,
                prompt = "Stone Wall Locked"
            )
        )

        // Master Exit Key on the occult desk (Final objective)
        interactiveObjects.add(
            InteractiveObject(
                id = "item_main_exit_key",
                name = "Master Manor Key",
                type = ObjectType.ITEM_PICKUP,
                posX = 13.5f, posY = 0.9f, posZ = -5.2f,
                prompt = "Take Master Manor Key"
            )
        )

        // Dr. Blackwood's Confession Diary (Unlocks Ending B)
        interactiveObjects.add(
            InteractiveObject(
                id = "note_occult_confession",
                name = "Dr. Blackwood's Confession",
                type = ObjectType.NOTE,
                posX = 14.5f, posY = 0.9f, posZ = -3.5f,
                noteContent = "FINAL CONFESSION:\n'September 1894. The ritual went horribly wrong. The shadow entity pacing these floors is not a demon—it is my poor son, William. When the thunder crashes, his mind clears for brief moments. I hid the master key here, unable to leave him alone. If someone finds this, forgive us... and run before the lightning fades.'",
                prompt = "Read Dr. Blackwood's Confession"
            )
        )
    }

    /**
     * Finds the closest interactive object along the player's view vector within maxDistance.
     */
    fun getInteractableObjectAt(
        playerPos: Vector3,
        lookDir: Vector3,
        maxDistance: Float = 2.4f
    ): InteractiveObject? {
        var closestObj: InteractiveObject? = null
        var closestDistSq = maxDistance * maxDistance

        for (obj in interactiveObjects) {
            if (obj.isCollected) continue
            val objPos = Vector3(obj.posX, obj.posY, obj.posZ)
            val toObj = objPos.sub(playerPos)
            val distSq = toObj.lengthSquared()

            if (distSq <= closestDistSq) {
                val dot = lookDir.dot(toObj.normalize())
                // Must be generally facing the object (within ~45 degree cone)
                if (dot > 0.7f) {
                    closestDistSq = distSq
                    closestObj = obj
                }
            }
        }
        return closestObj
    }

    /**
     * Checks if moving to newX, newZ causes a collision with walls, closed doors, or furniture.
     */
    fun isPositionBlocked(x: Float, z: Float, radius: Float = 0.4f): Boolean {
        // Wall collision
        for (wall in walls) {
            val dist = pointToSegmentDistance(x, z, wall.x1, wall.z1, wall.x2, wall.z2)
            if (dist < radius) return true
        }

        // Closed doors collision
        for (obj in interactiveObjects) {
            if (obj.type == ObjectType.DOOR && !obj.isOpen) {
                val dist = sqrt((x - obj.posX) * (x - obj.posX) + (z - obj.posZ) * (z - obj.posZ))
                if (dist < 0.9f) return true
            }
            if (obj.type == ObjectType.EXIT_GATE && !obj.isOpen) {
                val dist = sqrt((x - obj.posX) * (x - obj.posX) + (z - obj.posZ) * (z - obj.posZ))
                if (dist < 1.0f) return true
            }
        }

        return false
    }

    fun getRoomNameAt(x: Float, y: Float, z: Float): String {
        for (room in rooms) {
            if (x in room.minX..room.maxX && z in room.minZ..room.maxZ && y in room.minY..room.maxY) {
                return room.name
            }
        }
        return "Unknown Corridors"
    }

    private fun pointToSegmentDistance(px: Float, pz: Float, x1: Float, z1: Float, x2: Float, z2: Float): Float {
        val dx = x2 - x1
        val dz = z2 - z1
        val l2 = dx * dx + dz * dz
        if (l2 < 0.0001f) {
            return sqrt((px - x1) * (px - x1) + (pz - z1) * (pz - z1))
        }
        var t = ((px - x1) * dx + (pz - z1) * dz) / l2
        t = t.coerceIn(0f, 1f)
        val projX = x1 + t * dx
        val projZ = z1 + t * dz
        return sqrt((px - projX) * (px - projX) + (pz - projZ) * (pz - projZ))
    }
}
