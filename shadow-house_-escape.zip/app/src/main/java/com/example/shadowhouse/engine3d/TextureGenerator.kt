package com.example.shadowhouse.engine3d

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.opengl.GLES20
import android.opengl.GLUtils
import java.util.Random

object TextureGenerator {

    enum class TextureType {
        WALL,
        WOOD_FLOOR,
        BASEMENT_BRICK,
        DOOR,
        METAL_SAFE,
        PAINTING,
        WINDOW,
        CREATURE
    }

    private val textureMap = mutableMapOf<TextureType, Int>()

    fun initTextures(): Map<TextureType, Int> {
        textureMap.clear()
        for (type in TextureType.values()) {
            val bitmap = createBitmapForType(type)
            val textureId = uploadBitmapToGl(bitmap)
            bitmap.recycle()
            textureMap[type] = textureId
        }
        return textureMap
    }

    private fun createBitmapForType(type: TextureType): Bitmap {
        val size = 128
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val random = Random(42L + type.ordinal)

        when (type) {
            TextureType.WALL -> {
                // Decaying Victorian peeling wallpaper: dark slate olive
                canvas.drawColor(Color.rgb(38, 44, 40))
                paint.color = Color.rgb(30, 36, 32)
                paint.strokeWidth = 3f
                // Vertical damask stripes
                for (x in 0 until size step 16) {
                    canvas.drawLine(x.toFloat(), 0f, x.toFloat(), size.toFloat(), paint)
                }
                // Mildew and grime patches
                paint.color = Color.argb(90, 18, 22, 18)
                for (i in 0..20) {
                    val rx = random.nextFloat() * size
                    val ry = random.nextFloat() * size
                    val rad = 10f + random.nextFloat() * 25f
                    canvas.drawCircle(rx, ry, rad, paint)
                }
            }
            TextureType.WOOD_FLOOR -> {
                // Dark distressed wooden floorboards
                canvas.drawColor(Color.rgb(42, 32, 24))
                paint.strokeWidth = 2f
                paint.color = Color.rgb(20, 15, 10)
                // Planks
                for (y in 0 until size step 16) {
                    canvas.drawLine(0f, y.toFloat(), size.toFloat(), y.toFloat(), paint)
                    // Grain lines
                    for (i in 0..3) {
                        paint.color = Color.argb(60, 15, 10, 5)
                        val gy = y + random.nextFloat() * 14
                        canvas.drawLine(0f, gy, size.toFloat(), gy, paint)
                    }
                }
                // Nail holes
                paint.color = Color.rgb(12, 8, 5)
                for (y in 8 until size step 16) {
                    for (x in 12 until size step 32) {
                        canvas.drawCircle(x.toFloat(), y.toFloat(), 2f, paint)
                    }
                }
            }
            TextureType.BASEMENT_BRICK -> {
                // Damp cellar stone bricks
                canvas.drawColor(Color.rgb(32, 34, 38))
                paint.color = Color.rgb(18, 20, 22)
                paint.strokeWidth = 2.5f
                for (y in 0 until size step 16) {
                    canvas.drawLine(0f, y.toFloat(), size.toFloat(), y.toFloat(), paint)
                    val offset = if ((y / 16) % 2 == 0) 0 else 16
                    for (x in offset until size step 32) {
                        canvas.drawLine(x.toFloat(), y.toFloat(), x.toFloat(), (y + 16).toFloat(), paint)
                    }
                }
                // Water moss stains
                paint.color = Color.argb(70, 25, 45, 25)
                canvas.drawCircle(30f, 90f, 25f, paint)
                canvas.drawCircle(100f, 30f, 20f, paint)
            }
            TextureType.DOOR -> {
                // Wooden panel door with dark trim
                canvas.drawColor(Color.rgb(48, 36, 28))
                paint.color = Color.rgb(28, 20, 15)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 4f
                // Border frame
                canvas.drawRect(4f, 4f, size - 4f, size - 4f, paint)
                // Upper panel
                canvas.drawRect(12f, 12f, size - 12f, 54f, paint)
                // Lower panel
                canvas.drawRect(12f, 66f, size - 12f, size - 12f, paint)
                // Brass knob
                paint.style = Paint.Style.FILL
                paint.color = Color.rgb(180, 140, 45)
                canvas.drawCircle(size - 20f, 60f, 5f, paint)
            }
            TextureType.METAL_SAFE -> {
                // Rusty dark iron safe / breaker panel
                canvas.drawColor(Color.rgb(35, 38, 42))
                paint.color = Color.rgb(20, 22, 25)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 3f
                canvas.drawRect(6f, 6f, size - 6f, size - 6f, paint)
                // Dial / keylock circle
                paint.style = Paint.Style.FILL
                paint.color = Color.rgb(60, 65, 70)
                canvas.drawCircle(size / 2f, size / 2f, 20f, paint)
                paint.color = Color.rgb(180, 50, 40)
                canvas.drawCircle(size / 2f, size / 2f, 4f, paint)
            }
            TextureType.PAINTING -> {
                // Creepy antique oil portrait
                canvas.drawColor(Color.rgb(22, 20, 18))
                paint.color = Color.rgb(140, 100, 30) // Gilded frame
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 6f
                canvas.drawRect(6f, 6f, size - 6f, size - 6f, paint)
                // Dark silhouette inside
                paint.style = Paint.Style.FILL
                paint.color = Color.rgb(12, 10, 10)
                canvas.drawCircle(size / 2f, 45f, 18f, paint)
                canvas.drawOval(size / 2f - 24f, 65f, size / 2f + 24f, 115f, paint)
                // Faint glowing eyes in portrait
                paint.color = Color.rgb(255, 180, 50)
                canvas.drawCircle(size / 2f - 6f, 43f, 1.5f, paint)
                canvas.drawCircle(size / 2f + 6f, 43f, 1.5f, paint)
            }
            TextureType.WINDOW -> {
                // Night storm rain window
                canvas.drawColor(Color.rgb(10, 16, 28))
                paint.color = Color.rgb(30, 40, 55)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 5f
                canvas.drawRect(4f, 4f, size - 4f, size - 4f, paint)
                canvas.drawLine(size / 2f, 4f, size / 2f, size - 4f, paint)
                canvas.drawLine(4f, size / 2f, size - 4f, size / 2f, paint)
                // Rain streaks
                paint.color = Color.argb(120, 140, 180, 220)
                paint.strokeWidth = 1.5f
                for (i in 0..15) {
                    val rx = random.nextFloat() * (size - 10) + 5
                    val ry = random.nextFloat() * (size - 25) + 5
                    canvas.drawLine(rx, ry, rx + 2f, ry + 16f, paint)
                }
            }
            TextureType.CREATURE -> {
                // Shadow entity: wispy dark smoke with glowing amber eyes
                canvas.drawColor(Color.TRANSPARENT)
                paint.style = Paint.Style.FILL
                paint.color = Color.argb(235, 5, 5, 8)
                // Slender eerie silhouette
                canvas.drawOval(size / 2f - 18f, 15f, size / 2f + 18f, 50f, paint) // head
                canvas.drawOval(size / 2f - 26f, 45f, size / 2f + 26f, 120f, paint) // torso
                // Piercing glowing eyes
                paint.color = Color.rgb(255, 170, 30)
                canvas.drawCircle(size / 2f - 7f, 32f, 3f, paint)
                canvas.drawCircle(size / 2f + 7f, 32f, 3f, paint)
                paint.color = Color.rgb(255, 240, 200)
                canvas.drawCircle(size / 2f - 7f, 32f, 1f, paint)
                canvas.drawCircle(size / 2f + 7f, 32f, 1f, paint)
            }
        }

        return bitmap
    }

    private fun uploadBitmapToGl(bitmap: Bitmap): Int {
        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        val textureId = textures[0]

        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_REPEAT)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_REPEAT)

        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0)

        return textureId
    }

    fun releaseTextures() {
        for (id in textureMap.values) {
            GLES20.glDeleteTextures(1, intArrayOf(id), 0)
        }
        textureMap.clear()
    }
}
