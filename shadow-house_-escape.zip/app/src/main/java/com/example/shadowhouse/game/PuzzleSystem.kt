package com.example.shadowhouse.game

import com.example.shadowhouse.audio.AudioManager
import com.example.shadowhouse.engine3d.HouseMap
import com.example.shadowhouse.engine3d.InteractiveObject
import com.example.shadowhouse.engine3d.ObjectType
import com.example.shadowhouse.model.EndingType
import com.example.shadowhouse.model.GameProgress
import com.example.shadowhouse.model.InventoryItem
import com.example.shadowhouse.model.ItemType
import com.example.shadowhouse.model.PlayerData

class PuzzleSystem(
    val houseMap: HouseMap,
    val gameProgress: GameProgress,
    val playerData: PlayerData,
    val audioManager: AudioManager,
    val onCheckpointReached: (String) -> Unit
) {
    // Current switch sequence entered for the breaker puzzle
    val currentBreakerSequence = mutableListOf<Int>()
    private val correctBreakerSequence = listOf(3, 1, 4, 2)

    /**
     * Attempts to unlock or interact with an object.
     * Returns true if an action succeeded.
     */
    fun interactWith(obj: InteractiveObject): String {
        when (obj.type) {
            ObjectType.ITEM_PICKUP -> {
                return handleItemPickup(obj)
            }
            ObjectType.DOOR -> {
                return handleDoor(obj)
            }
            ObjectType.EXIT_GATE -> {
                return handleExitGate(obj)
            }
            ObjectType.WARDROBE -> {
                playerData.isHiding = !playerData.isHiding
                audioManager.playDoorOpen()
                return if (playerData.isHiding) {
                    "You concealed yourself inside the wardrobe. The creature cannot see you."
                } else {
                    "You stepped out of the wardrobe."
                }
            }
            ObjectType.SECRET_BOOK -> {
                return handleSecretBook(obj)
            }
            else -> return ""
        }
    }

    private fun handleItemPickup(obj: InteractiveObject): String {
        val itemType = when (obj.id) {
            "item_flashlight" -> ItemType.FLASHLIGHT
            "item_battery_kitchen", "item_battery_storage" -> ItemType.BATTERY
            "item_brass_key" -> {
                gameProgress.bathroomKeyPickedUp = true
                ItemType.BRASS_KEY
            }
            "item_fuse" -> {
                gameProgress.fusePickedUp = true
                ItemType.FUSE
            }
            "item_main_exit_key" -> ItemType.MAIN_EXIT_KEY
            else -> ItemType.BATTERY
        }

        obj.isCollected = true
        addItemToInventory(itemType)
        audioManager.playItemPickup()

        if (itemType == ItemType.FLASHLIGHT) {
            playerData.flashlightOn = true
            gameProgress.currentObjective = "Find clues in the house. Search the rooms for keys and notes."
            onCheckpointReached("Flashlight Acquired")
            return "Found Heavy Flashlight! Turned on automatically."
        }
        if (itemType == ItemType.BRASS_KEY) {
            gameProgress.currentObjective = "Use Brass Key to unlock the Master Bedroom."
            onCheckpointReached("Found Brass Key")
            return "Acquired Brass Skeleton Key. It bears an ornate bedroom crest."
        }
        if (itemType == ItemType.FUSE) {
            gameProgress.currentObjective = "Take the Ceramic Fuse to the Basement Breaker."
            return "Acquired Ceramic Fuse. Useful for restoring electrical systems."
        }
        if (itemType == ItemType.MAIN_EXIT_KEY) {
            gameProgress.currentObjective = "Escape through the Main Front Gate!"
            onCheckpointReached("Master Key Acquired")
            return "Acquired Master Manor Key! Rush to the front entrance gate to escape!"
        }

        return "Collected ${itemType.displayName}."
    }

    private fun handleDoor(obj: InteractiveObject): String {
        if (obj.isLocked) {
            val key = obj.requiredKey
            if (key != null && hasItem(key)) {
                obj.isLocked = false
                obj.isOpen = true
                audioManager.playDoorOpen()

                if (obj.id == "door_bedroom") {
                    gameProgress.bedroomDoorUnlocked = true
                    onCheckpointReached("Bedroom Unlocked")
                    return "Unlocked Master Bedroom Door with Brass Key!"
                }
                if (obj.id == "door_basement") {
                    gameProgress.basementDoorUnlocked = true
                    gameProgress.currentObjective = "Basement unlocked. Find the breaker panel and restore power."
                    onCheckpointReached("Basement Reached")
                    return "Unlocked Basement Cellar Door with Rusted Iron Key!"
                }
                return "Door unlocked!"
            } else {
                audioManager.playDoorLocked()
                val keyName = key?.displayName ?: "a key"
                return "Locked tight. Requires $keyName."
            }
        } else {
            obj.isOpen = !obj.isOpen
            audioManager.playDoorOpen()
            return if (obj.isOpen) "Door opened." else "Door closed."
        }
    }

    private fun handleSecretBook(obj: InteractiveObject): String {
        if (!gameProgress.breakerSolved) {
            audioManager.playDoorLocked()
            return "A heavy leather-bound book titled 'Shadows of the Mind'. It is firmly locked in place by an electromagnetic latch."
        }

        // Power is restored, pulling book opens secret passage
        gameProgress.secretPassageOpened = true
        val secretDoor = houseMap.interactiveObjects.find { it.id == "secret_passage_door" }
        secretDoor?.isOpen = true
        secretDoor?.isLocked = false
        audioManager.playDoorOpen()
        gameProgress.currentObjective = "The bookshelf swung open! Enter the hidden occult study."
        onCheckpointReached("Secret Passage Discovered")
        return "The book tilted forward with a heavy click! The giant bookshelf slides open to reveal a hidden room!"
    }

    private fun handleExitGate(obj: InteractiveObject): String {
        if (hasItem(ItemType.MAIN_EXIT_KEY)) {
            obj.isOpen = true
            obj.isLocked = false
            audioManager.playDoorOpen()

            // Trigger ending based on whether player found the hidden confession diary!
            if (gameProgress.occultConfessionRead) {
                gameProgress.activeEnding = EndingType.ENDING_B_HIDDEN_TRUTH
            } else {
                gameProgress.activeEnding = EndingType.ENDING_A_ESCAPE
            }
            return "You unlocked the front gate and rushed out into the stormy night!"
        } else {
            audioManager.playDoorLocked()
            return "The heavy iron gate is locked. You need the Master Manor Key to escape."
        }
    }

    /**
     * Safe combination verification (Code: 1894).
     */
    fun attemptSafeCode(enteredCode: String): Boolean {
        if (enteredCode == "1894") {
            val safe = houseMap.interactiveObjects.find { it.id == "storage_safe" }
            safe?.isLocked = false
            safe?.isOpen = true
            gameProgress.storageSafeUnlocked = true

            // Add Basement Key to inventory
            addItemToInventory(ItemType.BASEMENT_KEY)
            audioManager.playItemPickup()
            gameProgress.currentObjective = "Safe opened! Take the Rusted Iron Key to unlock the Basement Cellar."
            onCheckpointReached("Safe Crushed")
            return true
        } else {
            audioManager.playDoorLocked()
            return false
        }
    }

    /**
     * Toggles a breaker switch (index 1 to 4). Sequence needed: 3, 1, 4, 2.
     */
    fun toggleBreakerSwitch(switchIndex: Int): Pair<Boolean, String> {
        if (!gameProgress.fuseInstalled) {
            audioManager.playDoorLocked()
            return Pair(false, "The circuit breaker is dead. You need to insert an intact Ceramic Fuse first.")
        }

        audioManager.playSwitchClick()
        currentBreakerSequence.add(switchIndex)

        // Check if matching current prefix
        for (i in currentBreakerSequence.indices) {
            if (currentBreakerSequence[i] != correctBreakerSequence[i]) {
                // Wrong sequence reset
                currentBreakerSequence.clear()
                audioManager.playDoorLocked()
                return Pair(false, "A loud spark hissed! Sequence failed. Resetting breaker switches...")
            }
        }

        if (currentBreakerSequence.size == correctBreakerSequence.size) {
            gameProgress.breakerSolved = true
            audioManager.playItemPickup()
            gameProgress.currentObjective = "Power restored! The magnetic lock in the Living Room library has unlocked."
            onCheckpointReached("Power Restored")
            return Pair(true, "POWER RESTORED! Heavy electromagnetic locks throughout the manor disengaged with a deep thrum!")
        }

        return Pair(false, "Switch $switchIndex engaged. (${currentBreakerSequence.size}/${correctBreakerSequence.size})")
    }

    fun installFuse(): Boolean {
        if (hasItem(ItemType.FUSE)) {
            gameProgress.fuseInstalled = true
            removeItemFromInventory(ItemType.FUSE)
            audioManager.playSwitchClick()
            return true
        }
        return false
    }

    fun hasItem(type: ItemType): Boolean {
        return gameProgress.inventory.any { it.type == type && it.quantity > 0 }
    }

    private fun addItemToInventory(type: ItemType) {
        val existing = gameProgress.inventory.find { it.type == type }
        if (existing != null) {
            val idx = gameProgress.inventory.indexOf(existing)
            gameProgress.inventory[idx] = existing.copy(quantity = existing.quantity + 1)
        } else {
            gameProgress.inventory.add(InventoryItem(type, 1))
        }
    }

    fun removeItemItem(type: ItemType): Boolean {
        return removeItemFromInventory(type)
    }

    private fun removeItemFromInventory(type: ItemType): Boolean {
        val existing = gameProgress.inventory.find { it.type == type } ?: return false
        if (existing.quantity > 1) {
            val idx = gameProgress.inventory.indexOf(existing)
            gameProgress.inventory[idx] = existing.copy(quantity = existing.quantity - 1)
        } else {
            gameProgress.inventory.remove(existing)
        }
        return true
    }
}
