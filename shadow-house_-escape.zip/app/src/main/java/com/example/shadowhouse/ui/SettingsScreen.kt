package com.example.shadowhouse.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.shadowhouse.model.GameSettings
import com.example.shadowhouse.model.GraphicsQuality
import com.example.ui.theme.HorrorAmber
import com.example.ui.theme.HorrorBlack
import com.example.ui.theme.HorrorCrimson
import com.example.ui.theme.HorrorDarkGray
import com.example.ui.theme.HorrorMist
import com.example.ui.theme.HorrorSurface
import com.example.ui.theme.HorrorWhite

@Composable
fun SettingsScreen(
    currentSettings: GameSettings,
    onSaveSettings: (GameSettings) -> Unit,
    onResetProgress: () -> Unit,
    onBack: () -> Unit
) {
    var masterVol by remember { mutableFloatStateOf(currentSettings.masterVolume) }
    var sfxVol by remember { mutableFloatStateOf(currentSettings.sfxVolume) }
    var ambientVol by remember { mutableFloatStateOf(currentSettings.ambientVolume) }
    var sensitivity by remember { mutableFloatStateOf(currentSettings.sensitivity) }
    var quality by remember { mutableStateOf(currentSettings.graphicsQuality) }
    var vibration by remember { mutableStateOf(currentSettings.vibrationEnabled) }
    var subtitles by remember { mutableStateOf(currentSettings.subtitlesEnabled) }
    var invertY by remember { mutableStateOf(currentSettings.invertY) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(HorrorBlack)
            .padding(horizontal = 32.dp, vertical = 20.dp)
            .testTag("settings_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp)
                .align(Alignment.Center)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(onClick = {
                    onSaveSettings(
                        GameSettings(
                            masterVolume = masterVol,
                            sfxVolume = sfxVol,
                            ambientVolume = ambientVol,
                            sensitivity = sensitivity,
                            graphicsQuality = quality,
                            vibrationEnabled = vibration,
                            subtitlesEnabled = subtitles,
                            invertY = invertY
                        )
                    )
                    onBack()
                }) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = HorrorAmber)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "SETTINGS",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = HorrorWhite,
                    letterSpacing = 4.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Audio Card
            Card(
                colors = CardDefaults.cardColors(containerColor = HorrorSurface),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "AUDIO CONFIGURATION", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = HorrorAmber)
                    Spacer(modifier = Modifier.height(10.dp))

                    Text(text = "Master Volume: ${(masterVol * 100).toInt()}%", fontSize = 12.sp, color = HorrorMist)
                    Slider(
                        value = masterVol,
                        onValueChange = { masterVol = it },
                        colors = SliderDefaults.colors(thumbColor = HorrorAmber, activeTrackColor = HorrorAmber)
                    )

                    Text(text = "Sound Effects (SFX): ${(sfxVol * 100).toInt()}%", fontSize = 12.sp, color = HorrorMist)
                    Slider(
                        value = sfxVol,
                        onValueChange = { sfxVol = it },
                        colors = SliderDefaults.colors(thumbColor = HorrorAmber, activeTrackColor = HorrorAmber)
                    )

                    Text(text = "Ambient Storm & Wind: ${(ambientVol * 100).toInt()}%", fontSize = 12.sp, color = HorrorMist)
                    Slider(
                        value = ambientVol,
                        onValueChange = { ambientVol = it },
                        colors = SliderDefaults.colors(thumbColor = HorrorAmber, activeTrackColor = HorrorAmber)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Gameplay & Controls Card
            Card(
                colors = CardDefaults.cardColors(containerColor = HorrorSurface),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "CONTROLS & GAMEPLAY", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = HorrorAmber)
                    Spacer(modifier = Modifier.height(10.dp))

                    Text(text = "Touch Look Sensitivity: ${(sensitivity * 100).toInt()}%", fontSize = 12.sp, color = HorrorMist)
                    Slider(
                        value = sensitivity,
                        onValueChange = { sensitivity = it },
                        valueRange = 0.4f..2.5f,
                        colors = SliderDefaults.colors(thumbColor = HorrorAmber, activeTrackColor = HorrorAmber)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Invert Look Y-Axis", fontSize = 13.sp, color = HorrorWhite)
                        Switch(
                            checked = invertY,
                            onCheckedChange = { invertY = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = HorrorAmber)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Haptic Heartbeat Vibration", fontSize = 13.sp, color = HorrorWhite)
                        Switch(
                            checked = vibration,
                            onCheckedChange = { vibration = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = HorrorAmber)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Narrative Subtitles", fontSize = 13.sp, color = HorrorWhite)
                        Switch(
                            checked = subtitles,
                            onCheckedChange = { subtitles = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = HorrorAmber)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Graphics Card
            Card(
                colors = CardDefaults.cardColors(containerColor = HorrorSurface),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "GRAPHICS QUALITY", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = HorrorAmber)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GraphicsQuality.values().forEach { q ->
                            FilterChip(
                                selected = quality == q,
                                onClick = { quality = q },
                                label = { Text(q.displayName) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = HorrorAmber,
                                    selectedLabelColor = HorrorBlack
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Reset Save & Done Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                OutlinedButton(
                    onClick = onResetProgress,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = HorrorCrimson)
                ) {
                    Text("RESET SAVED GAME")
                }

                Button(
                    onClick = {
                        onSaveSettings(
                            GameSettings(
                                masterVolume = masterVol,
                                sfxVolume = sfxVol,
                                ambientVolume = ambientVol,
                                sensitivity = sensitivity,
                                graphicsQuality = quality,
                                vibrationEnabled = vibration,
                                subtitlesEnabled = subtitles,
                                invertY = invertY
                            )
                        )
                        onBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HorrorAmber, contentColor = HorrorBlack)
                ) {
                    Text("APPLY & BACK", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
