package com.example.shadowhouse.game

import com.example.shadowhouse.audio.AudioManager
import com.example.shadowhouse.engine3d.HouseMap
import com.example.shadowhouse.engine3d.Vector3
import com.example.shadowhouse.model.CreatureBehaviorState
import com.example.shadowhouse.model.CreatureData
import com.example.shadowhouse.model.EndingType
import com.example.shadowhouse.model.GameProgress
import com.example.shadowhouse.model.PlayerData
import java.util.Random
import kotlin.math.sqrt

class CreatureAI(
    val creatureData: CreatureData,
    val playerData: PlayerData,
    val gameProgress: GameProgress,
    val houseMap: HouseMap,
    val audioManager: AudioManager
) {
    private val random = Random()
    private var heartbeatTimer = 0f
    private var stateTimer = 0f

    // Waypoints for the creature to stalk
    private val waypoints = listOf(
        Vector3(0f, 0f, -6f),    // Hallway Center
        Vector3(0f, 0f, -14f),   // Deep Hallway
        Vector3(6f, 0f, -6f),    // Living Room
        Vector3(-6f, 0f, -6f),   // Kitchen
        Vector3(-5f, 0f, -14f),  // Outside Bathroom
        Vector3(4f, -2.5f, -22f),// Basement Cellar
        Vector3(-3f, 0f, -22f)   // Storage Room
    )
    private var currentWaypointIndex = 0

    fun update(deltaSeconds: Float) {
        val distToPlayer = calculateDistanceToPlayer()
        creatureData.distanceToPlayer = distToPlayer

        // Heartbeat pulse frequency scales as creature gets closer (suspense builder)
        if (creatureData.isVisible && distToPlayer < 12f) {
            heartbeatTimer += deltaSeconds
            val heartInterval = (distToPlayer / 12f * 1.2f).coerceIn(0.45f, 1.4f)
            if (heartbeatTimer >= heartInterval) {
                heartbeatTimer = 0f
                audioManager.playHeartbeat()
            }
        }

        // State Machine
        when (creatureData.state) {
            CreatureBehaviorState.PATROL -> {
                updatePatrol(deltaSeconds, distToPlayer)
            }
            CreatureBehaviorState.INVESTIGATE -> {
                updateInvestigate(deltaSeconds, distToPlayer)
            }
            CreatureBehaviorState.STALK -> {
                updateStalk(deltaSeconds, distToPlayer)
            }
            CreatureBehaviorState.CHASE -> {
                updateChase(deltaSeconds, distToPlayer)
            }
            CreatureBehaviorState.VANISHED -> {
                updateVanished(deltaSeconds)
            }
        }
    }

    private fun updatePatrol(deltaSeconds: Float, distToPlayer: Float) {
        creatureData.isVisible = true
        val target = waypoints[currentWaypointIndex]
        moveTowards(target.x, target.z, speed = 1.3f, deltaSeconds)

        val distToWaypoint = distanceTo(creatureData.posX, creatureData.posZ, target.x, target.z)
        if (distToWaypoint < 1.0f) {
            currentWaypointIndex = (currentWaypointIndex + 1) % waypoints.size
            // Chance to slip into shadows for suspense
            if (random.nextFloat() < 0.25f) {
                creatureData.state = CreatureBehaviorState.VANISHED
                stateTimer = 10f + random.nextFloat() * 15f
                creatureData.isVisible = false
            }
        }

        // Check noise reaction (hearing player)
        if (playerData.currentNoiseLevel > 0.4f && distToPlayer < 14f) {
            creatureData.targetX = playerData.posX
            creatureData.targetZ = playerData.posZ
            creatureData.state = CreatureBehaviorState.INVESTIGATE
            stateTimer = 8f
            audioManager.playCreatureAlert()
        }

        // Check visual sight of player
        if (canSeePlayer(distToPlayer)) {
            triggerChase()
        }
    }

    private fun updateInvestigate(deltaSeconds: Float, distToPlayer: Float) {
        creatureData.isVisible = true
        moveTowards(creatureData.targetX, creatureData.targetZ, speed = 2.0f, deltaSeconds)
        stateTimer -= deltaSeconds

        if (canSeePlayer(distToPlayer)) {
            triggerChase()
            return
        }

        val distToTarget = distanceTo(creatureData.posX, creatureData.posZ, creatureData.targetX, creatureData.targetZ)
        if (distToTarget < 1.2f || stateTimer <= 0f) {
            // Nothing found, resume patrol
            creatureData.state = CreatureBehaviorState.PATROL
        }
    }

    private fun updateStalk(deltaSeconds: Float, distToPlayer: Float) {
        creatureData.isVisible = true
        moveTowards(playerData.posX, playerData.posZ, speed = 1.6f, deltaSeconds)

        if (canSeePlayer(distToPlayer)) {
            triggerChase()
        } else if (distToPlayer > 18f) {
            creatureData.state = CreatureBehaviorState.PATROL
        }
    }

    private fun updateChase(deltaSeconds: Float, distToPlayer: Float) {
        creatureData.isVisible = true
        creatureData.chaseTimer -= deltaSeconds

        // If player successfully hid in wardrobe, the creature loses them!
        if (playerData.isHiding) {
            creatureData.state = CreatureBehaviorState.VANISHED
            creatureData.isVisible = false
            stateTimer = 12f
            return
        }

        // Chase speed
        moveTowards(playerData.posX, playerData.posZ, speed = 3.6f, deltaSeconds)

        // Caught condition!
        if (distToPlayer < 1.3f) {
            audioManager.playCreatureScreech()
            gameProgress.activeEnding = EndingType.ENDING_C_CAUGHT
            return
        }

        // Chase expires -> vanishes into fog for suspense
        if (creatureData.chaseTimer <= 0f || distToPlayer > 22f) {
            creatureData.state = CreatureBehaviorState.VANISHED
            creatureData.isVisible = false
            stateTimer = 15f + random.nextFloat() * 10f
        }
    }

    private fun updateVanished(deltaSeconds: Float) {
        creatureData.isVisible = false
        stateTimer -= deltaSeconds

        // Reaction to loud noise even while vanished
        if (playerData.currentNoiseLevel > 0.8f) {
            stateTimer -= deltaSeconds * 3f
        }

        if (stateTimer <= 0f) {
            // Re-appear near a distant room
            val randomWp = waypoints[random.nextInt(waypoints.size)]
            creatureData.posX = randomWp.x
            creatureData.posZ = randomWp.z
            creatureData.state = CreatureBehaviorState.PATROL
            creatureData.isVisible = true
        }
    }

    private fun triggerChase() {
        if (playerData.isHiding) return
        creatureData.state = CreatureBehaviorState.CHASE
        creatureData.chaseTimer = 9.0f // 9 second sprint
        audioManager.playCreatureScreech()
    }

    private fun canSeePlayer(dist: Float): Boolean {
        if (playerData.isHiding) return false
        if (dist > 16f) return false

        // Flashlight makes player much more visible
        val detectionThreshold = if (playerData.flashlightOn) 14f else if (playerData.isCrouching) 3.5f else 7f
        return dist < detectionThreshold
    }

    private fun moveTowards(tx: Float, tz: Float, speed: Float, dt: Float) {
        val dx = tx - creatureData.posX
        val dz = tz - creatureData.posZ
        val len = sqrt(dx * dx + dz * dz)
        if (len > 0.1f) {
            val step = speed * dt
            creatureData.posX += (dx / len) * step
            creatureData.posZ += (dz / len) * step
        }
    }

    private fun calculateDistanceToPlayer(): Float {
        val dx = creatureData.posX - playerData.posX
        val dz = creatureData.posZ - playerData.posZ
        return sqrt(dx * dx + dz * dz)
    }

    private fun distanceTo(x1: Float, z1: Float, x2: Float, z2: Float): Float {
        val dx = x1 - x2
        val dz = z1 - z2
        return sqrt(dx * dx + dz * dz)
    }
}
