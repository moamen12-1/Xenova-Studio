package com.example.shadowhouse.ui

import android.annotation.SuppressLint
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AirlineSeatLegroomReduced
import androidx.compose.material.icons.filled.Backpack
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.shadowhouse.engine3d.ObjectType
import com.example.shadowhouse.game.GameManager
import com.example.shadowhouse.model.CreatureBehaviorState
import com.example.ui.theme.HorrorAmber
import com.example.ui.theme.HorrorBlack
import com.example.ui.theme.HorrorBloodRed
import com.example.ui.theme.HorrorBrown
import com.example.ui.theme.HorrorCrimson
import com.example.ui.theme.HorrorDarkGray
import com.example.ui.theme.HorrorMist
import com.example.ui.theme.HorrorMutedGreen
import com.example.ui.theme.HorrorSurface
import com.example.ui.theme.HorrorSurfaceVariant
import com.example.ui.theme.HorrorWhite
import kotlin.math.roundToInt
import kotlin.math.sqrt

@SuppressLint("ClickableViewAccessibility")
@Composable
fun GameScreen(
    gameManager: GameManager,
    onOpenSettings: () -> Unit,
    onReturnToMenu: () -> Unit
) {
    val context = LocalContext.current
    var isTutorialOpen by remember { mutableStateOf(gameManager.gameProgress.secondsSurvived < 3) }

    // Virtual Joystick local state
    var joystickThumbOffset by remember { mutableStateOf(Offset.Zero) }
    val joystickRadius = 60f

    // Proximity red vignette calculation based on creature distance
    val creatureDist = gameManager.creatureData.distanceToPlayer
    val creatureActive = gameManager.creatureData.isVisible && gameManager.creatureData.state != CreatureBehaviorState.VANISHED
    val redVignetteAlpha = if (creatureActive && creatureDist < 12f) {
        ((12f - creatureDist) / 12f * 0.7f).coerceIn(0f, 0.7f)
    } else 0f

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(HorrorBlack)
            .testTag("game_screen_container")
    ) {
        // 1. OpenGL 3D Surface View
        AndroidView(
            factory = { ctx ->
                GLSurfaceView(ctx).apply {
                    setEGLContextClientVersion(2)
                    setRenderer(gameManager.renderer)
                    renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // 2. Creature Proximity Red Vignette Overlay
        if (redVignetteAlpha > 0.05f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(redVignetteAlpha)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color(0x668B1E2B),
                                Color(0xEE8B1E2B)
                            ),
                            radius = 1100f
                        )
                    )
            )
        }

        // 3. Right-Half Screen Camera Look Touch Area
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(0.6f)
                .align(Alignment.CenterEnd)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        gameManager.playerController.rotateCamera(
                            deltaYaw = dragAmount.x * 0.4f,
                            deltaPitch = -dragAmount.y * 0.4f
                        )
                    }
                }
        )

        // 4. Center Reticle & Interaction Hint
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .size(160.dp),
            contentAlignment = Alignment.Center
        ) {
            val target = gameManager.currentInteractionTarget
            if (target != null) {
                // Expanded interaction bracket
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .border(1.5.dp, HorrorAmber, CircleShape)
                )
                // Floating Action Text
                Text(
                    text = target.prompt.ifEmpty { target.name },
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = HorrorAmber,
                    modifier = Modifier
                        .offset(y = 30.dp)
                        .background(Color(0xCC080B10), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                )
            } else {
                // Subtle central white dot
                Box(
                    modifier = Modifier
                        .size(4.dp)
                        .background(Color(0x99FFFFFF), CircleShape)
                )
            }
        }

        // 5. Top Status Bar (Room name, Flashlight Battery, Objective, Pause)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Room badge
            Box(
                modifier = Modifier
                    .background(Color(0xBB12161E), RoundedCornerShape(6.dp))
                    .border(1.dp, HorrorDarkGray, RoundedCornerShape(6.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = gameManager.gameProgress.currentRoomName.uppercase(),
                    fontSize = 11.sp,
                    letterSpacing = 1.5.sp,
                    color = HorrorWhite,
                    fontWeight = FontWeight.Bold
                )
            }

            // Current Objective Banner
            Box(
                modifier = Modifier
                    .background(Color(0xDD080B10), RoundedCornerShape(20.dp))
                    .border(1.dp, Color(0x33FFB03B), RoundedCornerShape(20.dp))
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .widthIn(max = 440.dp)
            ) {
                Text(
                    text = gameManager.gameProgress.currentObjective,
                    fontSize = 12.sp,
                    color = HorrorAmber,
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )
            }

            // Flashlight Battery & Pause Button
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Flashlight toggle & battery bar
                Row(
                    modifier = Modifier
                        .background(Color(0xBB12161E), RoundedCornerShape(20.dp))
                        .clickable { gameManager.playerController.toggleFlashlight() }
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (gameManager.playerData.flashlightOn) Icons.Filled.FlashlightOn else Icons.Filled.FlashlightOff,
                        contentDescription = "Flashlight",
                        tint = if (gameManager.playerData.flashlightOn) HorrorAmber else HorrorMist,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        LinearProgressIndicator(
                            progress = { gameManager.playerData.batteryPercentage / 100f },
                            modifier = Modifier
                                .width(45.dp)
                                .height(5.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = if (gameManager.playerData.batteryPercentage > 20f) HorrorAmber else HorrorCrimson,
                            trackColor = HorrorDarkGray
                        )
                        Text(
                            text = "${gameManager.playerData.batteryPercentage.toInt()}%",
                            fontSize = 9.sp,
                            color = HorrorMist
                        )
                    }
                }

                // Pause button
                IconButton(
                    onClick = { gameManager.isPaused = true },
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color(0xBB12161E), CircleShape)
                        .border(1.dp, HorrorDarkGray, CircleShape)
                        .testTag("game_pause_button")
                ) {
                    Icon(Icons.Filled.Pause, contentDescription = "Pause", tint = HorrorWhite, modifier = Modifier.size(20.dp))
                }
            }
        }

        // 6. Stealth Noise Indicator (Bottom Center)
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 12.dp)
                .background(Color(0xCC080B10), RoundedCornerShape(16.dp))
                .border(1.dp, HorrorDarkGray, RoundedCornerShape(16.dp))
                .padding(horizontal = 14.dp, vertical = 4.dp)
        ) {
            val noise = gameManager.playerData.currentNoiseLevel
            val noiseText = when {
                gameManager.playerData.isHiding -> "HIDDEN IN WARDROBE"
                noise < 0.1f -> "SILENT (CROUCH)"
                noise < 0.5f -> "QUIET (WALKING)"
                else -> "LOUD (RUNNING!)"
            }
            val noiseColor = when {
                gameManager.playerData.isHiding -> HorrorMutedGreen
                noise < 0.1f -> HorrorMutedGreen
                noise < 0.5f -> HorrorAmber
                else -> HorrorBloodRed
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(noiseColor, CircleShape)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = noiseText,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = noiseColor,
                    letterSpacing = 1.sp
                )
            }
        }

        // 7. Left Virtual Joystick (Movement)
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 28.dp, bottom = 28.dp)
                .size(130.dp)
                .background(Color(0x4412161E), CircleShape)
                .border(1.5.dp, Color(0x668E9BAE), CircleShape)
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragEnd = {
                            joystickThumbOffset = Offset.Zero
                            gameManager.moveJoystickX = 0f
                            gameManager.moveJoystickY = 0f
                        },
                        onDragCancel = {
                            joystickThumbOffset = Offset.Zero
                            gameManager.moveJoystickX = 0f
                            gameManager.moveJoystickY = 0f
                        }
                    ) { change, dragAmount ->
                        change.consume()
                        val newOffset = joystickThumbOffset + dragAmount
                        val dist = sqrt(newOffset.x * newOffset.x + newOffset.y * newOffset.y)
                        val clamped = if (dist > joystickRadius) {
                            Offset(newOffset.x / dist * joystickRadius, newOffset.y / dist * joystickRadius)
                        } else newOffset

                        joystickThumbOffset = clamped
                        gameManager.moveJoystickX = (clamped.x / joystickRadius).coerceIn(-1f, 1f)
                        gameManager.moveJoystickY = (-clamped.y / joystickRadius).coerceIn(-1f, 1f)
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            // Inner draggable knob
            Box(
                modifier = Modifier
                    .offset { IntOffset(joystickThumbOffset.x.roundToInt(), joystickThumbOffset.y.roundToInt()) }
                    .size(54.dp)
                    .background(Color(0x88FFB03B), CircleShape)
                    .border(2.dp, HorrorAmber, CircleShape)
            )
        }

        // 8. Right Action Buttons (Interact, Crouch, Run, Inventory)
        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 28.dp, bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            // Inventory Button
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(
                    onClick = { gameManager.isInventoryOpen = true },
                    modifier = Modifier
                        .size(54.dp)
                        .background(HorrorSurfaceVariant, CircleShape)
                        .border(1.dp, HorrorDarkGray, CircleShape)
                        .testTag("action_inventory_button")
                ) {
                    Icon(Icons.Filled.Backpack, contentDescription = "Inventory", tint = HorrorWhite)
                }
                Text(text = "ITEMS", fontSize = 10.sp, color = HorrorMist, modifier = Modifier.padding(top = 2.dp))
            }

            // Crouch Button
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(
                    onClick = { gameManager.playerController.toggleCrouch() },
                    modifier = Modifier
                        .size(54.dp)
                        .background(
                            if (gameManager.playerData.isCrouching) HorrorAmber else HorrorSurfaceVariant,
                            CircleShape
                        )
                        .border(1.dp, HorrorDarkGray, CircleShape)
                        .testTag("action_crouch_button")
                ) {
                    Icon(
                        Icons.Filled.AirlineSeatLegroomReduced,
                        contentDescription = "Crouch",
                        tint = if (gameManager.playerData.isCrouching) HorrorBlack else HorrorWhite
                    )
                }
                Text(
                    text = if (gameManager.playerData.isCrouching) "STAND" else "CROUCH",
                    fontSize = 10.sp,
                    color = HorrorMist,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            // Sprint/Run Button
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(
                    onClick = { gameManager.playerController.toggleRun() },
                    modifier = Modifier
                        .size(54.dp)
                        .background(
                            if (gameManager.playerData.isRunning) HorrorCrimson else HorrorSurfaceVariant,
                            CircleShape
                        )
                        .border(1.dp, HorrorDarkGray, CircleShape)
                        .testTag("action_run_button")
                ) {
                    Icon(
                        Icons.Filled.DirectionsRun,
                        contentDescription = "Run",
                        tint = HorrorWhite
                    )
                }
                // Stamina bar indicator
                LinearProgressIndicator(
                    progress = { gameManager.playerData.stamina / 100f },
                    modifier = Modifier
                        .width(42.dp)
                        .height(3.dp)
                        .padding(top = 2.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = HorrorAmber,
                    trackColor = HorrorDarkGray
                )
            }

            // Big Contextual Interact Button
            val isTargetPresent = gameManager.currentInteractionTarget != null
            Button(
                onClick = { gameManager.onInteractPressed() },
                modifier = Modifier
                    .size(76.dp)
                    .testTag("action_interact_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isTargetPresent) HorrorAmber else Color(0x55262E3B),
                    contentColor = if (isTargetPresent) HorrorBlack else HorrorMist
                ),
                shape = CircleShape
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Filled.PanTool,
                        contentDescription = "Interact",
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = if (gameManager.playerData.isHiding) "LEAVE" else "USE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // 9. Subtitle Message
        if (gameManager.subtitleMessage.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 54.dp)
                    .background(Color(0xDD080B10), RoundedCornerShape(8.dp))
                    .padding(horizontal = 20.dp, vertical = 6.dp)
            ) {
                Text(
                    text = gameManager.subtitleMessage,
                    color = HorrorWhite,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Serif,
                    textAlign = TextAlign.Center
                )
            }
        }

        // 10. Tutorial Card (shows on first start, skippable)
        if (isTutorialOpen) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xAA000000))
                    .testTag("tutorial_overlay"),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier.widthIn(max = 480.dp),
                    colors = CardDefaults.cardColors(containerColor = HorrorSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, HorrorAmber),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "HOW TO SURVIVE",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = HorrorAmber,
                            letterSpacing = 2.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "• LEFT THUMB: Virtual Joystick to walk.\n" +
                                   "• RIGHT SCREEN: Drag anywhere to turn your camera.\n" +
                                   "• INTERACT: Aim at items, doors, and notes to pick up or open.\n" +
                                   "• CROUCH: Reduces noise. The creature reacts to running.\n" +
                                   "• HIDE: Use wardrobes to escape the creature's sight.\n" +
                                   "• FLASHLIGHT: Keep an eye on battery power.",
                            fontSize = 13.sp,
                            color = HorrorWhite,
                            lineHeight = 22.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { isTutorialOpen = false },
                            colors = ButtonDefaults.buttonColors(containerColor = HorrorAmber, contentColor = HorrorBlack)
                        ) {
                            Text("I UNDERSTAND", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 11. Modals & Dialogs
        if (gameManager.isInventoryOpen) {
            InventoryDialog(
                inventory = gameManager.gameProgress.inventory,
                onUseItem = { type -> gameManager.useItem(type) },
                onDismiss = { gameManager.isInventoryOpen = false }
            )
        }

        if (gameManager.isSafeDialogOpen) {
            SafeKeypadDialog(
                onCodeSubmitted = { code -> gameManager.puzzleSystem.attemptSafeCode(code) },
                onDismiss = { gameManager.isSafeDialogOpen = false }
            )
        }

        if (gameManager.isBreakerDialogOpen) {
            BreakerPanelDialog(
                isFuseInstalled = gameManager.gameProgress.fuseInstalled,
                onInstallFuse = { gameManager.puzzleSystem.installFuse() },
                onSwitchToggled = { switchIndex -> gameManager.puzzleSystem.toggleBreakerSwitch(switchIndex) },
                onDismiss = { gameManager.isBreakerDialogOpen = false }
            )
        }

        if (gameManager.isNoteDialogOpen) {
            NoteReaderDialog(
                title = gameManager.activeNoteTitle,
                content = gameManager.activeNoteBody,
                onDismiss = { gameManager.isNoteDialogOpen = false }
            )
        }

        // 12. Pause Menu Modal
        if (gameManager.isPaused) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xDD000000)),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier.width(300.dp),
                    colors = CardDefaults.cardColors(containerColor = HorrorSurface),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, HorrorDarkGray)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "GAME PAUSED",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = HorrorWhite,
                            letterSpacing = 2.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = { gameManager.isPaused = false },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = HorrorAmber, contentColor = HorrorBlack)
                        ) {
                            Text("RESUME", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = onOpenSettings,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("SETTINGS", color = HorrorWhite)
                        }

                        OutlinedButton(
                            onClick = {
                                gameManager.saveSystem.saveGame(
                                    gameManager.playerData,
                                    gameManager.gameProgress,
                                    gameManager.lastCheckpointName.ifEmpty { "Manual Save" }
                                )
                                gameManager.isPaused = false
                                onReturnToMenu()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("SAVE & MAIN MENU", color = HorrorWhite)
                        }
                    }
                }
            }
        }
    }
}
