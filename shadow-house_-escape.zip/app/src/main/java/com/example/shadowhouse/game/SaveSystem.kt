package com.example.shadowhouse.game

import android.content.Context
import android.content.SharedPreferences
import com.example.shadowhouse.model.GameProgress
import com.example.shadowhouse.model.GameSettings
import com.example.shadowhouse.model.GraphicsQuality
import com.example.shadowhouse.model.InventoryItem
import com.example.shadowhouse.model.ItemType
import com.example.shadowhouse.model.PlayerData
import org.json.JSONArray
import org.json.JSONObject

class SaveSystem(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("shadow_house_save", Context.MODE_PRIVATE)

    fun hasSavedGame(): Boolean {
        return prefs.getBoolean("has_active_save", false)
    }

    fun saveGame(
        playerData: PlayerData,
        gameProgress: GameProgress,
        checkpointName: String
    ) {
        val editor = prefs.edit()
        editor.putBoolean("has_active_save", true)
        editor.putString("checkpoint_name", checkpointName)
        editor.putLong("saved_timestamp", System.currentTimeMillis())

        // Player Data
        editor.putFloat("player_x", playerData.posX)
        editor.putFloat("player_y", playerData.posY)
        editor.putFloat("player_z", playerData.posZ)
        editor.putFloat("player_yaw", playerData.yaw)
        editor.putFloat("player_pitch", playerData.pitch)
        editor.putFloat("player_battery", playerData.batteryPercentage)
        editor.putBoolean("player_flashlight", playerData.flashlightOn)

        // Game Progress
        editor.putString("current_room", gameProgress.currentRoomName)
        editor.putString("current_objective", gameProgress.currentObjective)
        editor.putBoolean("bathroom_key_picked", gameProgress.bathroomKeyPickedUp)
        editor.putBoolean("bedroom_unlocked", gameProgress.bedroomDoorUnlocked)
        editor.putBoolean("safe_unlocked", gameProgress.storageSafeUnlocked)
        editor.putBoolean("basement_unlocked", gameProgress.basementDoorUnlocked)
        editor.putBoolean("fuse_picked", gameProgress.fusePickedUp)
        editor.putBoolean("fuse_installed", gameProgress.fuseInstalled)
        editor.putBoolean("breaker_solved", gameProgress.breakerSolved)
        editor.putBoolean("passage_opened", gameProgress.secretPassageOpened)
        editor.putBoolean("confession_read", gameProgress.occultConfessionRead)
        editor.putBoolean("exit_unlocked", gameProgress.exitGateUnlocked)
        editor.putInt("seconds_survived", gameProgress.secondsSurvived)
        editor.putInt("checkpoints_passed", gameProgress.checkpointsPassed)

        // Inventory JSON
        val invArray = JSONArray()
        for (item in gameProgress.inventory) {
            val itemObj = JSONObject()
            itemObj.put("id", item.type.id)
            itemObj.put("qty", item.quantity)
            invArray.put(itemObj)
        }
        editor.putString("inventory_json", invArray.toString())

        editor.apply()
    }

    fun loadGame(
        playerData: PlayerData,
        gameProgress: GameProgress
    ): Boolean {
        if (!hasSavedGame()) return false

        try {
            playerData.posX = prefs.getFloat("player_x", 0f)
            playerData.posY = prefs.getFloat("player_y", 1.6f)
            playerData.posZ = prefs.getFloat("player_z", 2f)
            playerData.yaw = prefs.getFloat("player_yaw", 180f)
            playerData.pitch = prefs.getFloat("player_pitch", 0f)
            playerData.batteryPercentage = prefs.getFloat("player_battery", 85f)
            playerData.flashlightOn = prefs.getBoolean("player_flashlight", true)

            gameProgress.currentRoomName = prefs.getString("current_room", "Entrance Foyer") ?: "Entrance Foyer"
            gameProgress.currentObjective = prefs.getString("current_objective", "Explore the house.") ?: "Explore the house."
            gameProgress.bathroomKeyPickedUp = prefs.getBoolean("bathroom_key_picked", false)
            gameProgress.bedroomDoorUnlocked = prefs.getBoolean("bedroom_unlocked", false)
            gameProgress.storageSafeUnlocked = prefs.getBoolean("safe_unlocked", false)
            gameProgress.basementDoorUnlocked = prefs.getBoolean("basement_unlocked", false)
            gameProgress.fusePickedUp = prefs.getBoolean("fuse_picked", false)
            gameProgress.fuseInstalled = prefs.getBoolean("fuse_installed", false)
            gameProgress.breakerSolved = prefs.getBoolean("breaker_solved", false)
            gameProgress.secretPassageOpened = prefs.getBoolean("passage_opened", false)
            gameProgress.occultConfessionRead = prefs.getBoolean("confession_read", false)
            gameProgress.exitGateUnlocked = prefs.getBoolean("exit_unlocked", false)
            gameProgress.secondsSurvived = prefs.getInt("seconds_survived", 0)
            gameProgress.checkpointsPassed = prefs.getInt("checkpoints_passed", 0)

            // Inventory
            gameProgress.inventory.clear()
            val invString = prefs.getString("inventory_json", "[]") ?: "[]"
            val invArray = JSONArray(invString)
            for (i in 0 until invArray.length()) {
                val itemObj = invArray.getJSONObject(i)
                val id = itemObj.getString("id")
                val qty = itemObj.optInt("qty", 1)
                val type = ItemType.values().find { it.id == id }
                if (type != null) {
                    gameProgress.inventory.add(InventoryItem(type, qty))
                }
            }

            return true
        } catch (_: Exception) {
            return false
        }
    }

    fun clearSavedGame() {
        prefs.edit().putBoolean("has_active_save", false).apply()
    }

    fun saveSettings(settings: GameSettings) {
        prefs.edit()
            .putFloat("sett_master", settings.masterVolume)
            .putFloat("sett_sfx", settings.sfxVolume)
            .putFloat("sett_ambient", settings.ambientVolume)
            .putFloat("sett_sens", settings.sensitivity)
            .putString("sett_quality", settings.graphicsQuality.name)
            .putBoolean("sett_vib", settings.vibrationEnabled)
            .putBoolean("sett_sub", settings.subtitlesEnabled)
            .putBoolean("sett_inv_y", settings.invertY)
            .apply()
    }

    fun loadSettings(): GameSettings {
        val qualStr = prefs.getString("sett_quality", GraphicsQuality.MEDIUM.name) ?: GraphicsQuality.MEDIUM.name
        val quality = try { GraphicsQuality.valueOf(qualStr) } catch (_: Exception) { GraphicsQuality.MEDIUM }

        return GameSettings(
            masterVolume = prefs.getFloat("sett_master", 0.8f),
            sfxVolume = prefs.getFloat("sett_sfx", 0.8f),
            ambientVolume = prefs.getFloat("sett_ambient", 0.7f),
            sensitivity = prefs.getFloat("sett_sens", 1.0f),
            graphicsQuality = quality,
            vibrationEnabled = prefs.getBoolean("sett_vib", true),
            subtitlesEnabled = prefs.getBoolean("sett_sub", true),
            invertY = prefs.getBoolean("sett_inv_y", false)
        )
    }
}
