package com.example.shadowhouse.model

enum class ItemType(
    val id: String,
    val displayName: String,
    val description: String,
    val iconName: String,
    val isUsable: Boolean
) {
    FLASHLIGHT(
        id = "flashlight",
        displayName = "Heavy Flashlight",
        description = "An old metal flashlight. Essential for navigating the dark corridors of the house.",
        iconName = "flashlight",
        isUsable = true
    ),
    BATTERY(
        id = "battery",
        displayName = "Spare Battery",
        description = "A standard 9V battery. Restores 50% power to your flashlight.",
        iconName = "battery",
        isUsable = true
    ),
    BRASS_KEY(
        id = "brass_key",
        displayName = "Brass Skeleton Key",
        description = "Found in the bathroom cabinet. It has an ornate crest matching the Master Bedroom door.",
        iconName = "key",
        isUsable = false
    ),
    BASEMENT_KEY(
        id = "basement_key",
        displayName = "Rusted Iron Key",
        description = "Retrieved from the storage safe. Opens the heavy padlock on the basement cellar door.",
        iconName = "key",
        isUsable = false
    ),
    MAIN_EXIT_KEY(
        id = "main_exit_key",
        displayName = "Master Manor Key",
        description = "A heavy, dark iron key with ancient runes. The final key to unlock the front entrance gates.",
        iconName = "key",
        isUsable = false
    ),
    NOTE_KITCHEN(
        id = "note_kitchen",
        displayName = "Scrap of Journal (Page 1)",
        description = "A bloodstained note found on the kitchen counter: 'The safe combination begins with the year this accursed house was finished: 18...'",
        iconName = "note",
        isUsable = true
    ),
    NOTE_BEDROOM(
        id = "note_bedroom",
        displayName = "Torn Journal (Page 2)",
        description = "A note tucked under the bedroom pillow: '...and ends with the year the whispers began: ...94. Code: 1-8-9-4.'",
        iconName = "note",
        isUsable = true
    ),
    NOTE_BASEMENT(
        id = "note_basement",
        displayName = "Maintenance Log",
        description = "A scribbled note next to the electrical breaker: 'Breaker sequence to override magnetic locks: 3, then 1, then 4, then 2.'",
        iconName = "note",
        isUsable = true
    ),
    OCCULT_RESEARCH(
        id = "occult_research",
        displayName = "Dr. Blackwood's Confession",
        description = "A forbidden manuscript in the secret study: 'The shadow creature is not an intruder... it is my son, transformed by our ritual. I cannot destroy him, so I locked us both inside.'",
        iconName = "book",
        isUsable = true
    ),
    FUSE(
        id = "fuse",
        displayName = "Ceramic Fuse",
        description = "A spare electrical fuse found in the storage shelves. Needed to power the breaker panel.",
        iconName = "fuse",
        isUsable = false
    )
}

data class InventoryItem(
    val type: ItemType,
    val quantity: Int = 1
)
