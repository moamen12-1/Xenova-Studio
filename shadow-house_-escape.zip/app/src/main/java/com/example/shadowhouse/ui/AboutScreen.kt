package com.example.shadowhouse.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.HorrorAmber
import com.example.ui.theme.HorrorBlack
import com.example.ui.theme.HorrorMist
import com.example.ui.theme.HorrorSurface
import com.example.ui.theme.HorrorWhite

@Composable
fun AboutScreen(
    onBack: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(HorrorBlack)
            .padding(horizontal = 32.dp, vertical = 20.dp)
            .testTag("about_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp)
                .align(Alignment.Center)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = HorrorAmber)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "ABOUT & LORE",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = HorrorWhite,
                    letterSpacing = 4.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Lore Card
            Card(
                colors = CardDefaults.cardColors(containerColor = HorrorSurface),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(text = "THE BLACKWOOD TRAGEDY", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = HorrorAmber)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Constructed in 1894 by occult researcher Dr. Alistair Blackwood, the manor stands atop a secluded coastal ridge. " +
                               "Following the disappearance of his son William during a relentless autumn thunderstorm, the house was abandoned.\n\n" +
                               "Local folklore speaks of an insatiable shadow wandering its long corridors—not out of malice, but drawn to the light and footsteps of the living.",
                        fontSize = 13.sp,
                        color = HorrorWhite,
                        lineHeight = 20.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Game Play Guide Card
            Card(
                colors = CardDefaults.cardColors(containerColor = HorrorSurface),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(text = "SURVIVAL DIRECTIVES", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = HorrorAmber)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "1. Atmosphere First: Sound is your greatest ally and your biggest threat. Listen for creaking floorboards and distant thunder.\n" +
                               "2. Conserve Battery: Flashlight batteries drain over time. Search desks and countertops for replacements.\n" +
                               "3. Stealth & Cover: When the shadow creature nears, crouch to muffle your footsteps or conceal yourself inside antique wardrobes.\n" +
                               "4. Multiple Endings: Escaping through the front gate is one path. Uncovering Dr. Blackwood's occult confession diary reveals the deeper truth.",
                        fontSize = 13.sp,
                        color = HorrorWhite,
                        lineHeight = 20.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Tech & Credits
            Card(
                colors = CardDefaults.cardColors(containerColor = HorrorSurface),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(text = "CREDITS & SPECIFICATIONS", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = HorrorAmber)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Shadow House: Escape v1.0.0\n" +
                               "Native Android Project • Jetpack Compose UI • OpenGL ES 2.0 3D Engine\n" +
                               "Procedural Audio Synthesizer (PCM Storm & SFX Engine)\n" +
                               "100% Offline • Lightweight Low-End & Mid-Range Device Architecture",
                        fontSize = 12.sp,
                        color = HorrorMist,
                        lineHeight = 18.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
