package com.example.shadowhouse.game

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.shadowhouse.audio.AudioManager
import com.example.shadowhouse.engine3d.HouseMap
import com.example.shadowhouse.engine3d.HouseRenderer
import com.example.shadowhouse.engine3d.InteractiveObject
import com.example.shadowhouse.engine3d.Vector3
import com.example.shadowhouse.model.CreatureData
import com.example.shadowhouse.model.EndingType
import com.example.shadowhouse.model.GameProgress
import com.example.shadowhouse.model.GameSettings
import com.example.shadowhouse.model.ItemType
import com.example.shadowhouse.model.PlayerData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Random

class GameManager(val context: Context) {
    val audioManager = AudioManager(context)
    val saveSystem = SaveSystem(context)
    val houseMap = HouseMap()

    var settings by mutableStateOf(saveSystem.loadSettings())
    val playerData = PlayerData()
    val creatureData = CreatureData()
    val gameProgress = GameProgress()

    // Observable states for Compose HUD
    var currentInteractionTarget by mutableStateOf<InteractiveObject?>(null)
    var interactionMessage by mutableStateOf("")
    var subtitleMessage by mutableStateOf("")
    var isSafeDialogOpen by mutableStateOf(false)
    var isBreakerDialogOpen by mutableStateOf(false)
    var isNoteDialogOpen by mutableStateOf(false)
    var activeNoteTitle by mutableStateOf("")
    var activeNoteBody by mutableStateOf("")
    var isInventoryOpen by mutableStateOf(false)
    var isPaused by mutableStateOf(false)
    var endingState by mutableStateOf(EndingType.NONE)
    var lastCheckpointName by mutableStateOf("")

    // Joysticks & touch inputs
    var moveJoystickX = 0f
    var moveJoystickY = 0f

    val playerController: PlayerController
    val creatureAI: CreatureAI
    val puzzleSystem: PuzzleSystem
    val renderer: HouseRenderer

    private val gameScope = CoroutineScope(Dispatchers.Main)
    private var gameLoopJob: Job? = null
    private val random = Random()
    private var stormTimer = 0f
    private var secondAcc = 0f

    init {
        audioManager.settings = settings
        playerController = PlayerController(playerData, houseMap, audioManager, settings)
        creatureAI = CreatureAI(creatureData, playerData, gameProgress, houseMap, audioManager)

        puzzleSystem = PuzzleSystem(houseMap, gameProgress, playerData, audioManager) { checkpoint ->
            lastCheckpointName = checkpoint
            gameProgress.checkpointsPassed++
            saveSystem.saveGame(playerData, gameProgress, checkpoint)
            showSubtitle("Checkpoint: $checkpoint")
        }

        renderer = HouseRenderer(houseMap, playerData, creatureData, settings)
    }

    fun startNewGame() {
        saveSystem.clearSavedGame()
        resetWorldState()
        startGameLoop()
    }

    fun continueSavedGame(): Boolean {
        if (!saveSystem.hasSavedGame()) return false
        val loaded = saveSystem.loadGame(playerData, gameProgress)
        if (loaded) {
            syncWorldWithProgress()
            startGameLoop()
            return true
        }
        return false
    }

    private fun resetWorldState() {
        playerData.posX = 0f
        playerData.posY = 1.6f
        playerData.posZ = 2.5f
        playerData.yaw = 180f
        playerData.pitch = 0f
        playerData.isCrouching = false
        playerData.isRunning = false
        playerData.isHiding = false
        playerData.stamina = 100f
        playerData.batteryPercentage = 85f
        playerData.flashlightOn = false

        creatureData.posX = 0f
        creatureData.posZ = -14f
        creatureData.isVisible = false

        gameProgress.inventory.clear()
        gameProgress.currentRoomName = "Entrance Foyer"
        gameProgress.currentObjective = "You woke up trapped. Find the heavy flashlight on the entrance table."
        gameProgress.bathroomKeyPickedUp = false
        gameProgress.bedroomDoorUnlocked = false
        gameProgress.storageSafeUnlocked = false
        gameProgress.basementDoorUnlocked = false
        gameProgress.fusePickedUp = false
        gameProgress.fuseInstalled = false
        gameProgress.breakerSolved = false
        gameProgress.secretPassageOpened = false
        gameProgress.occultConfessionRead = false
        gameProgress.exitGateUnlocked = false
        gameProgress.secondsSurvived = 0
        gameProgress.checkpointsPassed = 0
        gameProgress.activeEnding = EndingType.NONE
        endingState = EndingType.NONE

        syncWorldWithProgress()
    }

    private fun syncWorldWithProgress() {
        for (obj in houseMap.interactiveObjects) {
            when (obj.id) {
                "item_flashlight" -> obj.isCollected = playerData.flashlightOn || puzzleSystem.hasItem(ItemType.FLASHLIGHT)
                "item_brass_key" -> obj.isCollected = gameProgress.bathroomKeyPickedUp
                "item_fuse" -> obj.isCollected = gameProgress.fusePickedUp
                "door_bedroom" -> {
                    obj.isLocked = !gameProgress.bedroomDoorUnlocked
                    obj.isOpen = gameProgress.bedroomDoorUnlocked
                }
                "door_basement" -> {
                    obj.isLocked = !gameProgress.basementDoorUnlocked
                    obj.isOpen = gameProgress.basementDoorUnlocked
                }
                "storage_safe" -> {
                    obj.isLocked = !gameProgress.storageSafeUnlocked
                    obj.isOpen = gameProgress.storageSafeUnlocked
                }
                "secret_passage_door" -> {
                    obj.isOpen = gameProgress.secretPassageOpened
                    obj.isLocked = !gameProgress.secretPassageOpened
                }
            }
        }
    }

    fun startGameLoop() {
        audioManager.startAmbientStorm()
        gameLoopJob?.cancel()
        gameLoopJob = gameScope.launch {
            var lastTime = System.currentTimeMillis()
            while (isActive) {
                val now = System.currentTimeMillis()
                val delta = ((now - lastTime) / 1000f).coerceIn(0.001f, 0.05f)
                lastTime = now

                if (!isPaused && endingState == EndingType.NONE) {
                    tickGame(delta)
                }
                delay(16) // ~60 FPS
            }
        }
    }

    fun pauseGame() {
        isPaused = true
    }

    fun resumeGame() {
        isPaused = false
    }

    fun stopGame() {
        gameLoopJob?.cancel()
        gameLoopJob = null
        audioManager.stopAmbientStorm()
    }

    private fun tickGame(delta: Float) {
        // Update player movement
        playerController.update(delta, moveJoystickX, moveJoystickY)

        // Update Creature AI
        creatureAI.update(delta)

        // Update Room Location
        gameProgress.currentRoomName = houseMap.getRoomNameAt(playerData.posX, playerData.posY, playerData.posZ)

        // Look raycast detection
        val lookDir = Vector3.directionFromYawPitch(playerData.yaw, playerData.pitch)
        val eyePos = Vector3(playerData.posX, playerData.posY, playerData.posZ)
        currentInteractionTarget = houseMap.getInteractableObjectAt(eyePos, lookDir, 2.5f)

        // Storm & Lightning events
        stormTimer += delta
        if (stormTimer > 18f + random.nextFloat() * 12f) {
            stormTimer = 0f
            renderer.lightningFlashTimer = 0.6f
            audioManager.playThunder()
        }

        // Timer counter
        secondAcc += delta
        if (secondAcc >= 1.0f) {
            secondAcc = 0f
            gameProgress.secondsSurvived++
        }

        // Check if game ended
        if (gameProgress.activeEnding != EndingType.NONE) {
            endingState = gameProgress.activeEnding
        }
    }

    fun onInteractPressed() {
        val target = currentInteractionTarget ?: return

        when (target.type) {
            com.example.shadowhouse.engine3d.ObjectType.NOTE -> {
                activeNoteTitle = target.name
                activeNoteBody = target.noteContent
                isNoteDialogOpen = true
                if (target.id == "note_occult_confession") {
                    gameProgress.occultConfessionRead = true
                    showSubtitle("Discovered the occult research... The hidden truth has been revealed.")
                }
                audioManager.playItemPickup()
            }
            com.example.shadowhouse.engine3d.ObjectType.SAFE -> {
                if (target.isLocked) {
                    isSafeDialogOpen = true
                } else {
                    showSubtitle("The safe is unlocked. Interior is empty.")
                }
            }
            com.example.shadowhouse.engine3d.ObjectType.BREAKER_SWITCH -> {
                isBreakerDialogOpen = true
            }
            else -> {
                val resultMsg = puzzleSystem.interactWith(target)
                if (resultMsg.isNotEmpty()) {
                    showSubtitle(resultMsg)
                }
            }
        }
    }

    fun showSubtitle(text: String) {
        if (!settings.subtitlesEnabled) return
        subtitleMessage = text
        gameScope.launch {
            delay(4000)
            if (subtitleMessage == text) {
                subtitleMessage = ""
            }
        }
    }

    fun updateSettings(newSettings: GameSettings) {
        settings = newSettings
        audioManager.settings = newSettings
        playerController.settings = newSettings
        renderer.settings = newSettings
        saveSystem.saveSettings(newSettings)
    }

    fun useItem(itemType: ItemType) {
        if (itemType == ItemType.BATTERY) {
            if (puzzleSystem.removeItemItem(ItemType.BATTERY)) {
                playerController.rechargeBattery(50f)
                showSubtitle("Inserted battery. Flashlight recharged by 50%!")
            }
        } else if (itemType == ItemType.FLASHLIGHT) {
            playerController.toggleFlashlight()
        }
    }
}
