package com.example.shadowhouse.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.shadowhouse.model.EndingType
import com.example.shadowhouse.model.GameProgress
import com.example.ui.theme.HorrorAmber
import com.example.ui.theme.HorrorBlack
import com.example.ui.theme.HorrorBloodRed
import com.example.ui.theme.HorrorCrimson
import com.example.ui.theme.HorrorDarkGray
import com.example.ui.theme.HorrorMist
import com.example.ui.theme.HorrorSurface
import com.example.ui.theme.HorrorWhite

@Composable
fun EndingScreen(
    endingType: EndingType,
    gameProgress: GameProgress,
    onRetryCheckpoint: () -> Unit,
    onReturnToMenu: () -> Unit
) {
    val isVictory = endingType == EndingType.ENDING_A_ESCAPE || endingType == EndingType.ENDING_B_HIDDEN_TRUTH

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(HorrorBlack)
            .padding(32.dp)
            .testTag("ending_screen_container"),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .widthIn(max = 620.dp)
                .testTag("ending_card"),
            colors = CardDefaults.cardColors(containerColor = HorrorSurface),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(
                width = 1.5.dp,
                color = if (isVictory) HorrorAmber else HorrorBloodRed
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Ending Title
                Text(
                    text = endingType.title.uppercase(),
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    letterSpacing = 4.sp,
                    color = if (isVictory) HorrorAmber else HorrorBloodRed,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Narrative Outcome
                Text(
                    text = endingType.description,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Serif,
                    fontStyle = FontStyle.Italic,
                    color = HorrorWhite,
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Statistics Strip
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(HorrorDarkGray, RoundedCornerShape(8.dp))
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "SURVIVED", fontSize = 11.sp, color = HorrorMist)
                            Text(
                                text = "${gameProgress.secondsSurvived / 60}m ${gameProgress.secondsSurvived % 60}s",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = HorrorWhite
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "CHECKPOINTS", fontSize = 11.sp, color = HorrorMist)
                            Text(
                                text = "${gameProgress.checkpointsPassed}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = HorrorWhite
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "ITEMS FOUND", fontSize = 11.sp, color = HorrorMist)
                            Text(
                                text = "${gameProgress.inventory.size}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = HorrorWhite
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (endingType == EndingType.ENDING_C_CAUGHT) {
                        Button(
                            onClick = onRetryCheckpoint,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = HorrorCrimson, contentColor = HorrorWhite),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.padding(end = 6.dp))
                            Text("RETRY CHECKPOINT", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }

                    OutlinedButton(
                        onClick = onReturnToMenu,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = HorrorWhite),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Filled.Home, contentDescription = null, modifier = Modifier.padding(end = 6.dp))
                        Text("MAIN MENU", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
