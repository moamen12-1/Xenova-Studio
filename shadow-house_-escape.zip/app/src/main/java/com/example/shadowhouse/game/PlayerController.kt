package com.example.shadowhouse.game

import com.example.shadowhouse.audio.AudioManager
import com.example.shadowhouse.engine3d.HouseMap
import com.example.shadowhouse.engine3d.Vector3
import com.example.shadowhouse.model.GameSettings
import com.example.shadowhouse.model.PlayerData
import kotlin.math.cos
import kotlin.math.sin

class PlayerController(
    val playerData: PlayerData,
    val houseMap: HouseMap,
    val audioManager: AudioManager,
    var settings: GameSettings
) {
    private var footstepTimer = 0f
    private val standHeight = 1.6f
    private val crouchHeight = 0.9f

    fun update(
        deltaSeconds: Float,
        moveX: Float, // -1 to 1 (strafe left/right)
        moveY: Float  // -1 to 1 (forward/backward)
    ) {
        // If hiding inside wardrobe, player cannot move
        if (playerData.isHiding) {
            playerData.currentNoiseLevel = 0f
            return
        }

        // Crouch height lerp
        val targetHeight = if (playerData.isCrouching) crouchHeight else standHeight
        playerData.posY += (targetHeight - playerData.posY) * (10f * deltaSeconds)

        // Running & stamina
        var speed = 2.4f // base walk speed
        if (playerData.isCrouching) {
            speed = 1.2f
            playerData.isRunning = false
        } else if (playerData.isRunning && playerData.stamina > 5f) {
            speed = 4.5f
            playerData.stamina = (playerData.stamina - 20f * deltaSeconds).coerceAtLeast(0f)
            if (playerData.stamina <= 0f) {
                playerData.isRunning = false
            }
        } else {
            // Recover stamina
            playerData.isRunning = false
            playerData.stamina = (playerData.stamina + 15f * deltaSeconds).coerceAtMost(100f)
        }

        // Calculate movement relative to player yaw
        val yawRad = Math.toRadians(playerData.yaw.toDouble())
        val forwardX = sin(yawRad).toFloat()
        val forwardZ = -cos(yawRad).toFloat()
        val rightX = cos(yawRad).toFloat()
        val rightZ = sin(yawRad).toFloat()

        val velX = (forwardX * moveY + rightX * moveX) * speed
        val velZ = (forwardZ * moveY + rightZ * moveX) * speed

        val isMoving = (moveX * moveX + moveY * moveY) > 0.05f

        if (isMoving) {
            val nextX = playerData.posX + velX * deltaSeconds
            val nextZ = playerData.posZ + velZ * deltaSeconds

            // Collision check (separate X and Z for sliding along walls)
            if (!houseMap.isPositionBlocked(nextX, playerData.posZ)) {
                playerData.posX = nextX
            }
            if (!houseMap.isPositionBlocked(playerData.posX, nextZ)) {
                playerData.posZ = nextZ
            }

            // Footstep sounds & noise generation
            val stepInterval = when {
                playerData.isCrouching -> 0.75f
                playerData.isRunning -> 0.32f
                else -> 0.52f
            }

            footstepTimer += deltaSeconds
            if (footstepTimer >= stepInterval) {
                footstepTimer = 0f
                val isCreaky = playerData.posZ in -18.5f..-2.0f && (playerData.posX in -2.2f..2.2f)
                audioManager.playFootstep(isCreaky)
            }

            playerData.currentNoiseLevel = when {
                playerData.isCrouching -> 0.05f
                playerData.isRunning -> 0.95f
                else -> 0.35f
            }
        } else {
            playerData.currentNoiseLevel = 0f
            footstepTimer = 0f
        }

        // Flashlight battery decay
        if (playerData.flashlightOn) {
            // ~10 minutes battery life = 100% / 600s = 0.16% per second
            playerData.batteryPercentage = (playerData.batteryPercentage - 0.12f * deltaSeconds).coerceAtLeast(0f)
            if (playerData.batteryPercentage <= 0f) {
                playerData.flashlightOn = false
            }
        }
    }

    fun rotateCamera(deltaYaw: Float, deltaPitch: Float) {
        val sens = settings.sensitivity * 0.35f
        playerData.yaw = (playerData.yaw + deltaYaw * sens) % 360f
        if (playerData.yaw < 0f) playerData.yaw += 360f

        val pitchSign = if (settings.invertY) -1f else 1f
        playerData.pitch = (playerData.pitch + deltaPitch * sens * pitchSign).coerceIn(-75f, 75f)
    }

    fun toggleFlashlight() {
        if (playerData.batteryPercentage > 0f) {
            playerData.flashlightOn = !playerData.flashlightOn
            audioManager.playFlashlightClick()
        }
    }

    fun toggleCrouch() {
        playerData.isCrouching = !playerData.isCrouching
    }

    fun toggleRun() {
        if (!playerData.isCrouching && playerData.stamina > 15f) {
            playerData.isRunning = !playerData.isRunning
        }
    }

    fun rechargeBattery(amount: Float = 50f) {
        playerData.batteryPercentage = (playerData.batteryPercentage + amount).coerceAtMost(100f)
        audioManager.playItemPickup()
    }
}
