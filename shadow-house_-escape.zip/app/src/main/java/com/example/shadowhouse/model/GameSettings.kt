package com.example.shadowhouse.model

enum class GraphicsQuality(val displayName: String, val shadowSteps: Int, val maxLights: Int, val fogDensity: Float) {
    LOW("LOW", shadowSteps = 0, maxLights = 2, fogDensity = 0.08f),
    MEDIUM("MEDIUM", shadowSteps = 1, maxLights = 4, fogDensity = 0.06f),
    HIGH("HIGH", shadowSteps = 2, maxLights = 6, fogDensity = 0.045f)
}

data class GameSettings(
    val masterVolume: Float = 0.8f,
    val sfxVolume: Float = 0.8f,
    val ambientVolume: Float = 0.7f,
    val sensitivity: Float = 1.0f,
    val graphicsQuality: GraphicsQuality = GraphicsQuality.MEDIUM,
    val vibrationEnabled: Boolean = true,
    val subtitlesEnabled: Boolean = true,
    val invertY: Boolean = false
)
