package com.example.shadowhouse.engine3d

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import com.example.shadowhouse.model.CreatureBehaviorState
import com.example.shadowhouse.model.CreatureData
import com.example.shadowhouse.model.GameSettings
import com.example.shadowhouse.model.PlayerData
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.Random
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.sin

class HouseRenderer(
    val houseMap: HouseMap,
    var playerData: PlayerData,
    var creatureData: CreatureData,
    var settings: GameSettings
) : GLSurfaceView.Renderer {

    private val vMatrix = FloatArray(16)
    private val pMatrix = FloatArray(16)
    private val mMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)

    private var programHandle = 0
    private var uMVPMatrixHandle = 0
    private var uMMatrixHandle = 0
    private var uTextureHandle = 0
    private var uCameraPosHandle = 0
    private var uLightDirHandle = 0
    private var uLightIntensityHandle = 0
    private var uLightningFlashHandle = 0
    private var uFogDensityHandle = 0
    private var uFlashlightOnHandle = 0
    private var uEmissiveColorHandle = 0

    private var aPositionHandle = 0
    private var aTexCoordHandle = 0
    private var aNormalHandle = 0

    private var textures: Map<TextureGenerator.TextureType, Int> = emptyMap()

    private lateinit var wallBuffer: FloatBuffer
    private var wallVertexCount = 0

    private lateinit var floorCeilingBuffer: FloatBuffer
    private var floorCeilingVertexCount = 0

    private lateinit var quadBuffer: FloatBuffer
    private lateinit var cubeBuffer: FloatBuffer

    private val random = Random()
    var lightningFlashTimer = 0f
    private var frameTime = 0f

    private val vertexShaderSource = """
        uniform mat4 u_MVPMatrix;
        uniform mat4 u_MMatrix;
        attribute vec4 a_Position;
        attribute vec2 a_TexCoordinate;
        attribute vec3 a_Normal;

        varying vec3 v_PositionWorld;
        varying vec2 v_TexCoordinate;
        varying vec3 v_NormalWorld;

        void main() {
            vec4 worldPos = u_MMatrix * a_Position;
            v_PositionWorld = vec3(worldPos);
            v_TexCoordinate = a_TexCoordinate;
            v_NormalWorld = normalize(vec3(u_MMatrix * vec4(a_Normal, 0.0)));
            gl_Position = u_MVPMatrix * a_Position;
        }
    """.trimIndent()

    private val fragmentShaderSource = """
        precision mediump float;
        uniform sampler2D u_Texture;
        uniform vec3 u_CameraPos;
        uniform vec3 u_LightDir;
        uniform float u_LightIntensity;
        uniform float u_LightningFlash;
        uniform float u_FogDensity;
        uniform float u_FlashlightOn;
        uniform vec4 u_EmissiveColor;

        varying vec3 v_PositionWorld;
        varying vec2 v_TexCoordinate;
        varying vec3 v_NormalWorld;

        void main() {
            vec4 texColor = texture2D(u_Texture, v_TexCoordinate);
            if (texColor.a < 0.2) discard;

            // Ambient darkness
            vec3 ambient = vec3(0.08, 0.09, 0.12) + vec3(u_LightningFlash * 0.85);

            // Flashlight spotlight calculation
            vec3 toPoint = v_PositionWorld - u_CameraPos;
            float distance = length(toPoint);
            vec3 lightDirNorm = normalize(toPoint);
            vec3 spotDirNorm = normalize(u_LightDir);

            float spotCos = dot(lightDirNorm, spotDirNorm);
            float spotCutoff = 0.82; // ~35 degrees cone
            float spotOuter = 0.65;  // soft falloff

            float spotFactor = clamp((spotCos - spotOuter) / (spotCutoff - spotOuter), 0.0, 1.0);
            float attenuation = 1.0 / (1.0 + 0.08 * distance + 0.015 * distance * distance);
            float diffuse = max(dot(v_NormalWorld, -lightDirNorm), 0.0);

            vec3 flashlight = vec3(1.0, 0.95, 0.85) * (diffuse * 1.5 + 0.3) * spotFactor * attenuation * u_LightIntensity * u_FlashlightOn;

            vec3 finalColor = (texColor.rgb * (ambient + flashlight)) + u_EmissiveColor.rgb;

            // Distance fog
            float fogFactor = exp(-pow(distance * u_FogDensity, 2.0));
            fogFactor = clamp(fogFactor, 0.0, 1.0);
            vec3 fogColor = vec3(0.03, 0.04, 0.07) + vec3(u_LightningFlash * 0.4);

            gl_FragColor = vec4(mix(fogColor, finalColor, fogFactor), texColor.a);
        }
    """.trimIndent()

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.02f, 0.03f, 0.05f, 1.0f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glEnable(GLES20.GL_CULL_FACE)
        GLES20.glCullFace(GLES20.GL_BACK)

        programHandle = ShaderHelper.createAndLinkProgram(vertexShaderSource, fragmentShaderSource)
        uMVPMatrixHandle = GLES20.glGetUniformLocation(programHandle, "u_MVPMatrix")
        uMMatrixHandle = GLES20.glGetUniformLocation(programHandle, "u_MMatrix")
        uTextureHandle = GLES20.glGetUniformLocation(programHandle, "u_Texture")
        uCameraPosHandle = GLES20.glGetUniformLocation(programHandle, "u_CameraPos")
        uLightDirHandle = GLES20.glGetUniformLocation(programHandle, "u_LightDir")
        uLightIntensityHandle = GLES20.glGetUniformLocation(programHandle, "u_LightIntensity")
        uLightningFlashHandle = GLES20.glGetUniformLocation(programHandle, "u_LightningFlash")
        uFogDensityHandle = GLES20.glGetUniformLocation(programHandle, "u_FogDensity")
        uFlashlightOnHandle = GLES20.glGetUniformLocation(programHandle, "u_FlashlightOn")
        uEmissiveColorHandle = GLES20.glGetUniformLocation(programHandle, "u_EmissiveColor")

        aPositionHandle = GLES20.glGetAttribLocation(programHandle, "a_Position")
        aTexCoordHandle = GLES20.glGetAttribLocation(programHandle, "a_TexCoordinate")
        aNormalHandle = GLES20.glGetAttribLocation(programHandle, "a_Normal")

        textures = TextureGenerator.initTextures()

        buildStaticBuffers()
    }

    private fun buildStaticBuffers() {
        // Wall mesh generation (Each wall is 2 triangles = 6 vertices, 8 floats per vertex: x,y,z, u,v, nx,ny,nz)
        val wallFloats = mutableListOf<Float>()
        for (w in houseMap.walls) {
            val dx = w.x2 - w.x1
            val dz = w.z2 - w.z1
            val len = kotlin.math.sqrt(dx * dx + dz * dz)
            val nx = -dz / len
            val nz = dx / len
            val uMax = len / 2f

            // V1: bottom left
            wallFloats.addAll(listOf(w.x1, w.yBottom, w.z1, 0f, 1f, nx, 0f, nz))
            // V2: bottom right
            wallFloats.addAll(listOf(w.x2, w.yBottom, w.z2, uMax, 1f, nx, 0f, nz))
            // V3: top left
            wallFloats.addAll(listOf(w.x1, w.yTop, w.z1, 0f, 0f, nx, 0f, nz))

            // V4: bottom right
            wallFloats.addAll(listOf(w.x2, w.yBottom, w.z2, uMax, 1f, nx, 0f, nz))
            // V5: top right
            wallFloats.addAll(listOf(w.x2, w.yTop, w.z2, uMax, 0f, nx, 0f, nz))
            // V6: top left
            wallFloats.addAll(listOf(w.x1, w.yTop, w.z1, 0f, 0f, nx, 0f, nz))
        }
        wallVertexCount = wallFloats.size / 8
        wallBuffer = ByteBuffer.allocateDirect(wallFloats.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        wallBuffer.put(wallFloats.toFloatArray()).position(0)

        // Floor / Ceiling mesh generation
        val fcFloats = mutableListOf<Float>()
        for (fc in houseMap.floorCeilings) {
            val uMax = (fc.maxX - fc.minX) / 2.5f
            val vMax = (fc.maxZ - fc.minZ) / 2.5f
            val ny = if (fc.isCeiling) -1f else 1f

            if (!fc.isCeiling) {
                fcFloats.addAll(listOf(fc.minX, fc.y, fc.minZ, 0f, 0f, 0f, ny, 0f))
                fcFloats.addAll(listOf(fc.minX, fc.y, fc.maxZ, 0f, vMax, 0f, ny, 0f))
                fcFloats.addAll(listOf(fc.maxX, fc.y, fc.minZ, uMax, 0f, 0f, ny, 0f))

                fcFloats.addAll(listOf(fc.maxX, fc.y, fc.minZ, uMax, 0f, 0f, ny, 0f))
                fcFloats.addAll(listOf(fc.minX, fc.y, fc.maxZ, 0f, vMax, 0f, ny, 0f))
                fcFloats.addAll(listOf(fc.maxX, fc.y, fc.maxZ, uMax, vMax, 0f, ny, 0f))
            } else {
                fcFloats.addAll(listOf(fc.minX, fc.y, fc.minZ, 0f, 0f, 0f, ny, 0f))
                fcFloats.addAll(listOf(fc.maxX, fc.y, fc.minZ, uMax, 0f, 0f, ny, 0f))
                fcFloats.addAll(listOf(fc.minX, fc.y, fc.maxZ, 0f, vMax, 0f, ny, 0f))

                fcFloats.addAll(listOf(fc.maxX, fc.y, fc.minZ, uMax, 0f, 0f, ny, 0f))
                fcFloats.addAll(listOf(fc.maxX, fc.y, fc.maxZ, uMax, vMax, 0f, ny, 0f))
                fcFloats.addAll(listOf(fc.minX, fc.y, fc.maxZ, 0f, vMax, 0f, ny, 0f))
            }
        }
        floorCeilingVertexCount = fcFloats.size / 8
        floorCeilingBuffer = ByteBuffer.allocateDirect(fcFloats.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        floorCeilingBuffer.put(fcFloats.toFloatArray()).position(0)

        // Unit quad (for billboards, doors, paintings)
        val quad = floatArrayOf(
            -0.5f, -0.5f, 0f, 0f, 1f, 0f, 0f, 1f,
             0.5f, -0.5f, 0f, 1f, 1f, 0f, 0f, 1f,
            -0.5f,  0.5f, 0f, 0f, 0f, 0f, 0f, 1f,

             0.5f, -0.5f, 0f, 1f, 1f, 0f, 0f, 1f,
             0.5f,  0.5f, 0f, 1f, 0f, 0f, 0f, 1f,
            -0.5f,  0.5f, 0f, 0f, 0f, 0f, 0f, 1f
        )
        quadBuffer = ByteBuffer.allocateDirect(quad.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        quadBuffer.put(quad).position(0)

        // Simple cube (for tables, chests, safe)
        val cube = floatArrayOf(
            // Front
            -0.5f, -0.5f,  0.5f, 0f, 1f, 0f, 0f, 1f,
             0.5f, -0.5f,  0.5f, 1f, 1f, 0f, 0f, 1f,
            -0.5f,  0.5f,  0.5f, 0f, 0f, 0f, 0f, 1f,
             0.5f, -0.5f,  0.5f, 1f, 1f, 0f, 0f, 1f,
             0.5f,  0.5f,  0.5f, 1f, 0f, 0f, 0f, 1f,
            -0.5f,  0.5f,  0.5f, 0f, 0f, 0f, 0f, 1f,
            // Back
             0.5f, -0.5f, -0.5f, 0f, 1f, 0f, 0f, -1f,
            -0.5f, -0.5f, -0.5f, 1f, 1f, 0f, 0f, -1f,
             0.5f,  0.5f, -0.5f, 0f, 0f, 0f, 0f, -1f,
            -0.5f, -0.5f, -0.5f, 1f, 1f, 0f, 0f, -1f,
            -0.5f,  0.5f, -0.5f, 1f, 0f, 0f, 0f, -1f,
             0.5f,  0.5f, -0.5f, 0f, 0f, 0f, 0f, -1f
        )
        cubeBuffer = ByteBuffer.allocateDirect(cube.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        cubeBuffer.put(cube).position(0)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val ratio = width.toFloat() / height.toFloat()
        // 65 deg FOV
        Matrix.perspectiveM(pMatrix, 0, 65f, ratio, 0.1f, 45f)
    }

    override fun onDrawFrame(gl: GL10?) {
        frameTime += 0.016f
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        // Setup Camera View Matrix
        val lookDir = Vector3.directionFromYawPitch(playerData.yaw, playerData.pitch)
        val eyeX = playerData.posX
        val eyeY = playerData.posY
        val eyeZ = playerData.posZ
        val targetX = eyeX + lookDir.x
        val targetY = eyeY + lookDir.y
        val targetZ = eyeZ + lookDir.z

        Matrix.setLookAtM(vMatrix, 0, eyeX, eyeY, eyeZ, targetX, targetY, targetZ, 0f, 1f, 0f)

        GLES20.glUseProgram(programHandle)

        // Flashlight battery calculation & flickering
        var lightIntensity = (playerData.batteryPercentage / 100f).coerceIn(0.2f, 1.0f)
        if (playerData.batteryPercentage < 20f) {
            // Low battery flickering
            if (random.nextFloat() < 0.25f) {
                lightIntensity *= (0.3f + random.nextFloat() * 0.4f)
            }
        }

        // Lightning flash
        var lightningFlash = 0f
        if (lightningFlashTimer > 0f) {
            lightningFlashTimer -= 0.016f
            lightningFlash = (lightningFlashTimer * 1.5f).coerceIn(0f, 1f)
        }

        // Set global uniforms
        GLES20.glUniform3f(uCameraPosHandle, eyeX, eyeY, eyeZ)
        GLES20.glUniform3f(uLightDirHandle, lookDir.x, lookDir.y, lookDir.z)
        GLES20.glUniform1f(uLightIntensityHandle, lightIntensity)
        GLES20.glUniform1f(uLightningFlashHandle, lightningFlash)
        GLES20.glUniform1f(uFogDensityHandle, settings.graphicsQuality.fogDensity)
        GLES20.glUniform1f(uFlashlightOnHandle, if (playerData.flashlightOn) 1.0f else 0.0f)
        GLES20.glUniform4f(uEmissiveColorHandle, 0f, 0f, 0f, 0f)

        // 1. Draw Walls
        bindTexture(TextureGenerator.TextureType.WALL)
        Matrix.setIdentityM(mMatrix, 0)
        Matrix.multiplyMM(mvpMatrix, 0, vMatrix, 0, mMatrix, 0)
        Matrix.multiplyMM(mvpMatrix, 0, pMatrix, 0, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(uMVPMatrixHandle, 1, false, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(uMMatrixHandle, 1, false, mMatrix, 0)

        drawVertices(wallBuffer, wallVertexCount)

        // 2. Draw Floor & Ceiling
        bindTexture(TextureGenerator.TextureType.WOOD_FLOOR)
        drawVertices(floorCeilingBuffer, floorCeilingVertexCount)

        // 3. Draw Doors and Interactive Objects
        drawWorldObjects(eyeX, eyeY, eyeZ)

        // 4. Draw Creature if active
        drawCreature(eyeX, eyeY, eyeZ)
    }

    private fun drawWorldObjects(eyeX: Float, eyeY: Float, eyeZ: Float) {
        for (obj in houseMap.interactiveObjects) {
            if (obj.isCollected) continue

            when (obj.type) {
                ObjectType.DOOR -> {
                    bindTexture(TextureGenerator.TextureType.DOOR)
                    Matrix.setIdentityM(mMatrix, 0)
                    Matrix.translateM(mMatrix, 0, obj.posX, obj.posY, obj.posZ)
                    if (obj.isOpen) {
                        Matrix.rotateM(mMatrix, 0, 85f, 0f, 1f, 0f)
                    }
                    Matrix.scaleM(mMatrix, 0, 1.8f, 2.4f, 0.1f)
                    drawMeshWithMatrices(cubeBuffer, 12)
                }
                ObjectType.EXIT_GATE -> {
                    bindTexture(TextureGenerator.TextureType.METAL_SAFE)
                    Matrix.setIdentityM(mMatrix, 0)
                    Matrix.translateM(mMatrix, 0, obj.posX, obj.posY, obj.posZ)
                    Matrix.scaleM(mMatrix, 0, 3.0f, 2.8f, 0.15f)
                    drawMeshWithMatrices(cubeBuffer, 12)
                }
                ObjectType.SAFE -> {
                    bindTexture(TextureGenerator.TextureType.METAL_SAFE)
                    Matrix.setIdentityM(mMatrix, 0)
                    Matrix.translateM(mMatrix, 0, obj.posX, obj.posY, obj.posZ)
                    Matrix.scaleM(mMatrix, 0, 0.8f, 0.9f, 0.8f)
                    drawMeshWithMatrices(cubeBuffer, 12)
                }
                ObjectType.BREAKER_SWITCH -> {
                    bindTexture(TextureGenerator.TextureType.METAL_SAFE)
                    Matrix.setIdentityM(mMatrix, 0)
                    Matrix.translateM(mMatrix, 0, obj.posX, obj.posY, obj.posZ)
                    Matrix.scaleM(mMatrix, 0, 0.6f, 0.8f, 0.2f)
                    drawMeshWithMatrices(cubeBuffer, 12)
                }
                ObjectType.WARDROBE -> {
                    bindTexture(TextureGenerator.TextureType.DOOR)
                    Matrix.setIdentityM(mMatrix, 0)
                    Matrix.translateM(mMatrix, 0, obj.posX, obj.posY, obj.posZ)
                    Matrix.scaleM(mMatrix, 0, 1.4f, 2.3f, 0.8f)
                    drawMeshWithMatrices(cubeBuffer, 12)
                }
                ObjectType.ITEM_PICKUP -> {
                    // Floating glowing collectible item!
                    val bobbingY = obj.posY + 0.08f * sin(frameTime * 3.5f + obj.posX)
                    bindTexture(TextureGenerator.TextureType.METAL_SAFE)
                    Matrix.setIdentityM(mMatrix, 0)
                    Matrix.translateM(mMatrix, 0, obj.posX, bobbingY, obj.posZ)
                    Matrix.rotateM(mMatrix, 0, frameTime * 45f, 0f, 1f, 0f)
                    Matrix.scaleM(mMatrix, 0, 0.25f, 0.25f, 0.25f)

                    // Subtle amber emission so items are discoverable in dark
                    GLES20.glUniform4f(uEmissiveColorHandle, 0.5f, 0.35f, 0.1f, 1f)
                    drawMeshWithMatrices(cubeBuffer, 12)
                    GLES20.glUniform4f(uEmissiveColorHandle, 0f, 0f, 0f, 0f)
                }
                ObjectType.NOTE -> {
                    bindTexture(TextureGenerator.TextureType.PAINTING)
                    Matrix.setIdentityM(mMatrix, 0)
                    Matrix.translateM(mMatrix, 0, obj.posX, obj.posY, obj.posZ)
                    Matrix.scaleM(mMatrix, 0, 0.35f, 0.45f, 0.02f)
                    GLES20.glUniform4f(uEmissiveColorHandle, 0.3f, 0.25f, 0.15f, 1f)
                    drawMeshWithMatrices(cubeBuffer, 12)
                    GLES20.glUniform4f(uEmissiveColorHandle, 0f, 0f, 0f, 0f)
                }
                else -> {}
            }
        }
    }

    private fun drawCreature(eyeX: Float, eyeY: Float, eyeZ: Float) {
        if (!creatureData.isVisible || creatureData.state == CreatureBehaviorState.VANISHED) return

        // Creature Billboard facing the player camera
        val dx = eyeX - creatureData.posX
        val dz = eyeZ - creatureData.posZ
        val angleRad = kotlin.math.atan2(dx.toDouble(), dz.toDouble())
        val angleDeg = Math.toDegrees(angleRad).toFloat()

        bindTexture(TextureGenerator.TextureType.CREATURE)
        Matrix.setIdentityM(mMatrix, 0)
        Matrix.translateM(mMatrix, 0, creatureData.posX, creatureData.posY + 1.4f, creatureData.posZ)
        Matrix.rotateM(mMatrix, 0, angleDeg, 0f, 1f, 0f)
        Matrix.scaleM(mMatrix, 0, 1.8f, 2.7f, 1.0f)

        // Glowing red/amber eyes when angry or chasing
        if (creatureData.state == CreatureBehaviorState.CHASE) {
            GLES20.glUniform4f(uEmissiveColorHandle, 0.6f, 0.1f, 0.05f, 1f)
        } else {
            GLES20.glUniform4f(uEmissiveColorHandle, 0.35f, 0.2f, 0.05f, 1f)
        }

        drawMeshWithMatrices(quadBuffer, 6)
        GLES20.glUniform4f(uEmissiveColorHandle, 0f, 0f, 0f, 0f)
    }

    private fun drawMeshWithMatrices(buffer: FloatBuffer, vertexCount: Int) {
        Matrix.multiplyMM(mvpMatrix, 0, vMatrix, 0, mMatrix, 0)
        Matrix.multiplyMM(mvpMatrix, 0, pMatrix, 0, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(uMVPMatrixHandle, 1, false, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(uMMatrixHandle, 1, false, mMatrix, 0)
        drawVertices(buffer, vertexCount)
    }

    private fun bindTexture(type: TextureGenerator.TextureType) {
        val id = textures[type] ?: 0
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id)
        GLES20.glUniform1i(uTextureHandle, 0)
    }

    private fun drawVertices(buffer: FloatBuffer, vertexCount: Int) {
        val stride = 8 * 4 // 8 floats per vertex

        buffer.position(0)
        GLES20.glEnableVertexAttribArray(aPositionHandle)
        GLES20.glVertexAttribPointer(aPositionHandle, 3, GLES20.GL_FLOAT, false, stride, buffer)

        buffer.position(3)
        GLES20.glEnableVertexAttribArray(aTexCoordHandle)
        GLES20.glVertexAttribPointer(aTexCoordHandle, 2, GLES20.GL_FLOAT, false, stride, buffer)

        buffer.position(5)
        GLES20.glEnableVertexAttribArray(aNormalHandle)
        GLES20.glVertexAttribPointer(aNormalHandle, 3, GLES20.GL_FLOAT, false, stride, buffer)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, vertexCount)

        GLES20.glDisableVertexAttribArray(aPositionHandle)
        GLES20.glDisableVertexAttribArray(aTexCoordHandle)
        GLES20.glDisableVertexAttribArray(aNormalHandle)
    }
}
