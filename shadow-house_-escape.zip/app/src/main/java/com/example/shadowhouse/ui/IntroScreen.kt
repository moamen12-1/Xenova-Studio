package com.example.shadowhouse.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.shadowhouse.audio.AudioManager
import com.example.ui.theme.HorrorAmber
import com.example.ui.theme.HorrorBlack
import com.example.ui.theme.HorrorMist
import com.example.ui.theme.HorrorWhite
import kotlinx.coroutines.delay

@Composable
fun IntroScreen(
    audioManager: AudioManager,
    onIntroFinished: () -> Unit
) {
    // Eyelid opening animation (height of eyelids: 1f = closed, 0f = wide open)
    val eyelidHeight = remember { Animatable(1.0f) }
    val textAlpha = remember { Animatable(0f) }
    var narrativeStep by remember { mutableStateOf(0) }

    val narrativeTexts = listOf(
        "A sudden crack of thunder jolts you awake...",
        "The cold floorboards bite into your skin. Rain lashes against the windows.",
        "The heavy iron doors are locked from the outside.",
        "And somewhere in the dark corridors... something is listening."
    )

    LaunchedEffect(Unit) {
        audioManager.playThunder()
        delay(1200)

        // Eye opens slightly then blinks closed
        eyelidHeight.animateTo(0.6f, tween(1500, easing = FastOutSlowInEasing))
        delay(400)
        eyelidHeight.animateTo(0.9f, tween(500))
        delay(300)

        // Eye opens fully
        eyelidHeight.animateTo(0.0f, tween(2000, easing = FastOutSlowInEasing))

        // Narrative sequence
        for (i in narrativeTexts.indices) {
            narrativeStep = i
            textAlpha.animateTo(1f, tween(800))
            delay(2400)
            textAlpha.animateTo(0f, tween(600))
            delay(300)
        }

        delay(500)
        onIntroFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(HorrorBlack)
            .testTag("intro_screen_container")
    ) {
        // Center Narrative Text
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(32.dp)
                .widthIn(max = 680.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = narrativeTexts[narrativeStep],
                fontSize = 20.sp,
                fontFamily = FontFamily.Serif,
                fontStyle = FontStyle.Italic,
                color = if (narrativeStep == 3) HorrorAmber else HorrorWhite,
                textAlign = TextAlign.Center,
                lineHeight = 32.sp,
                modifier = Modifier
                    .alpha(textAlpha.value)
                    .testTag("intro_narrative_text")
            )
        }

        // Top Eyelid Overlay
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxSize(eyelidHeight.value * 0.5f)
                .align(Alignment.TopCenter)
                .background(Color.Black)
        )

        // Bottom Eyelid Overlay
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxSize(eyelidHeight.value * 0.5f)
                .align(Alignment.BottomCenter)
                .background(Color.Black)
        )

        // Skip Button
        Button(
            onClick = onIntroFinished,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(24.dp)
                .testTag("intro_skip_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0x33FFFFFF),
                contentColor = HorrorMist
            ),
            shape = RoundedCornerShape(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "SKIP INTRO", fontSize = 12.sp, letterSpacing = 2.sp)
                Spacer(modifier = Modifier.width(6.dp))
                Icon(Icons.Filled.FastForward, contentDescription = "Skip Intro")
            }
        }
    }
}
