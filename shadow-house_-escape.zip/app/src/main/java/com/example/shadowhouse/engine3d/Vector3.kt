package com.example.shadowhouse.engine3d

import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class Vector3(var x: Float = 0f, var y: Float = 0f, var z: Float = 0f) {
    fun set(nx: Float, ny: Float, nz: Float): Vector3 {
        x = nx
        y = ny
        z = nz
        return this
    }

    fun add(o: Vector3): Vector3 = Vector3(x + o.x, y + o.y, z + o.z)
    fun sub(o: Vector3): Vector3 = Vector3(x - o.x, y - o.y, z - o.z)
    fun scale(s: Float): Vector3 = Vector3(x * s, y * s, z * s)

    fun length(): Float = sqrt(x * x + y * y + z * z)

    fun lengthSquared(): Float = x * x + y * y + z * z

    fun distanceTo(o: Vector3): Float = sub(o).length()

    fun distanceToSquared(o: Vector3): Float = sub(o).lengthSquared()

    fun normalize(): Vector3 {
        val len = length()
        return if (len > 0.0001f) Vector3(x / len, y / len, z / len) else Vector3(0f, 0f, 0f)
    }

    fun dot(o: Vector3): Float = x * o.x + y * o.y + z * o.z

    companion object {
        fun directionFromYawPitch(yawDeg: Float, pitchDeg: Float): Vector3 {
            val yawRad = Math.toRadians(yawDeg.toDouble())
            val pitchRad = Math.toRadians(pitchDeg.toDouble())

            val cosPitch = cos(pitchRad)
            val sinPitch = sin(pitchRad)
            val sinYaw = sin(yawRad)
            val cosYaw = cos(yawRad)

            // In our 3D coordinate system: yaw 0 is looking towards -Z
            return Vector3(
                (sinYaw * cosPitch).toFloat(),
                sinPitch.toFloat(),
                (-cosYaw * cosPitch).toFloat()
            ).normalize()
        }
    }
}
