package com.example.shadowhouse.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.example.shadowhouse.model.GameSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Random
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Procedural Horror Audio & Haptics Engine.
 * Generates custom 16-bit PCM sound effects and continuous ambient storm soundscapes
 * without requiring external mp3 assets, ensuring 100% offline reliability.
 */
class AudioManager(private val context: Context) {

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    private val sampleRate = 22050
    private val random = Random()
    private val audioScope = CoroutineScope(Dispatchers.Default)
    private var ambientJob: Job? = null
    private var ambientTrack: AudioTrack? = null

    var settings: GameSettings = GameSettings()

    fun startAmbientStorm() {
        if (ambientJob != null) return

        val minBufferSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferSize = minBufferSize.coerceAtLeast(sampleRate / 2)

        try {
            ambientTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            ambientTrack?.play()

            ambientJob = audioScope.launch {
                val pcmBuffer = ShortArray(bufferSize / 2)
                var lastSample = 0f
                var timeAcc = 0.0

                while (isActive) {
                    val ambVol = settings.masterVolume * settings.ambientVolume
                    for (i in pcmBuffer.indices) {
                        timeAcc += 1.0 / sampleRate
                        // Pink/Brown noise filtered for rain sound
                        val white = (random.nextFloat() * 2f - 1f)
                        lastSample = (lastSample + (0.05f * white)) / 1.05f

                        // Low wind drone oscillator
                        val wind = sin(2.0 * PI * (35.0 + 8.0 * sin(timeAcc * 0.2)) * timeAcc).toFloat() * 0.15f
                        val mix = (lastSample * 0.25f + wind) * ambVol
                        val clamped = mix.coerceIn(-1.0f, 1.0f)
                        pcmBuffer[i] = (clamped * 32767).toInt().toShort()
                    }
                    ambientTrack?.write(pcmBuffer, 0, pcmBuffer.size)
                }
            }
        } catch (_: Exception) {
            // Fail gracefully if device audio is restricted
        }
    }

    fun stopAmbientStorm() {
        ambientJob?.cancel()
        ambientJob = null
        try {
            ambientTrack?.stop()
            ambientTrack?.release()
        } catch (_: Exception) {}
        ambientTrack = null
    }

    private fun playPcmSound(samples: ShortArray) {
        val sfxVol = settings.masterVolume * settings.sfxVolume
        if (sfxVol <= 0.01f) return

        audioScope.launch {
            try {
                val byteBuffer = ByteBuffer.allocateDirect(samples.size * 2).order(ByteOrder.nativeOrder())
                for (s in samples) {
                    val scaled = (s * sfxVol).toInt().coerceIn(-32768, 32767).toShort()
                    byteBuffer.putShort(scaled)
                }
                byteBuffer.flip()

                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(samples.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                track.write(byteBuffer, samples.size * 2, AudioTrack.WRITE_BLOCKING)
                track.play()
                // Wait for sound to finish before releasing
                val durationMs = (samples.size * 1000L / sampleRate) + 50
                kotlinx.coroutines.delay(durationMs)
                track.release()
            } catch (_: Exception) {}
        }
    }

    fun playFootstep(isCreaky: Boolean = false) {
        val numSamples = (sampleRate * 0.12).toInt()
        val buffer = ShortArray(numSamples)
        val baseFreq = if (isCreaky) 180.0 else 90.0

        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val decay = exp(-t * 28.0)
            val noise = (random.nextFloat() * 2f - 1f) * 0.35f
            val tone = sin(2.0 * PI * baseFreq * t).toFloat()
            val sample = (((noise + tone) * decay * 0.5f).toFloat()).coerceIn(-1f, 1f)
            buffer[i] = (sample * 32767).toInt().toShort()
        }
        playPcmSound(buffer)

        if (settings.vibrationEnabled) {
            vibrate(15)
        }
    }

    fun playFlashlightClick() {
        val numSamples = (sampleRate * 0.05).toInt()
        val buffer = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val decay = exp(-t * 80.0)
            val tone = sin(2.0 * PI * 2400.0 * t).toFloat()
            val noise = (random.nextFloat() * 2f - 1f) * 0.4f
            val sample = (((tone + noise) * decay).toFloat()).coerceIn(-1f, 1f)
            buffer[i] = (sample * 32767).toInt().toShort()
        }
        playPcmSound(buffer)
        if (settings.vibrationEnabled) vibrate(20)
    }

    fun playDoorOpen() {
        val numSamples = (sampleRate * 0.7).toInt()
        val buffer = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val decay = exp(-t * 3.5)
            // Frequency modulation for eerie creaking wood
            val freq = 120.0 + 90.0 * sin(t * 35.0)
            val sample = (sin(2.0 * PI * freq * t) * decay * 0.7f).toFloat().coerceIn(-1f, 1f)
            buffer[i] = (sample * 32767).toInt().toShort()
        }
        playPcmSound(buffer)
        if (settings.vibrationEnabled) vibrate(40)
    }

    fun playDoorLocked() {
        val numSamples = (sampleRate * 0.25).toInt()
        val buffer = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val decay = exp(-((t % 0.12) * 50.0))
            val tone = sin(2.0 * PI * 340.0 * t).toFloat()
            val sample = ((tone * decay * 0.6f).toFloat()).coerceIn(-1f, 1f)
            buffer[i] = (sample * 32767).toInt().toShort()
        }
        playPcmSound(buffer)
        if (settings.vibrationEnabled) vibrate(30)
    }

    fun playItemPickup() {
        val numSamples = (sampleRate * 0.35).toInt()
        val buffer = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val decay = exp(-t * 9.0)
            val tone1 = sin(2.0 * PI * 587.33 * t) // D5
            val tone2 = sin(2.0 * PI * 880.00 * t) // A5
            val sample = ((tone1 + tone2) * 0.4 * decay).toFloat().coerceIn(-1f, 1f)
            buffer[i] = (sample * 32767).toInt().toShort()
        }
        playPcmSound(buffer)
        if (settings.vibrationEnabled) vibrate(25)
    }

    fun playThunder() {
        val numSamples = (sampleRate * 2.2).toInt()
        val buffer = ShortArray(numSamples)
        var lp = 0f
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val decay = exp(-t * 1.8)
            val white = (random.nextFloat() * 2f - 1f)
            lp = lp + 0.12f * (white - lp)
            val subBass = sin(2.0 * PI * 45.0 * t).toFloat() * 0.4f
            val sample = (((lp * 0.8f + subBass) * decay).toFloat()).coerceIn(-1f, 1f)
            buffer[i] = (sample * 32767).toInt().toShort()
        }
        playPcmSound(buffer)
        if (settings.vibrationEnabled) {
            vibrate(120)
        }
    }

    fun playHeartbeat() {
        val numSamples = (sampleRate * 0.45).toInt()
        val buffer = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            // Lub-dub double pulse
            val pulse1 = exp(-t * 25.0) * sin(2.0 * PI * 55.0 * t)
            val pulse2 = if (t > 0.16) exp(-(t - 0.16) * 30.0) * sin(2.0 * PI * 48.0 * (t - 0.16)) else 0.0
            val sample = ((pulse1 + pulse2) * 0.85).toFloat().coerceIn(-1f, 1f)
            buffer[i] = (sample * 32767).toInt().toShort()
        }
        playPcmSound(buffer)
        if (settings.vibrationEnabled) {
            vibrate(45)
        }
    }

    fun playSwitchClick() {
        val numSamples = (sampleRate * 0.18).toInt()
        val buffer = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val decay = exp(-t * 35.0)
            val clunk = sin(2.0 * PI * 220.0 * t).toFloat() * 0.6f
            val spark = (random.nextFloat() * 2f - 1f) * 0.4f
            val sample = (((clunk + spark) * decay).toFloat()).coerceIn(-1f, 1f)
            buffer[i] = (sample * 32767).toInt().toShort()
        }
        playPcmSound(buffer)
        if (settings.vibrationEnabled) vibrate(35)
    }

    fun playCreatureAlert() {
        val numSamples = (sampleRate * 1.5).toInt()
        val buffer = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val decay = exp(-t * 1.2)
            // Sinister pitch modulation
            val freq = 280.0 + 80.0 * sin(2.0 * PI * 6.0 * t)
            val sub = sin(2.0 * PI * 65.0 * t) * 0.5
            val noise = (random.nextFloat() * 2f - 1f) * 0.2f
            val sample = ((sin(2.0 * PI * freq * t) * 0.5 + sub + noise) * decay).toFloat().coerceIn(-1f, 1f)
            buffer[i] = (sample * 32767).toInt().toShort()
        }
        playPcmSound(buffer)
        if (settings.vibrationEnabled) vibrate(90)
    }

    fun playCreatureScreech() {
        val numSamples = (sampleRate * 1.8).toInt()
        val buffer = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val decay = exp(-t * 2.0)
            val freq = 900.0 - 400.0 * t + 120.0 * sin(t * 80.0)
            val scream = sin(2.0 * PI * freq * t) + 0.4 * sin(2.0 * PI * (freq * 1.5) * t)
            val noise = (random.nextFloat() * 2f - 1f) * 0.35f
            val sample = ((scream + noise) * decay * 0.8f).toFloat().coerceIn(-1f, 1f)
            buffer[i] = (sample * 32767).toInt().toShort()
        }
        playPcmSound(buffer)
        if (settings.vibrationEnabled) vibrate(150)
    }

    fun vibrate(durationMs: Long) {
        if (!settings.vibrationEnabled) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(durationMs)
            }
        } catch (_: Exception) {}
    }

    fun release() {
        stopAmbientStorm()
    }
}
