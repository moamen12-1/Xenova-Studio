package com.example.shadowhouse.model

enum class EndingType(val title: String, val description: String) {
    NONE("", ""),
    ENDING_A_ESCAPE(
        "The Escape",
        "You reached the heavy front gate, turned the master key, and burst through into the howling storm. The nightmare of Blackwood Manor is behind you, though its shadows will forever haunt your memory."
    ),
    ENDING_B_HIDDEN_TRUTH(
        "The Hidden Truth",
        "You uncovered the hidden study and read Dr. Blackwood's desperate confession. You escaped into the dawn, carrying the truth of William's tragic transformation and the sorrow that cursed this manor."
    ),
    ENDING_C_CAUGHT(
        "Consumed by Shadows",
        "The icy darkness closed in. You felt a terrifying chill down your spine as shadowy hands dragged you into the abyss. The house claims another soul..."
    )
}

enum class CreatureBehaviorState {
    PATROL,
    INVESTIGATE,
    STALK,
    CHASE,
    VANISHED
}

data class CreatureData(
    var posX: Float = 0f,
    var posY: Float = 0f,
    var posZ: Float = -15f,
    var targetX: Float = 0f,
    var targetZ: Float = 0f,
    var state: CreatureBehaviorState = CreatureBehaviorState.PATROL,
    var alertLevel: Float = 0f,     // 0.0 to 1.0 (triggers chase at 1.0)
    var chaseTimer: Float = 0f,     // chase duration in seconds
    var distanceToPlayer: Float = 20f,
    var isVisible: Boolean = false
)

data class PlayerData(
    var posX: Float = 0f,
    var posY: Float = 1.6f,         // Eye level standing: 1.6m, crouching: 0.9m
    var posZ: Float = 2f,
    var yaw: Float = 180f,          // In degrees
    var pitch: Float = 0f,          // In degrees
    var isCrouching: Boolean = false,
    var isRunning: Boolean = false,
    var isHiding: Boolean = false,  // Inside wardrobe / closet
    var stamina: Float = 100f,
    var flashlightOn: Boolean = true,
    var batteryPercentage: Float = 85f,
    var currentNoiseLevel: Float = 0f // 0 = silent, 0.3 = walk, 0.9 = run
)

data class GameProgress(
    val inventory: MutableList<InventoryItem> = mutableListOf(),
    var currentRoomName: String = "Entrance Foyer",
    var currentObjective: String = "Explore the house. Find a way to unlock the front gate.",
    var bathroomKeyPickedUp: Boolean = false,
    var bedroomDoorUnlocked: Boolean = false,
    var storageSafeUnlocked: Boolean = false,
    var basementDoorUnlocked: Boolean = false,
    var fusePickedUp: Boolean = false,
    var fuseInstalled: Boolean = false,
    var breakerSwitchesState: List<Boolean> = listOf(false, false, false, false),
    var breakerSolved: Boolean = false,
    var secretPassageOpened: Boolean = false,
    var occultConfessionRead: Boolean = false,
    var exitGateUnlocked: Boolean = false,
    var secondsSurvived: Int = 0,
    var checkpointsPassed: Int = 0,
    var activeEnding: EndingType = EndingType.NONE
)
