package com.example.shadowhouse.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.HorrorAmber
import com.example.ui.theme.HorrorBlack
import com.example.ui.theme.HorrorCrimson
import com.example.ui.theme.HorrorMist
import com.example.ui.theme.HorrorWhite
import java.util.Random

@Composable
fun MainMenuScreen(
    hasSavedGame: Boolean,
    onPlayNewGame: () -> Unit,
    onContinueGame: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenAbout: () -> Unit,
    onExitApp: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "menu_atmosphere")

    // Subtle fog breathing animation
    val fogAlpha by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.55f,
        animationSpec = infiniteRepeatable(
            animation = tween(4500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "fog_alpha"
    )

    // Lightning flash animation
    val lightningAlpha by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(7000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "lightning_timer"
    )
    val isLightning = lightningAlpha > 0.94f && lightningAlpha < 0.97f

    // Animated rain lines
    val rainOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rain_offset"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(HorrorBlack)
            .testTag("main_menu_container")
    ) {
        // Background mansion artwork
        Image(
            painter = painterResource(id = R.drawable.shadow_house_menu_bg),
            contentDescription = "Shadow House Exterior",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Dark gradient vignette
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color(0xCC080B10),
                            Color(0xF5080B10)
                        ),
                        radius = 1200f
                    )
                )
        )

        // Animated Fog Layer
        Box(
            modifier = Modifier
                .fillMaxSize()
                .alpha(fogAlpha)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color(0x44262E3B),
                            Color(0xAA12161E)
                        )
                    )
                )
        )

        // Lightning Flash overlay
        if (isLightning) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x66DDEEFF))
            )
        }

        // Rain particle canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val rand = Random(42)
            val dropColor = Color(0x55B0C4DE)
            for (i in 0..70) {
                val rx = rand.nextFloat() * size.width
                val startY = ((rand.nextFloat() + rainOffset) % 1f) * size.height
                val dropLen = 25f + rand.nextFloat() * 35f
                drawLine(
                    color = dropColor,
                    start = Offset(rx, startY),
                    end = Offset(rx - 8f, startY + dropLen),
                    strokeWidth = 1.5f
                )
            }
        }

        // Menu Content Container
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 48.dp, vertical = 24.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left Column: Game Title & Atmospheric Lore
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 32.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = stringResource(id = R.string.game_title),
                    fontSize = 42.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Serif,
                    color = HorrorWhite,
                    letterSpacing = 6.sp,
                    lineHeight = 44.sp
                )
                Text(
                    text = stringResource(id = R.string.game_subtitle),
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = HorrorAmber,
                    letterSpacing = 8.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Box(
                    modifier = Modifier
                        .width(180.dp)
                        .height(2.dp)
                        .background(
                            Brush.horizontalGradient(
                                listOf(HorrorCrimson, HorrorAmber, Color.Transparent)
                            )
                        )
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "A storm rages outside. The doors are locked.\nFind the keys. Solve the puzzles.\nDo not let the creature find you.",
                    fontSize = 14.sp,
                    color = HorrorMist,
                    lineHeight = 22.sp,
                    modifier = Modifier.widthIn(max = 420.dp)
                )
            }

            // Right Column: Navigation Buttons
            Column(
                modifier = Modifier
                    .width(260.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Continue Button (if save exists)
                if (hasSavedGame) {
                    Button(
                        onClick = onContinueGame,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("menu_continue_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = HorrorAmber,
                            contentColor = HorrorBlack
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Filled.Restore, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
                        Text(
                            text = stringResource(id = R.string.play_continue),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp
                        )
                    }
                }

                // New Game Button
                Button(
                    onClick = onPlayNewGame,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("menu_play_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (hasSavedGame) HorrorCrimson else HorrorAmber,
                        contentColor = if (hasSavedGame) HorrorWhite else HorrorBlack
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
                    Text(
                        text = stringResource(id = R.string.play_new_game),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                }

                // Settings Button
                OutlinedButton(
                    onClick = onOpenSettings,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("menu_settings_button"),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = HorrorWhite
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Filled.Settings, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
                    Text(
                        text = stringResource(id = R.string.menu_settings),
                        fontSize = 14.sp,
                        letterSpacing = 2.sp
                    )
                }

                // About Button
                OutlinedButton(
                    onClick = onOpenAbout,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("menu_about_button"),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = HorrorWhite
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Filled.Info, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
                    Text(
                        text = stringResource(id = R.string.menu_about),
                        fontSize = 14.sp,
                        letterSpacing = 2.sp
                    )
                }

                // Exit Button
                OutlinedButton(
                    onClick = onExitApp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("menu_exit_button"),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = HorrorMist
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = stringResource(id = R.string.menu_exit),
                        fontSize = 13.sp,
                        letterSpacing = 2.sp
                    )
                }
            }
        }
    }
}
