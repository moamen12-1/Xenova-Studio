package com.example

import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.shadowhouse.game.GameManager
import com.example.shadowhouse.model.EndingType
import com.example.shadowhouse.ui.AboutScreen
import com.example.shadowhouse.ui.EndingScreen
import com.example.shadowhouse.ui.GameScreen
import com.example.shadowhouse.ui.IntroScreen
import com.example.shadowhouse.ui.MainMenuScreen
import com.example.shadowhouse.ui.SettingsScreen
import com.example.ui.theme.HorrorBlack
import com.example.ui.theme.MyApplicationTheme

enum class ScreenState {
    MAIN_MENU,
    INTRO,
    GAME,
    SETTINGS,
    ABOUT,
    ENDING
}

class MainActivity : ComponentActivity() {

    private lateinit var gameManager: GameManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        hideSystemUI()

        gameManager = GameManager(this)

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = HorrorBlack
                ) {
                    AppNavigation(gameManager, onExitApp = { finish() })
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        hideSystemUI()
        if (::gameManager.isInitialized && !gameManager.isPaused) {
            gameManager.audioManager.startAmbientStorm()
        }
    }

    override fun onPause() {
        super.onPause()
        if (::gameManager.isInitialized) {
            gameManager.audioManager.stopAmbientStorm()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::gameManager.isInitialized) {
            gameManager.stopGame()
            gameManager.audioManager.release()
        }
    }

    private fun hideSystemUI() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
            )
        }
    }
}

@Composable
fun AppNavigation(
    gameManager: GameManager,
    onExitApp: () -> Unit
) {
    var currentScreen by remember { mutableStateOf(ScreenState.MAIN_MENU) }
    var previousScreen by remember { mutableStateOf(ScreenState.MAIN_MENU) }

    // Check ending state transition
    if (gameManager.endingState != EndingType.NONE && currentScreen == ScreenState.GAME) {
        currentScreen = ScreenState.ENDING
    }

    when (currentScreen) {
        ScreenState.MAIN_MENU -> {
            MainMenuScreen(
                hasSavedGame = gameManager.saveSystem.hasSavedGame(),
                onPlayNewGame = {
                    currentScreen = ScreenState.INTRO
                },
                onContinueGame = {
                    val loaded = gameManager.continueSavedGame()
                    if (loaded) {
                        currentScreen = ScreenState.GAME
                    } else {
                        currentScreen = ScreenState.INTRO
                    }
                },
                onOpenSettings = {
                    previousScreen = ScreenState.MAIN_MENU
                    currentScreen = ScreenState.SETTINGS
                },
                onOpenAbout = {
                    currentScreen = ScreenState.ABOUT
                },
                onExitApp = onExitApp
            )
        }

        ScreenState.INTRO -> {
            BackHandler {
                gameManager.stopGame()
                currentScreen = ScreenState.MAIN_MENU
            }
            IntroScreen(
                audioManager = gameManager.audioManager,
                onIntroFinished = {
                    gameManager.startNewGame()
                    currentScreen = ScreenState.GAME
                }
            )
        }

        ScreenState.GAME -> {
            BackHandler {
                // Pause game rather than instant exit
                gameManager.isPaused = true
            }
            GameScreen(
                gameManager = gameManager,
                onOpenSettings = {
                    previousScreen = ScreenState.GAME
                    currentScreen = ScreenState.SETTINGS
                },
                onReturnToMenu = {
                    gameManager.stopGame()
                    currentScreen = ScreenState.MAIN_MENU
                }
            )
        }

        ScreenState.SETTINGS -> {
            BackHandler {
                currentScreen = previousScreen
            }
            SettingsScreen(
                currentSettings = gameManager.settings,
                onSaveSettings = { updated ->
                    gameManager.updateSettings(updated)
                },
                onResetProgress = {
                    gameManager.saveSystem.clearSavedGame()
                },
                onBack = {
                    currentScreen = previousScreen
                }
            )
        }

        ScreenState.ABOUT -> {
            BackHandler {
                currentScreen = ScreenState.MAIN_MENU
            }
            AboutScreen(
                onBack = {
                    currentScreen = ScreenState.MAIN_MENU
                }
            )
        }

        ScreenState.ENDING -> {
            BackHandler {
                gameManager.stopGame()
                currentScreen = ScreenState.MAIN_MENU
            }
            EndingScreen(
                endingType = gameManager.endingState,
                gameProgress = gameManager.gameProgress,
                onRetryCheckpoint = {
                    val loaded = gameManager.continueSavedGame()
                    if (loaded) {
                        currentScreen = ScreenState.GAME
                    } else {
                        gameManager.startNewGame()
                        currentScreen = ScreenState.GAME
                    }
                },
                onReturnToMenu = {
                    gameManager.stopGame()
                    currentScreen = ScreenState.MAIN_MENU
                }
            )
        }
    }
}
