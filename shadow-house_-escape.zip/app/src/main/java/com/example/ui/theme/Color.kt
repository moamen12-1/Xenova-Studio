package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val HorrorBlack = Color(0xFF080B10)
val HorrorSurface = Color(0xFF12161E)
val HorrorSurfaceVariant = Color(0xFF1B222D)
val HorrorDarkGray = Color(0xFF262E3B)
val HorrorMutedGreen = Color(0xFF2E4035)
val HorrorBrown = Color(0xFF3D2F24)
val HorrorAmber = Color(0xFFFFB03B)
val HorrorCrimson = Color(0xFF8B1E2B)
val HorrorBloodRed = Color(0xFFD32F2F)
val HorrorMist = Color(0xFF8E9BAE)
val HorrorWhite = Color(0xFFE8EDF5)
