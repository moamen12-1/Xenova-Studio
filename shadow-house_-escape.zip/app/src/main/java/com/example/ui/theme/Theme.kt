package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val HorrorColorScheme = darkColorScheme(
    primary = HorrorAmber,
    onPrimary = HorrorBlack,
    primaryContainer = HorrorBrown,
    onPrimaryContainer = HorrorAmber,
    secondary = HorrorCrimson,
    onSecondary = HorrorWhite,
    tertiary = HorrorMutedGreen,
    background = HorrorBlack,
    surface = HorrorSurface,
    surfaceVariant = HorrorSurfaceVariant,
    onBackground = HorrorWhite,
    onSurface = HorrorWhite,
    onSurfaceVariant = HorrorMist,
    error = HorrorBloodRed
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = HorrorColorScheme,
        typography = Typography,
        content = content
    )
}
