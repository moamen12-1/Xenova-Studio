package com.example.sanxstudio.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.sanxstudio.data.db.SanXDatabase
import com.example.sanxstudio.data.model.ProjectEntity
import com.example.sanxstudio.data.repository.PreferencesRepository
import com.example.sanxstudio.data.repository.SanXRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeUiState(
    val projects: List<ProjectEntity> = emptyList(),
    val projectCount: Int = 0,
    val ideaCount: Int = 0,
    val scriptCount: Int = 0,
    val favoriteCount: Int = 0,
    val isLoading: Boolean = false
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {
    private val database = SanXDatabase.getInstance(application)
    private val repository = SanXRepository(
        database.projectDao(),
        database.ideaDao(),
        database.scriptDao(),
        database.favoriteDao(),
        database.analyticsDao(),
        database.calendarDao()
    )

    val uiState: StateFlow<HomeUiState> = combine(
        repository.allProjects,
        repository.projectCount,
        repository.ideaCount,
        repository.scriptCount,
        repository.favoriteCount
    ) { projects, pCount, iCount, sCount, fCount ->
        HomeUiState(
            projects = projects.take(5),
            projectCount = pCount,
            ideaCount = iCount,
            scriptCount = sCount,
            favoriteCount = fCount,
            isLoading = false
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = HomeUiState(isLoading = true)
    )

    init {
        viewModelScope.launch {
            repository.checkAndSeedSampleDataIfNeeded()
        }
    }

    fun toggleFavorite(project: ProjectEntity) {
        viewModelScope.launch {
            repository.toggleProjectFavorite(project)
        }
    }

    fun deleteProject(project: ProjectEntity) {
        viewModelScope.launch {
            repository.deleteProject(project)
        }
    }
}
