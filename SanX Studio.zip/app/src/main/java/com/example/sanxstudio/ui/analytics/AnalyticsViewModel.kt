package com.example.sanxstudio.ui.analytics

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.sanxstudio.data.db.SanXDatabase
import com.example.sanxstudio.data.model.AnalyticsEntity
import com.example.sanxstudio.data.repository.SanXRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class CalculatedStats(
    val averageViews: Long = 0,
    val totalViews: Long = 0,
    val totalLikes: Long = 0,
    val totalComments: Long = 0,
    val bestPerformingGame: String = "N/A",
    val bestPerformingPlatform: String = "N/A",
    val averageEngagementRate: Double = 0.0,
    val videoCount: Int = 0
)

class AnalyticsViewModel(application: Application) : AndroidViewModel(application) {
    private val database = SanXDatabase.getInstance(application)
    private val repository = SanXRepository(
        database.projectDao(),
        database.ideaDao(),
        database.scriptDao(),
        database.favoriteDao(),
        database.analyticsDao(),
        database.calendarDao()
    )

    val logs: StateFlow<List<AnalyticsEntity>> = repository.allAnalytics
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val calculatedStats: StateFlow<CalculatedStats> = logs.map { list ->
        if (list.isEmpty()) {
            CalculatedStats()
        } else {
            val totalViews = list.sumOf { it.views }
            val totalLikes = list.sumOf { it.likes }
            val totalComments = list.sumOf { it.comments }
            val avgViews = totalViews / list.size

            val bestGame = list.groupBy { it.game }
                .maxByOrNull { entry -> entry.value.sumOf { it.views } }?.key ?: "N/A"

            val bestPlatform = list.groupBy { it.platform }
                .maxByOrNull { entry -> entry.value.sumOf { it.views } }?.key ?: "N/A"

            val engagement = if (totalViews > 0) {
                ((totalLikes + totalComments).toDouble() / totalViews.toDouble()) * 100.0
            } else {
                0.0
            }

            CalculatedStats(
                averageViews = avgViews,
                totalViews = totalViews,
                totalLikes = totalLikes,
                totalComments = totalComments,
                bestPerformingGame = bestGame,
                bestPerformingPlatform = bestPlatform,
                averageEngagementRate = engagement,
                videoCount = list.size
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = CalculatedStats()
    )

    init {
        // Seed initial creator benchmark if empty
        viewModelScope.launch {
            if (repository.projectCount.first() == 0) {
                repository.insertAnalytics(
                    AnalyticsEntity(
                        title = "Top 5 Secret Vehicles in GTA",
                        platform = "YouTube Shorts",
                        game = "GTA San Andreas",
                        views = 28400,
                        likes = 3120,
                        comments = 184,
                        retentionPercent = 84.5f
                    )
                )
            }
        }
    }

    fun addLog(
        title: String,
        platform: String,
        game: String,
        views: Long,
        likes: Long,
        comments: Long,
        retentionPercent: Float,
        notes: String
    ) {
        viewModelScope.launch {
            repository.insertAnalytics(
                AnalyticsEntity(
                    title = title,
                    platform = platform,
                    game = game,
                    views = views,
                    likes = likes,
                    comments = comments,
                    retentionPercent = retentionPercent,
                    notes = notes
                )
            )
        }
    }

    fun deleteLog(log: AnalyticsEntity) {
        viewModelScope.launch {
            repository.deleteAnalytics(log)
        }
    }
}
