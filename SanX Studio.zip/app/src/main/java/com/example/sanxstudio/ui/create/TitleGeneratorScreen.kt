package com.example.sanxstudio.ui.create

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.sanxstudio.data.ai.TitleOption
import com.example.sanxstudio.ui.components.LoadingStateView
import com.example.sanxstudio.ui.components.SanXButton
import com.example.sanxstudio.ui.components.SanXCard
import com.example.sanxstudio.ui.components.SanXSecondaryButton
import com.example.sanxstudio.ui.components.SanXTopBar
import com.example.sanxstudio.ui.localization.LocalStrings
import com.example.sanxstudio.ui.projects.FilterChip
import com.example.ui.theme.SanXBlack
import com.example.ui.theme.SanXCardBorder
import com.example.ui.theme.SanXCyan
import com.example.ui.theme.SanXGold
import com.example.ui.theme.SanXNeonGreen
import com.example.ui.theme.SanXPurple
import com.example.ui.theme.SanXRed
import com.example.ui.theme.SanXSurface
import com.example.ui.theme.SanXSurfaceVariant
import com.example.ui.theme.SanXTextMuted
import com.example.ui.theme.SanXTextWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TitleGeneratorScreen(
    initialProjectId: Long? = null,
    onBack: () -> Unit,
    onNavigateToSettings: () -> Unit,
    viewModel: CreateViewModel = viewModel()
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val strings = LocalStrings.current
    val state by viewModel.titleState.collectAsState()

    var game by remember { mutableStateOf("FC 25") }
    var topic by remember { mutableStateOf("Secret Penalty Trick That Never Misses") }
    var selectedCategory by remember { mutableStateOf("All Categories") }
    var selectedLanguage by remember { mutableStateOf("en") }

    val categories = listOf("All Categories", "Curiosity", "Mystery", "Horror", "Viral-style", "Professional", "Short", "Dramatic")

    fun runGenerate() {
        viewModel.generateTitles(game, topic, selectedCategory, selectedLanguage)
    }

    Scaffold(
        topBar = {
            SanXTopBar(
                title = strings.titleStudioTitle,
                showBack = true,
                onBackClick = onBack,
                onSettingsClick = onNavigateToSettings
            )
        },
        containerColor = SanXBlack
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                SanXCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Title Studio Controls", fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 15.sp)

                        OutlinedTextField(
                            value = topic,
                            onValueChange = { topic = it },
                            label = { Text(strings.topicLabel) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SanXNeonGreen,
                                unfocusedBorderColor = SanXCardBorder,
                                focusedTextColor = SanXTextWhite,
                                unfocusedTextColor = SanXTextWhite
                            )
                        )

                        OutlinedTextField(
                            value = game,
                            onValueChange = { game = it },
                            label = { Text(strings.gameLabel) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SanXNeonGreen,
                                unfocusedBorderColor = SanXCardBorder,
                                focusedTextColor = SanXTextWhite,
                                unfocusedTextColor = SanXTextWhite
                            )
                        )

                        // Categories
                        Column {
                            Text("Category Focus", fontSize = 12.sp, color = SanXTextMuted)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                categories.forEach { cat ->
                                    FilterChip(
                                        text = cat,
                                        isSelected = selectedCategory == cat,
                                        onClick = { selectedCategory = cat }
                                    )
                                }
                            }
                        }

                        // Language
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                text = "English",
                                isSelected = selectedLanguage == "en",
                                onClick = { selectedLanguage = "en" }
                            )
                            FilterChip(
                                text = "العربية (Arabic)",
                                isSelected = selectedLanguage == "ar",
                                onClick = { selectedLanguage = "ar" }
                            )
                        }

                        SanXButton(
                            text = "Generate High-CTR Titles",
                            onClick = { runGenerate() },
                            icon = Icons.Default.AutoAwesome,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            when (val current = state) {
                is GeneratorState.Idle -> {}
                is GeneratorState.Loading -> {
                    item { LoadingStateView(message = "Brainstorming clickable titles...") }
                }
                is GeneratorState.NotConfigured -> {
                    item {
                        SanXCard(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(strings.aiNotConfiguredTitle, fontWeight = FontWeight.Bold, color = SanXTextWhite)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(current.message, color = SanXTextMuted, fontSize = 13.sp)
                                Spacer(modifier = Modifier.height(14.dp))
                                SanXButton(text = strings.goToSettings, onClick = onNavigateToSettings)
                            }
                        }
                    }
                }
                is GeneratorState.Error -> {
                    item {
                        SanXCard(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Title Error", color = SanXRed, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(current.message, color = SanXTextMuted, fontSize = 13.sp)
                            }
                        }
                    }
                }
                is GeneratorState.Success -> {
                    item {
                        Text("Suggested Titles", fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 16.sp)
                    }

                    items(current.data) { titleOpt ->
                        TitleItemCard(
                            titleOption = titleOpt,
                            onCopy = {
                                clipboardManager.setText(AnnotatedString(titleOpt.title))
                                Toast.makeText(context, strings.copied, Toast.LENGTH_SHORT).show()
                            },
                            onFavorite = {
                                viewModel.saveTitleToFavorites(titleOpt.title, titleOpt.category)
                                Toast.makeText(context, "Saved to Favorites!", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

@Composable
private fun TitleItemCard(
    titleOption: TitleOption,
    onCopy: () -> Unit,
    onFavorite: () -> Unit
) {
    var isFavorited by remember { mutableStateOf(false) }

    SanXCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = SanXSurfaceVariant,
                    border = BorderStroke(0.8.dp, SanXCyan.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = titleOption.category,
                        color = SanXCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                Row {
                    IconButton(
                        onClick = {
                            isFavorited = !isFavorited
                            onFavorite()
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (isFavorited) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = "Favorite",
                            tint = if (isFavorited) SanXGold else SanXTextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(onClick = onCopy, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = SanXNeonGreen, modifier = Modifier.size(18.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = titleOption.title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = SanXTextWhite,
                lineHeight = 20.sp
            )
        }
    }
}
