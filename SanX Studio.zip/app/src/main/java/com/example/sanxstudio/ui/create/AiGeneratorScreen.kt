package com.example.sanxstudio.ui.create

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.sanxstudio.data.ai.FullContentResult
import com.example.sanxstudio.data.model.ContentTone
import com.example.sanxstudio.ui.components.EmptyStateView
import com.example.sanxstudio.ui.components.LoadingStateView
import com.example.sanxstudio.ui.components.SanXButton
import com.example.sanxstudio.ui.components.SanXCard
import com.example.sanxstudio.ui.components.SanXSecondaryButton
import com.example.sanxstudio.ui.components.SanXTopBar
import com.example.sanxstudio.ui.localization.LocalStrings
import com.example.sanxstudio.ui.projects.FilterChip
import com.example.ui.theme.SanXBlack
import com.example.ui.theme.SanXCardBorder
import com.example.ui.theme.SanXCyan
import com.example.ui.theme.SanXNeonGreen
import com.example.ui.theme.SanXRed
import com.example.ui.theme.SanXSurface
import com.example.ui.theme.SanXSurfaceVariant
import com.example.ui.theme.SanXTextDim
import com.example.ui.theme.SanXTextMuted
import com.example.ui.theme.SanXTextWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiGeneratorScreen(
    initialProjectId: Long? = null,
    onBack: () -> Unit,
    onNavigateToSettings: () -> Unit,
    viewModel: CreateViewModel = viewModel()
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val strings = LocalStrings.current
    val state by viewModel.fullContentState.collectAsState()

    var game by remember { mutableStateOf("GTA San Andreas") }
    var topic by remember { mutableStateOf("Secret motorcycle on Las Venturas roof") }
    var selectedTone by remember { mutableStateOf(ContentTone.ENERGETIC.name) }
    var selectedDuration by remember { mutableIntStateOf(45) }
    var selectedPlatform by remember { mutableStateOf("YouTube Shorts") }
    var selectedLanguage by remember { mutableStateOf("en") }

    val durations = listOf(30, 45, 60, 180, 300, 600)
    val platforms = listOf("YouTube Shorts", "TikTok", "Instagram Reels", "YouTube Video")

    fun triggerGeneration() {
        viewModel.generateFullContent(
            game = game,
            topic = topic,
            tone = selectedTone,
            durationSeconds = selectedDuration,
            platform = selectedPlatform,
            language = selectedLanguage
        )
    }

    Scaffold(
        topBar = {
            SanXTopBar(
                title = strings.aiGeneratorTitle,
                showBack = true,
                onBackClick = onBack,
                onSettingsClick = onNavigateToSettings
            )
        },
        containerColor = SanXBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Input Controls Card
            SanXCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("Content Parameters", fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 15.sp)

                    // Game Input
                    OutlinedTextField(
                        value = game,
                        onValueChange = { game = it },
                        label = { Text(strings.gameLabel) },
                        modifier = Modifier.fillMaxWidth().testTag("ai_game_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SanXNeonGreen,
                            unfocusedBorderColor = SanXCardBorder,
                            focusedTextColor = SanXTextWhite,
                            unfocusedTextColor = SanXTextWhite
                        ),
                        singleLine = true
                    )

                    // Topic Input
                    OutlinedTextField(
                        value = topic,
                        onValueChange = { topic = it },
                        label = { Text(strings.topicLabel) },
                        placeholder = { Text(strings.topicHint, color = SanXTextDim) },
                        modifier = Modifier.fillMaxWidth().testTag("ai_topic_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SanXNeonGreen,
                            unfocusedBorderColor = SanXCardBorder,
                            focusedTextColor = SanXTextWhite,
                            unfocusedTextColor = SanXTextWhite
                        ),
                        singleLine = true
                    )

                    // Tone Row
                    Column {
                        Text(strings.toneLabel, fontSize = 12.sp, color = SanXTextMuted)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            ContentTone.values().forEach { tone ->
                                FilterChip(
                                    text = tone.displayName,
                                    isSelected = selectedTone == tone.name,
                                    onClick = { selectedTone = tone.name }
                                )
                            }
                        }
                    }

                    // Duration Row
                    Column {
                        Text(strings.durationLabel, fontSize = 12.sp, color = SanXTextMuted)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            durations.forEach { dur ->
                                FilterChip(
                                    text = if (dur >= 60) "${dur / 60}m" else "${dur}s",
                                    isSelected = selectedDuration == dur,
                                    onClick = { selectedDuration = dur }
                                )
                            }
                        }
                    }

                    // Platform Row
                    Column {
                        Text(strings.platformLabel, fontSize = 12.sp, color = SanXTextMuted)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            platforms.forEach { plat ->
                                FilterChip(
                                    text = plat,
                                    isSelected = selectedPlatform == plat,
                                    onClick = { selectedPlatform = plat }
                                )
                            }
                        }
                    }

                    // Language Row
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            text = "English",
                            isSelected = selectedLanguage == "en",
                            onClick = { selectedLanguage = "en" }
                        )
                        FilterChip(
                            text = "العربية (Arabic)",
                            isSelected = selectedLanguage == "ar",
                            onClick = { selectedLanguage = "ar" }
                        )
                    }

                    // Generate Button
                    SanXButton(
                        text = strings.generateButton,
                        onClick = { triggerGeneration() },
                        icon = Icons.Default.AutoAwesome,
                        modifier = Modifier.fillMaxWidth().testTag("generate_full_content_button")
                    )
                }
            }

            // Results Section
            when (val current = state) {
                is GeneratorState.Idle -> {
                    // Nothing yet
                }
                is GeneratorState.Loading -> {
                    LoadingStateView(message = strings.preparingContent)
                }
                is GeneratorState.NotConfigured -> {
                    SanXCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.Settings, contentDescription = null, tint = SanXCyan, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = strings.aiNotConfiguredTitle,
                                fontWeight = FontWeight.Bold,
                                color = SanXTextWhite,
                                fontSize = 16.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = current.message,
                                color = SanXTextMuted,
                                fontSize = 13.sp,
                                lineHeight = 18.sp
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            SanXButton(
                                text = strings.goToSettings,
                                onClick = onNavigateToSettings,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
                is GeneratorState.Error -> {
                    SanXCard(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Generation Error", fontWeight = FontWeight.Bold, color = SanXRed, fontSize = 15.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(current.message, color = SanXTextMuted, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            SanXSecondaryButton(text = "Try Again", onClick = { triggerGeneration() })
                        }
                    }
                }
                is GeneratorState.Success -> {
                    val data = current.data
                    Text("Generated Content Suite", fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 17.sp)

                    // 1. Hook
                    ContentSectionCard(
                        title = "1. Opening Hook (0-5s)",
                        content = data.hook,
                        onCopy = {
                            clipboardManager.setText(AnnotatedString(data.hook))
                            Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                        },
                        onRegenerate = { triggerGeneration() }
                    )

                    // 2. Video Idea
                    ContentSectionCard(
                        title = "2. Video Concept & Angle",
                        content = data.videoIdea,
                        onCopy = {
                            clipboardManager.setText(AnnotatedString(data.videoIdea))
                            Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                        },
                        onRegenerate = { triggerGeneration() }
                    )

                    // 3. Full Script
                    ContentSectionCard(
                        title = "3. Complete Gaming Script",
                        content = data.fullScript,
                        onCopy = {
                            clipboardManager.setText(AnnotatedString(data.fullScript))
                            Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                        },
                        onRegenerate = { triggerGeneration() }
                    )

                    // 4. Title
                    ContentSectionCard(
                        title = "4. Clickable Title",
                        content = data.title,
                        onCopy = {
                            clipboardManager.setText(AnnotatedString(data.title))
                            Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                        },
                        onRegenerate = { triggerGeneration() }
                    )

                    // 5. Description
                    ContentSectionCard(
                        title = "5. Video Description",
                        content = data.description,
                        onCopy = {
                            clipboardManager.setText(AnnotatedString(data.description))
                            Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                        },
                        onRegenerate = { triggerGeneration() }
                    )

                    // 6. Hashtags
                    ContentSectionCard(
                        title = "6. Targeted Hashtags",
                        content = data.hashtags,
                        onCopy = {
                            clipboardManager.setText(AnnotatedString(data.hashtags))
                            Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                        },
                        onRegenerate = { triggerGeneration() }
                    )

                    // 7. Keywords
                    ContentSectionCard(
                        title = "7. SEO Keywords",
                        content = data.keywords,
                        onCopy = {
                            clipboardManager.setText(AnnotatedString(data.keywords))
                            Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                        },
                        onRegenerate = { triggerGeneration() }
                    )

                    // 8. Thumbnail Concept
                    ContentSectionCard(
                        title = "8. Thumbnail Composition & Art Direction",
                        content = data.thumbnailConcept,
                        onCopy = {
                            clipboardManager.setText(AnnotatedString(data.thumbnailConcept))
                            Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                        },
                        onRegenerate = { triggerGeneration() }
                    )

                    // 9. Thumbnail Prompt
                    ContentSectionCard(
                        title = "9. Image Generator Prompt (AI Art)",
                        content = data.thumbnailPrompt,
                        onCopy = {
                            clipboardManager.setText(AnnotatedString(data.thumbnailPrompt))
                            Toast.makeText(context, strings.promptCopied, Toast.LENGTH_SHORT).show()
                        },
                        onRegenerate = { triggerGeneration() }
                    )

                    // 10. Call to Action
                    ContentSectionCard(
                        title = "10. Call To Action (CTA)",
                        content = data.callToAction,
                        onCopy = {
                            clipboardManager.setText(AnnotatedString(data.callToAction))
                            Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                        },
                        onRegenerate = { triggerGeneration() }
                    )

                    if (initialProjectId != null) {
                        SanXButton(
                            text = "Apply All to Current Project",
                            onClick = {
                                viewModel.applyFullContentToProject(initialProjectId, data) {
                                    Toast.makeText(context, "Applied to project successfully!", Toast.LENGTH_SHORT).show()
                                    onBack()
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
fun ContentSectionCard(
    title: String,
    content: String,
    onCopy: () -> Unit,
    onRegenerate: (() -> Unit)? = null,
    onSave: (() -> Unit)? = null
) {
    var isEditing by remember { mutableStateOf(false) }
    var editedContent by remember { mutableStateOf(content) }

    SanXCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    color = SanXNeonGreen,
                    fontSize = 14.sp
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { isEditing = !isEditing }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = SanXTextMuted, modifier = Modifier.size(16.dp))
                    }
                    if (onRegenerate != null) {
                        IconButton(onClick = onRegenerate, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Refresh, contentDescription = "Regenerate", tint = SanXTextMuted, modifier = Modifier.size(16.dp))
                        }
                    }
                    if (onSave != null) {
                        IconButton(onClick = onSave, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Save, contentDescription = "Save", tint = SanXCyan, modifier = Modifier.size(16.dp))
                        }
                    }
                    IconButton(onClick = onCopy, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = SanXNeonGreen, modifier = Modifier.size(16.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (isEditing) {
                OutlinedTextField(
                    value = editedContent,
                    onValueChange = { editedContent = it },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SanXNeonGreen,
                        unfocusedBorderColor = SanXCardBorder,
                        focusedTextColor = SanXTextWhite,
                        unfocusedTextColor = SanXTextWhite
                    )
                )
            } else {
                Text(
                    text = editedContent.ifBlank { content },
                    fontSize = 13.sp,
                    color = SanXTextWhite,
                    lineHeight = 19.sp
                )
            }
        }
    }
}
