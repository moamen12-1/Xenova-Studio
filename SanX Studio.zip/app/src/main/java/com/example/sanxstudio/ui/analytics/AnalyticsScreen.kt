package com.example.sanxstudio.ui.analytics

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.sanxstudio.data.model.AnalyticsEntity
import com.example.sanxstudio.ui.components.EmptyStateView
import com.example.sanxstudio.ui.components.SanXButton
import com.example.sanxstudio.ui.components.SanXCard
import com.example.sanxstudio.ui.components.SanXTopBar
import com.example.sanxstudio.ui.localization.LocalStrings
import com.example.sanxstudio.ui.projects.FilterChip
import com.example.ui.theme.SanXBlack
import com.example.ui.theme.SanXBlue
import com.example.ui.theme.SanXCardBorder
import com.example.ui.theme.SanXCyan
import com.example.ui.theme.SanXGold
import com.example.ui.theme.SanXGreenDark
import com.example.ui.theme.SanXNeonGreen
import com.example.ui.theme.SanXPurple
import com.example.ui.theme.SanXRed
import com.example.ui.theme.SanXSurface
import com.example.ui.theme.SanXSurfaceVariant
import com.example.ui.theme.SanXTextDim
import com.example.ui.theme.SanXTextMuted
import com.example.ui.theme.SanXTextWhite

@Composable
fun AnalyticsScreen(
    onBack: (() -> Unit)? = null,
    viewModel: AnalyticsViewModel = viewModel()
) {
    val strings = LocalStrings.current
    val stats by viewModel.calculatedStats.collectAsState()
    val logs by viewModel.logs.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            SanXTopBar(
                title = strings.analyticsTitle,
                showBack = onBack != null,
                onBackClick = { onBack?.invoke() }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = SanXNeonGreen,
                contentColor = SanXBlack,
                shape = CircleShape,
                modifier = Modifier.testTag("analytics_add_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Log Video", modifier = Modifier.size(28.dp))
            }
        },
        containerColor = SanXBlack
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Milestone Goal Tracker Card
            item {
                SanXCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = SanXGold, modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(strings.creatorMilestone, fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 15.sp)
                            }
                            Text(
                                text = "${stats.totalViews} / 100,000 Views",
                                fontSize = 12.sp,
                                color = SanXNeonGreen,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        val progress = (stats.totalViews.toFloat() / 100000f).coerceIn(0.01f, 1f)
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = SanXNeonGreen,
                            trackColor = SanXSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Track your trajectory across platforms independently from platform algorithms.",
                            fontSize = 12.sp,
                            color = SanXTextMuted
                        )
                    }
                }
            }

            // Quick Analytics Grid
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatTile(
                            label = strings.averageViews,
                            value = formatNumber(stats.averageViews),
                            color = SanXNeonGreen,
                            modifier = Modifier.weight(1f)
                        )
                        StatTile(
                            label = strings.engagementRate,
                            value = String.format("%.1f%%", stats.averageEngagementRate),
                            color = SanXCyan,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatTile(
                            label = strings.bestPerformingGame,
                            value = stats.bestPerformingGame,
                            color = SanXGold,
                            modifier = Modifier.weight(1f)
                        )
                        StatTile(
                            label = strings.bestContentType,
                            value = stats.bestPerformingPlatform,
                            color = SanXPurple,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Video Logs Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Performance Log (${logs.size})", fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 16.sp)
                    SanXButton(
                        text = strings.logVideo,
                        onClick = { showAddDialog = true },
                        icon = Icons.Default.Add
                    )
                }
            }

            if (logs.isEmpty()) {
                item {
                    SanXCard(modifier = Modifier.fillMaxWidth()) {
                        EmptyStateView(
                            icon = Icons.Default.Insights,
                            title = "No Video Logs Yet",
                            description = "Log your published video stats to track performance and unlock insights.",
                            buttonText = strings.logVideo,
                            onButtonClick = { showAddDialog = true }
                        )
                    }
                }
            } else {
                items(logs, key = { it.id }) { log ->
                    VideoLogCard(
                        log = log,
                        onDelete = { viewModel.deleteLog(log) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(60.dp))
            }
        }
    }

    if (showAddDialog) {
        AddAnalyticsLogDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { t, plat, g, v, l, c, ret, n ->
                viewModel.addLog(t, plat, g, v, l, c, ret, n)
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun StatTile(
    label: String,
    value: String,
    color: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = SanXSurface,
        border = BorderStroke(1.dp, SanXCardBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(text = label, color = SanXTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, color = color, fontSize = 18.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
fun VideoLogCard(
    log: AnalyticsEntity,
    onDelete: () -> Unit
) {
    SanXCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = log.title, fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(text = "${log.game} • ${log.platform}", fontSize = 12.sp, color = SanXTextMuted)
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = SanXRed, modifier = Modifier.size(18.dp))
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MetricChip(label = "Views", value = formatNumber(log.views), color = SanXNeonGreen)
                MetricChip(label = "Likes", value = formatNumber(log.likes), color = SanXCyan)
                MetricChip(label = "Comments", value = formatNumber(log.comments.toLong()), color = SanXGold)
                MetricChip(label = "Retention", value = "${log.retentionPercent.toInt()}%", color = SanXPurple)
            }
        }
    }
}

@Composable
private fun MetricChip(label: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, fontWeight = FontWeight.Black, fontSize = 14.sp, color = color)
        Text(text = label, fontSize = 10.sp, color = SanXTextMuted)
    }
}

@Composable
fun AddAnalyticsLogDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, Long, Long, Long, Float, String) -> Unit
) {
    val strings = LocalStrings.current
    var title by remember { mutableStateOf("") }
    var game by remember { mutableStateOf("") }
    var platform by remember { mutableStateOf("YouTube Shorts") }
    var views by remember { mutableStateOf("") }
    var likes by remember { mutableStateOf("") }
    var comments by remember { mutableStateOf("") }
    var retention by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.logVideo, fontWeight = FontWeight.Bold, color = SanXTextWhite) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Video Title") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = game,
                    onValueChange = { game = it },
                    label = { Text("Game") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = views,
                        onValueChange = { views = it },
                        label = { Text("Views") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = likes,
                        onValueChange = { likes = it },
                        label = { Text("Likes") },
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = comments,
                        onValueChange = { comments = it },
                        label = { Text("Comments") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = retention,
                        onValueChange = { retention = it },
                        label = { Text("Retention %") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (title.isNotBlank()) {
                        val v = views.toLongOrNull() ?: 0L
                        val l = likes.toLongOrNull() ?: 0L
                        val c = comments.toLongOrNull() ?: 0L
                        val ret = retention.toFloatOrNull() ?: 0f
                        onConfirm(title, platform, if (game.isBlank()) "Gaming" else game, v, l, c, ret, "")
                    }
                }
            ) {
                Text(strings.saveChanges, color = SanXNeonGreen, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(strings.cancel, color = SanXTextMuted) }
        },
        containerColor = SanXSurface
    )
}

private fun formatNumber(num: Long): String {
    return when {
        num >= 1000000 -> String.format("%.1fM", num / 1000000.0)
        num >= 1000 -> String.format("%.1fK", num / 1000.0)
        else -> num.toString()
    }
}
