package com.example.sanxstudio.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.sanxstudio.data.model.AnalyticsEntity
import com.example.sanxstudio.data.model.CalendarEntryEntity
import com.example.sanxstudio.data.model.FavoriteEntity
import com.example.sanxstudio.data.model.IdeaEntity
import com.example.sanxstudio.data.model.ProjectEntity
import com.example.sanxstudio.data.model.ScriptEntity

@Database(
    entities = [
        ProjectEntity::class,
        IdeaEntity::class,
        ScriptEntity::class,
        FavoriteEntity::class,
        AnalyticsEntity::class,
        CalendarEntryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SanXDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
    abstract fun ideaDao(): IdeaDao
    abstract fun scriptDao(): ScriptDao
    abstract fun favoriteDao(): FavoriteDao
    abstract fun analyticsDao(): AnalyticsDao
    abstract fun calendarDao(): CalendarDao

    companion object {
        @Volatile
        private var INSTANCE: SanXDatabase? = null

        fun getInstance(context: Context): SanXDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SanXDatabase::class.java,
                    "sanx_studio_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
