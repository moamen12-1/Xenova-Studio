package com.example.sanxstudio.data.ai

sealed interface AiResult<out T> {
    data class Success<T>(val data: T) : AiResult<T>
    data class NotConfigured(val message: String) : AiResult<Nothing>
    data class Error(val message: String) : AiResult<Nothing>
}

data class FullContentResult(
    val hook: String,
    val videoIdea: String,
    val fullScript: String,
    val title: String,
    val description: String,
    val hashtags: String,
    val keywords: String,
    val thumbnailConcept: String,
    val thumbnailPrompt: String,
    val callToAction: String
)

data class ScriptResult(
    val hook: String,
    val intro: String,
    val mainContent: String,
    val climax: String,
    val ending: String,
    val cta: String,
    val isTtsFriendly: Boolean
) {
    val fullText: String
        get() = "HOOK:\n$hook\n\nINTRO:\n$intro\n\nMAIN:\n$mainContent\n\nCLIMAX:\n$climax\n\nENDING:\n$ending\n\nCTA:\n$cta"
}

data class TitleOption(
    val title: String,
    val category: String
)

data class ThumbnailConceptResult(
    val composition: String,
    val foreground: String,
    val background: String,
    val lighting: String,
    val characterPosition: String,
    val textPosition: String,
    val effects: String,
    val cameraAngle: String,
    val colorDirection: String,
    val overallMood: String,
    val generatedPrompt: String
)

data class HashtagsResult(
    val gamingTags: List<String>,
    val gameSpecificTags: List<String>,
    val topicSpecificTags: List<String>,
    val arabicTags: List<String>,
    val englishTags: List<String>
) {
    val allFormatted: String
        get() = (gamingTags + gameSpecificTags + topicSpecificTags + arabicTags + englishTags)
            .distinct()
            .joinToString(" ")
}

data class KeywordsResult(
    val primaryKeywords: List<String>,
    val secondaryKeywords: List<String>,
    val longTailKeywords: List<String>,
    val searchIntentExplanation: String = "High-intent search terms designed to capture gaming queries and recommendations."
) {
    val primary: List<String> get() = primaryKeywords
    val secondary: List<String> get() = secondaryKeywords
    val longTail: List<String> get() = longTailKeywords
    val intentExplanation: String get() = searchIntentExplanation

    val allFormatted: String
        get() = (primaryKeywords + secondaryKeywords + longTailKeywords).joinToString(", ")
}

interface AiContentService {
    suspend fun generateFullContent(
        game: String,
        topic: String,
        tone: String,
        durationSeconds: Int,
        platform: String,
        language: String
    ): AiResult<FullContentResult>

    suspend fun generateScript(
        topic: String,
        game: String,
        durationSeconds: Int,
        voiceStyle: String,
        tone: String,
        language: String,
        ttsFriendly: Boolean
    ): AiResult<ScriptResult>

    suspend fun generateTitles(
        game: String,
        topic: String,
        category: String,
        language: String
    ): AiResult<List<TitleOption>>

    suspend fun generateThumbnailConcept(
        topic: String,
        game: String,
        mainSubject: String,
        emotion: String,
        background: String,
        mainText: String,
        visualEffects: String,
        aspectRatio: String
    ): AiResult<ThumbnailConceptResult>

    suspend fun generateHashtags(
        game: String,
        topic: String,
        platform: String,
        language: String
    ): AiResult<HashtagsResult>

    suspend fun generateKeywords(
        game: String,
        topic: String,
        platform: String
    ): AiResult<KeywordsResult>

    suspend fun testConnection(): AiResult<String>
}
