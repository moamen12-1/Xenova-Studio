package com.example.sanxstudio.ui.create

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.Title
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.sanxstudio.ui.components.SanXTopBar
import com.example.sanxstudio.ui.localization.LocalStrings
import com.example.ui.theme.SanXBlack
import com.example.ui.theme.SanXBlue
import com.example.ui.theme.SanXCardBorder
import com.example.ui.theme.SanXCyan
import com.example.ui.theme.SanXGold
import com.example.ui.theme.SanXGreenDark
import com.example.ui.theme.SanXGreenGlow
import com.example.ui.theme.SanXNeonGreen
import com.example.ui.theme.SanXPurple
import com.example.ui.theme.SanXRed
import com.example.ui.theme.SanXSurface
import com.example.ui.theme.SanXSurfaceVariant
import com.example.ui.theme.SanXTextMuted
import com.example.ui.theme.SanXTextWhite

@Composable
fun CreateHubScreen(
    onNavigateToAiGenerator: (Long?) -> Unit,
    onNavigateToScriptStudio: (Long?) -> Unit,
    onNavigateToTitleStudio: (Long?) -> Unit,
    onNavigateToThumbnailStudio: (Long?) -> Unit,
    onNavigateToHashtags: () -> Unit,
    onNavigateToKeywords: () -> Unit,
    onNavigateToCalendar: () -> Unit,
    onNavigateToAnalytics: () -> Unit
) {
    val strings = LocalStrings.current

    Scaffold(
        topBar = {
            SanXTopBar(title = strings.navCreate)
        },
        containerColor = SanXBlack
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Featured All-in-One AI Generator Card
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .clickable { onNavigateToAiGenerator(null) },
                    shape = RoundedCornerShape(18.dp),
                    color = SanXSurface,
                    border = BorderStroke(1.5.dp, SanXNeonGreen)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.horizontalGradient(
                                    listOf(SanXGreenDark.copy(alpha = 0.6f), SanXSurface)
                                )
                            )
                            .padding(20.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(SanXNeonGreen)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text("AI ENGINE", color = SanXBlack, fontSize = 10.sp, fontWeight = FontWeight.Black)
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = strings.aiGeneratorTitle,
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Black,
                                    color = SanXTextWhite
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Generate hooks, full scripts, titles, descriptions, hashtags, keywords & thumbnail prompts in one shot",
                                    fontSize = 13.sp,
                                    color = SanXTextMuted,
                                    lineHeight = 18.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(SanXGreenGlow),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = SanXNeonGreen, modifier = Modifier.size(26.dp))
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = "Specialized Creator Studios",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = SanXTextWhite,
                    modifier = Modifier.padding(top = 8.dp, bottom = 2.dp)
                )
            }

            // Script Studio
            item {
                StudioCard(
                    icon = Icons.Default.EditNote,
                    iconColor = SanXCyan,
                    title = strings.scriptStudioTitle,
                    subtitle = "Hook, intro, climax, and dedicated Arabic/English TTS friendly scripts",
                    onClick = { onNavigateToScriptStudio(null) }
                )
            }

            // Title Studio
            item {
                StudioCard(
                    icon = Icons.Default.Title,
                    iconColor = SanXPurple,
                    title = strings.titleStudioTitle,
                    subtitle = "Categorized high-CTR titles: Mystery, Horror, Curiosity, Viral & Short",
                    onClick = { onNavigateToTitleStudio(null) }
                )
            }

            // Thumbnail Studio
            item {
                StudioCard(
                    icon = Icons.Default.Image,
                    iconColor = SanXGold,
                    title = strings.thumbnailStudioTitle,
                    subtitle = "Rule-of-thirds composition, lighting, text overlay & aspect ratio canvas",
                    onClick = { onNavigateToThumbnailStudio(null) }
                )
            }

            // Hashtag Generator
            item {
                StudioCard(
                    icon = Icons.Default.Tag,
                    iconColor = SanXBlue,
                    title = strings.hashtagStudioTitle,
                    subtitle = "Gaming, game-specific, Arabic & English targeted tags with one-tap copy",
                    onClick = onNavigateToHashtags
                )
            }

            // SEO Keywords
            item {
                StudioCard(
                    icon = Icons.Default.Key,
                    iconColor = SanXGold,
                    title = strings.keywordStudioTitle,
                    subtitle = "Primary, secondary, and long-tail search terms to boost discoverability",
                    onClick = onNavigateToKeywords
                )
            }

            item {
                Text(
                    text = "Planning & Analytics",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = SanXTextWhite,
                    modifier = Modifier.padding(top = 8.dp, bottom = 2.dp)
                )
            }

            // Content Calendar
            item {
                StudioCard(
                    icon = Icons.Default.CalendarMonth,
                    iconColor = SanXCyan,
                    title = strings.calendarTitle,
                    subtitle = "Schedule filming and publishing dates with monthly & weekly views",
                    onClick = onNavigateToCalendar
                )
            }

            // Analytics
            item {
                StudioCard(
                    icon = Icons.Default.Insights,
                    iconColor = SanXRed,
                    title = strings.analyticsTitle,
                    subtitle = "Independent creator tracking for views, engagement rates, and watch times",
                    onClick = onNavigateToAnalytics
                )
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

@Composable
private fun StudioCard(
    icon: ImageVector,
    iconColor: Color,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = SanXSurface,
        border = BorderStroke(1.dp, SanXCardBorder)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(iconColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(24.dp))
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 15.sp)
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = subtitle, color = SanXTextMuted, fontSize = 12.sp, lineHeight = 16.sp)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = SanXCardBorder)
        }
    }
}
