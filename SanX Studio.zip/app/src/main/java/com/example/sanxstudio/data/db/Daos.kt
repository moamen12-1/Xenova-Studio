package com.example.sanxstudio.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.sanxstudio.data.model.AnalyticsEntity
import com.example.sanxstudio.data.model.CalendarEntryEntity
import com.example.sanxstudio.data.model.FavoriteEntity
import com.example.sanxstudio.data.model.IdeaEntity
import com.example.sanxstudio.data.model.ProjectEntity
import com.example.sanxstudio.data.model.ScriptEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    fun getAllProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE isFavorite = 1 ORDER BY updatedAt DESC")
    fun getFavoriteProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun getProjectById(id: Long): ProjectEntity?

    @Query("SELECT * FROM projects WHERE id = :id")
    fun observeProjectById(id: Long): Flow<ProjectEntity?>

    @Query("SELECT COUNT(*) FROM projects")
    fun getProjectCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectEntity): Long

    @Update
    suspend fun updateProject(project: ProjectEntity)

    @Delete
    suspend fun deleteProject(project: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProjectById(id: Long)

    @Query("SELECT * FROM projects WHERE name LIKE '%' || :query || '%' OR game LIKE '%' || :query || '%' OR description LIKE '%' || :query || '%'")
    fun searchProjects(query: String): Flow<List<ProjectEntity>>
}

@Dao
interface IdeaDao {
    @Query("SELECT * FROM ideas ORDER BY createdAt DESC")
    fun getAllIdeas(): Flow<List<IdeaEntity>>

    @Query("SELECT * FROM ideas WHERE isFavorite = 1 ORDER BY createdAt DESC")
    fun getFavoriteIdeas(): Flow<List<IdeaEntity>>

    @Query("SELECT COUNT(*) FROM ideas")
    fun getIdeaCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIdea(idea: IdeaEntity): Long

    @Update
    suspend fun updateIdea(idea: IdeaEntity)

    @Delete
    suspend fun deleteIdea(idea: IdeaEntity)

    @Query("DELETE FROM ideas WHERE id = :id")
    suspend fun deleteIdeaById(id: Long)

    @Query("SELECT * FROM ideas WHERE title LIKE '%' || :query || '%' OR game LIKE '%' || :query || '%'")
    fun searchIdeas(query: String): Flow<List<IdeaEntity>>
}

@Dao
interface ScriptDao {
    @Query("SELECT * FROM scripts ORDER BY createdAt DESC")
    fun getAllScripts(): Flow<List<ScriptEntity>>

    @Query("SELECT * FROM scripts WHERE isFavorite = 1 ORDER BY createdAt DESC")
    fun getFavoriteScripts(): Flow<List<ScriptEntity>>

    @Query("SELECT * FROM scripts WHERE id = :id")
    suspend fun getScriptById(id: Long): ScriptEntity?

    @Query("SELECT COUNT(*) FROM scripts")
    fun getScriptCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScript(script: ScriptEntity): Long

    @Update
    suspend fun updateScript(script: ScriptEntity)

    @Delete
    suspend fun deleteScript(script: ScriptEntity)

    @Query("DELETE FROM scripts WHERE id = :id")
    suspend fun deleteScriptById(id: Long)

    @Query("SELECT * FROM scripts WHERE title LIKE '%' || :query || '%' OR topic LIKE '%' || :query || '%'")
    fun searchScripts(query: String): Flow<List<ScriptEntity>>
}

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites ORDER BY createdAt DESC")
    fun getAllFavorites(): Flow<List<FavoriteEntity>>

    @Query("SELECT * FROM favorites WHERE type = :type ORDER BY createdAt DESC")
    fun getFavoritesByType(type: String): Flow<List<FavoriteEntity>>

    @Query("SELECT COUNT(*) FROM favorites")
    fun getFavoriteCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(favorite: FavoriteEntity): Long

    @Update
    suspend fun updateFavorite(favorite: FavoriteEntity)

    @Delete
    suspend fun deleteFavorite(favorite: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE type = :type AND targetId = :targetId")
    suspend fun deleteByTypeAndTargetId(type: String, targetId: Long)

    @Query("DELETE FROM favorites WHERE id = :id")
    suspend fun deleteFavoriteById(id: Long)
}

@Dao
interface AnalyticsDao {
    @Query("SELECT * FROM analytics ORDER BY entryDate DESC")
    fun getAllAnalytics(): Flow<List<AnalyticsEntity>>

    @Query("SELECT * FROM analytics WHERE id = :id")
    suspend fun getAnalyticsById(id: Long): AnalyticsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnalytics(analytics: AnalyticsEntity): Long

    @Update
    suspend fun updateAnalytics(analytics: AnalyticsEntity)

    @Delete
    suspend fun deleteAnalytics(analytics: AnalyticsEntity)

    @Query("DELETE FROM analytics WHERE id = :id")
    suspend fun deleteAnalyticsById(id: Long)
}

@Dao
interface CalendarDao {
    @Query("SELECT * FROM calendar_entries ORDER BY plannedDate ASC")
    fun getAllCalendarEntries(): Flow<List<CalendarEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCalendarEntry(entry: CalendarEntryEntity): Long

    @Update
    suspend fun updateCalendarEntry(entry: CalendarEntryEntity)

    @Delete
    suspend fun deleteCalendarEntry(entry: CalendarEntryEntity)

    @Query("DELETE FROM calendar_entries WHERE id = :id")
    suspend fun deleteCalendarEntryById(id: Long)
}
