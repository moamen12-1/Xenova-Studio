package com.example.sanxstudio.ui.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.sanxstudio.data.ai.AiContentService
import com.example.sanxstudio.data.ai.AiResult
import com.example.sanxstudio.data.ai.SanXAiContentServiceImpl
import com.example.sanxstudio.data.repository.PreferencesRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface ConnectionTestState {
    object Idle : ConnectionTestState
    object Testing : ConnectionTestState
    data class Success(val message: String) : ConnectionTestState
    data class Error(val message: String) : ConnectionTestState
}

class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    val preferencesRepository = PreferencesRepository(application)
    private val aiService: AiContentService = SanXAiContentServiceImpl(preferencesRepository)

    val currentLanguage = preferencesRepository.appLanguageFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "en")

    val apiKey = preferencesRepository.geminiApiKeyFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    val selectedModel = preferencesRepository.selectedModelFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "gemini-2.5-flash")

    val notificationsEnabled = preferencesRepository.reminderNotificationsEnabledFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    private val _testState = MutableStateFlow<ConnectionTestState>(ConnectionTestState.Idle)
    val testState: StateFlow<ConnectionTestState> = _testState.asStateFlow()

    fun setLanguage(lang: String) {
        viewModelScope.launch {
            preferencesRepository.setAppLanguage(lang)
        }
    }

    fun setApiKey(key: String) {
        viewModelScope.launch {
            preferencesRepository.setGeminiApiKey(key)
        }
    }

    fun setSelectedModel(model: String) {
        viewModelScope.launch {
            preferencesRepository.setSelectedModel(model)
        }
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setReminderNotificationsEnabled(enabled)
        }
    }

    fun testConnection() {
        viewModelScope.launch {
            _testState.value = ConnectionTestState.Testing
            when (val res = aiService.testConnection()) {
                is AiResult.Success -> {
                    _testState.value = ConnectionTestState.Success(res.data)
                }
                is AiResult.NotConfigured -> {
                    _testState.value = ConnectionTestState.Error(res.message)
                }
                is AiResult.Error -> {
                    _testState.value = ConnectionTestState.Error(res.message)
                }
            }
        }
    }
}
