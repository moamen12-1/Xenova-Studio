package com.example.sanxstudio.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ContentType(val displayName: String, val displayNameAr: String) {
    YOUTUBE_VIDEO("YouTube Video", "فيديو يوتيوب"),
    YOUTUBE_SHORTS("YouTube Shorts", "شورتس يوتيوب"),
    TIKTOK("TikTok", "تيك توك"),
    INSTAGRAM_REELS("Instagram Reels", "ريلز إنستغرام"),
    FACEBOOK_REELS("Facebook Reels", "ريلز فيسبوك"),
    GAMING_LIVE("Gaming Live", "بث مباشر للألعاب")
}

enum class VideoFormat(val ratio: String, val widthRatio: Float, val heightRatio: Float) {
    RATIO_16_9("16:9", 16f, 9f),
    RATIO_9_16("9:16", 9f, 16f),
    RATIO_1_1("1:1", 1f, 1f),
    RATIO_4_5("4:5", 4f, 5f)
}

enum class ProjectStatus(val displayName: String, val displayNameAr: String) {
    IDEA("Idea", "فكرة"),
    WRITING("Writing", "كتابة السكربت"),
    RECORDING("Recording", "تسجيل"),
    EDITING("Editing", "مونتاج"),
    READY("Ready", "جاهز للنشر"),
    PUBLISHED("Published", "تم النشر")
}

enum class ContentTone(val displayName: String, val displayNameAr: String) {
    ENERGETIC("Energetic", "حماسي ونشيط"),
    MYSTERIOUS("Mysterious", "غامض ومثير"),
    SCARY("Horror / Scary", "رعب ومخيف"),
    FUNNY("Funny / Comedy", "كوميدي ومضحك"),
    PROFESSIONAL("Professional", "احترافي ودقيق"),
    STORYTELLING("Dramatic / Story", "قصصي ودرامي"),
    EDUCATIONAL("Educational / Guide", "تعليمي وشروحات")
}

enum class FavoriteType(val displayName: String) {
    PROJECT("Project"),
    HOOK("Hook"),
    SCRIPT("Script"),
    TITLE("Title"),
    IDEA("Idea"),
    PROMPT("Prompt"),
    KEYWORDS("Keywords"),
    HASHTAG("Hashtag")
}

enum class IdeaPriority(val displayName: String, val displayNameAr: String) {
    LOW("Low", "منخفضة"),
    MEDIUM("Medium", "متوسطة"),
    HIGH("High", "عالية"),
    TOP("Top Priority", "أولوية قصوى")
}

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val game: String,
    val contentType: String = ContentType.YOUTUBE_SHORTS.name,
    val language: String = "en",
    val videoFormat: String = VideoFormat.RATIO_9_16.name,
    val targetPlatform: String = "YouTube Shorts",
    val description: String = "",
    val status: String = ProjectStatus.IDEA.name,
    val hook: String = "",
    val idea: String = "",
    val script: String = "",
    val title: String = "",
    val thumbnailPrompt: String = "",
    val thumbnailConcept: String = "",
    val hashtags: String = "",
    val keywords: String = "",
    val callToAction: String = "",
    val notes: String = "",
    val isFavorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "ideas")
data class IdeaEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val game: String,
    val description: String = "",
    val category: String = "Gameplay",
    val priority: String = IdeaPriority.MEDIUM.name,
    val isFavorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "scripts")
data class ScriptEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long? = null,
    val title: String,
    val game: String,
    val topic: String,
    val durationSeconds: Int = 45,
    val tone: String = ContentTone.ENERGETIC.name,
    val voiceStyle: String = "Fast & punchy",
    val language: String = "en",
    val hook: String = "",
    val intro: String = "",
    val mainContent: String = "",
    val climax: String = "",
    val ending: String = "",
    val cta: String = "",
    val isTtsFriendly: Boolean = false,
    val isFavorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String, // from FavoriteType
    val targetId: Long? = null,
    val title: String,
    val subtitle: String = "",
    val content: String = "",
    val metadata: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "analytics")
data class AnalyticsEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long? = null,
    val title: String,
    val platform: String,
    val game: String = "General Gaming",
    val views: Long = 0,
    val likes: Long = 0,
    val comments: Long = 0,
    val shares: Long = 0,
    val followersGained: Long = 0,
    val avgWatchTimeSeconds: Int = 0,
    val videoDurationSeconds: Int = 60,
    val retentionPercent: Float = 0f,
    val notes: String = "",
    val entryDate: Long = System.currentTimeMillis()
) {
    val engagementRate: Float
        get() = if (views > 0) ((likes + comments + shares).toFloat() / views.toFloat()) * 100f else 0f

    val likeRate: Float
        get() = if (views > 0) (likes.toFloat() / views.toFloat()) * 100f else 0f

    val commentRate: Float
        get() = if (views > 0) (comments.toFloat() / views.toFloat()) * 100f else 0f

    val shareRate: Float
        get() = if (views > 0) (shares.toFloat() / views.toFloat()) * 100f else 0f
}

@Entity(tableName = "calendar_entries")
data class CalendarEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long? = null,
    val title: String,
    val game: String = "",
    val plannedDate: Long = System.currentTimeMillis(),
    val platform: String = "YouTube Shorts",
    val status: String = "PLANNED", // PLANNED, RECORDED, PUBLISHED
    val notes: String = "",
    val hasReminder: Boolean = false
) {
    val scheduledDate: Long get() = plannedDate
    val contentType: String get() = platform
}

typealias CalendarEntity = CalendarEntryEntity
