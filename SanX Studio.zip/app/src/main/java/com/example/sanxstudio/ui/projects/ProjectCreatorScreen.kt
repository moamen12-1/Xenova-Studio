package com.example.sanxstudio.ui.projects

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.sanxstudio.data.model.ContentType
import com.example.sanxstudio.data.model.VideoFormat
import com.example.sanxstudio.ui.components.SanXButton
import com.example.sanxstudio.ui.components.SanXSecondaryButton
import com.example.sanxstudio.ui.components.SanXTopBar
import com.example.sanxstudio.ui.localization.LocalStrings
import com.example.ui.theme.SanXBlack
import com.example.ui.theme.SanXCardBorder
import com.example.ui.theme.SanXNeonGreen
import com.example.ui.theme.SanXRed
import com.example.ui.theme.SanXSurface
import com.example.ui.theme.SanXTextDim
import com.example.ui.theme.SanXTextMuted
import com.example.ui.theme.SanXTextWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectCreatorScreen(
    onBack: () -> Unit,
    onProjectCreated: (Long) -> Unit,
    viewModel: ProjectsViewModel = viewModel()
) {
    val strings = LocalStrings.current

    var name by remember { mutableStateOf("") }
    var game by remember { mutableStateOf("") }
    var selectedContentType by remember { mutableStateOf(ContentType.YOUTUBE_SHORTS.name) }
    var selectedLanguage by remember { mutableStateOf("en") }
    var selectedFormat by remember { mutableStateOf(VideoFormat.RATIO_9_16.name) }
    var targetPlatform by remember { mutableStateOf("YouTube Shorts") }
    var description by remember { mutableStateOf("") }
    var nameError by remember { mutableStateOf(false) }

    val platforms = listOf("YouTube Shorts", "YouTube Video", "TikTok", "Instagram Reels", "Facebook Reels", "Twitch / Kick")

    Scaffold(
        topBar = {
            SanXTopBar(
                title = strings.createProjectTitle,
                showBack = true,
                onBackClick = onBack
            )
        },
        containerColor = SanXBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Project Name (Required)
            Column {
                Text(
                    text = "${strings.projectNameLabel} *",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (nameError) SanXRed else SanXTextWhite
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        if (it.isNotBlank()) nameError = false
                    },
                    placeholder = { Text(strings.projectNameHint, color = SanXTextDim) },
                    isError = nameError,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("project_name_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SanXNeonGreen,
                        unfocusedBorderColor = SanXCardBorder,
                        focusedContainerColor = SanXSurface,
                        unfocusedContainerColor = SanXSurface,
                        focusedTextColor = SanXTextWhite,
                        unfocusedTextColor = SanXTextWhite
                    ),
                    singleLine = true
                )
            }

            // Game
            Column {
                Text(
                    text = strings.gameLabel,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = SanXTextWhite
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = game,
                    onValueChange = { game = it },
                    placeholder = { Text(strings.gameHint, color = SanXTextDim) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("project_game_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SanXNeonGreen,
                        unfocusedBorderColor = SanXCardBorder,
                        focusedContainerColor = SanXSurface,
                        unfocusedContainerColor = SanXSurface,
                        focusedTextColor = SanXTextWhite,
                        unfocusedTextColor = SanXTextWhite
                    ),
                    singleLine = true
                )
            }

            // Content Type Chips
            Column {
                Text(
                    text = strings.contentTypeLabel,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = SanXTextWhite
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ContentType.values().forEach { type ->
                        FilterChip(
                            text = type.displayName,
                            isSelected = selectedContentType == type.name,
                            onClick = {
                                selectedContentType = type.name
                                if (type == ContentType.YOUTUBE_VIDEO || type == ContentType.GAMING_LIVE) {
                                    selectedFormat = VideoFormat.RATIO_16_9.name
                                    targetPlatform = if (type == ContentType.GAMING_LIVE) "Twitch / Kick" else "YouTube Video"
                                } else {
                                    selectedFormat = VideoFormat.RATIO_9_16.name
                                    targetPlatform = type.displayName
                                }
                            }
                        )
                    }
                }
            }

            // Target Platform Chips
            Column {
                Text(
                    text = strings.targetPlatformLabel,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = SanXTextWhite
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    platforms.forEach { plat ->
                        FilterChip(
                            text = plat,
                            isSelected = targetPlatform == plat,
                            onClick = { targetPlatform = plat }
                        )
                    }
                }
            }

            // Video Format Ratio Chips
            Column {
                Text(
                    text = strings.videoFormatLabel,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = SanXTextWhite
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    VideoFormat.values().forEach { format ->
                        FilterChip(
                            text = format.ratio,
                            isSelected = selectedFormat == format.name,
                            onClick = { selectedFormat = format.name }
                        )
                    }
                }
            }

            // Script Language
            Column {
                Text(
                    text = strings.languageLabel,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = SanXTextWhite
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FilterChip(
                        text = "English",
                        isSelected = selectedLanguage == "en",
                        onClick = { selectedLanguage = "en" }
                    )
                    FilterChip(
                        text = "العربية (Arabic)",
                        isSelected = selectedLanguage == "ar",
                        onClick = { selectedLanguage = "ar" }
                    )
                }
            }

            // Description
            Column {
                Text(
                    text = strings.descriptionLabel,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = SanXTextWhite
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    placeholder = { Text(strings.descriptionHint, color = SanXTextDim) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("project_desc_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SanXNeonGreen,
                        unfocusedBorderColor = SanXCardBorder,
                        focusedContainerColor = SanXSurface,
                        unfocusedContainerColor = SanXSurface,
                        focusedTextColor = SanXTextWhite,
                        unfocusedTextColor = SanXTextWhite
                    ),
                    minLines = 3,
                    maxLines = 6
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                SanXSecondaryButton(
                    text = strings.cancel,
                    onClick = onBack,
                    modifier = Modifier.weight(0.4f)
                )
                Spacer(modifier = Modifier.width(12.dp))
                SanXButton(
                    text = strings.createProjectButton,
                    onClick = {
                        if (name.isBlank()) {
                            nameError = true
                        } else {
                            viewModel.createProject(
                                name = name,
                                game = if (game.isBlank()) "General Gaming" else game,
                                contentType = selectedContentType,
                                language = selectedLanguage,
                                videoFormat = selectedFormat,
                                targetPlatform = targetPlatform,
                                description = description,
                                onCreated = onProjectCreated
                            )
                        }
                    },
                    icon = Icons.Default.Check,
                    modifier = Modifier
                        .weight(0.6f)
                        .testTag("submit_create_project_button")
                )
            }
        }
    }
}
