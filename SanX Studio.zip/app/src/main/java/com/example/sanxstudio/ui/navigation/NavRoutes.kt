package com.example.sanxstudio.ui.navigation

sealed class Screen(val route: String) {
    object Onboarding : Screen("onboarding")
    object Main : Screen("main")

    // Bottom bar tabs
    object Home : Screen("home")
    object Projects : Screen("projects")
    object Create : Screen("create")
    object Ideas : Screen("ideas")
    object Settings : Screen("settings")

    // Sub-screens
    object ProjectCreator : Screen("project_creator")
    object ProjectWorkspace : Screen("project_workspace/{projectId}") {
        fun createRoute(projectId: Long) = "project_workspace/$projectId"
    }

    object AiGenerator : Screen("ai_generator?projectId={projectId}") {
        fun createRoute(projectId: Long? = null) = if (projectId != null) "ai_generator?projectId=$projectId" else "ai_generator"
    }

    object ScriptStudio : Screen("script_studio?projectId={projectId}") {
        fun createRoute(projectId: Long? = null) = if (projectId != null) "script_studio?projectId=$projectId" else "script_studio"
    }

    object TitleStudio : Screen("title_studio?projectId={projectId}") {
        fun createRoute(projectId: Long? = null) = if (projectId != null) "title_studio?projectId=$projectId" else "title_studio"
    }

    object ThumbnailStudio : Screen("thumbnail_studio?projectId={projectId}") {
        fun createRoute(projectId: Long? = null) = if (projectId != null) "thumbnail_studio?projectId=$projectId" else "thumbnail_studio"
    }

    object HashtagStudio : Screen("hashtag_studio")
    object KeywordStudio : Screen("keyword_studio")
    object ContentCalendar : Screen("content_calendar")
    object Analytics : Screen("analytics")
    object Favorites : Screen("favorites")
    object GlobalSearch : Screen("global_search")
}
