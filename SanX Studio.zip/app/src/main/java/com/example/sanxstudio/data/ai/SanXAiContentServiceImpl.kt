package com.example.sanxstudio.data.ai

import com.example.sanxstudio.data.repository.PreferencesRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class SanXAiContentServiceImpl(
    private val preferencesRepository: PreferencesRepository
) : AiContentService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private suspend fun getActiveApiKey(): String {
        val userKey = preferencesRepository.aiApiKey.first().trim()
        if (userKey.isNotEmpty()) return userKey
        // Fallback to BuildConfig if provided via secrets panel
        return try {
            val field = Class.forName("com.example.BuildConfig").getField("GEMINI_API_KEY")
            (field.get(null) as? String)?.trim().orEmpty()
        } catch (_: Exception) {
            ""
        }
    }

    private suspend fun callGeminiApi(prompt: String): AiResult<String> = withContext(Dispatchers.IO) {
        val apiKey = getActiveApiKey()
        if (apiKey.isEmpty()) {
            return@withContext AiResult.NotConfigured(
                "AI service is not configured yet.\n\nPlease go to Settings > AI Configuration and enter your Gemini API key to enable instant AI generation."
            )
        }

        val model = preferencesRepository.aiModel.first().ifEmpty { "gemini-2.5-flash" }
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"

        try {
            val jsonBody = JSONObject().apply {
                val contents = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val parts = JSONArray().apply {
                            put(JSONObject().apply { put("text", prompt) })
                        }
                        put("parts", parts)
                    }
                    put(contentObj)
                }
                put("contents", contents)
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.7)
                    put("maxOutputTokens", 2048)
                })
            }

            val request = Request.Builder()
                .url(url)
                .post(jsonBody.toString().toRequestBody(jsonMediaType))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                return@withContext AiResult.Error("API error (${response.code}): $responseBody")
            }

            val jsonResponse = JSONObject(responseBody)
            val candidates = jsonResponse.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val firstCandidate = candidates.getJSONObject(0)
                val content = firstCandidate.getJSONObject("content")
                val parts = content.getJSONArray("parts")
                if (parts.length() > 0) {
                    val text = parts.getJSONObject(0).getString("text")
                    return@withContext AiResult.Success(text)
                }
            }
            AiResult.Error("Empty response received from AI model.")
        } catch (e: Exception) {
            AiResult.Error("Network or generation error: ${e.localizedMessage ?: "Unknown error"}")
        }
    }

    override suspend fun generateFullContent(
        game: String,
        topic: String,
        tone: String,
        durationSeconds: Int,
        platform: String,
        language: String
    ): AiResult<FullContentResult> {
        val isArabic = language == "ar"
        val langInstruction = if (isArabic) {
            "Write everything in high-quality Arabic suitable for gaming content creators."
        } else {
            "Write everything in energetic, creator-focused English."
        }

        val prompt = """
You are SanX Studio's elite gaming content creation AI.
Create a complete, structured content package for a video about:
Game: $game
Topic: $topic
Tone: $tone
Duration: $durationSeconds seconds
Target Platform: $platform
Language Instruction: $langInstruction

Respond strictly with valid JSON using exactly these keys:
{
  "hook": "An irresistible 3-second opening hook line",
  "videoIdea": "A sharp 2-sentence summary of the core video concept",
  "fullScript": "Complete spoken script formatted with timestamps and speaker cues",
  "title": "A clickable, high-CTR gaming title (no false viral claims)",
  "description": "Engaging description with timestamps, summary, and creator links",
  "hashtags": "8-12 relevant hashtags formatted with #",
  "keywords": "Comma-separated SEO keywords and search terms",
  "thumbnailConcept": "Clear description of character, scene, colors, and focal point",
  "thumbnailPrompt": "Midjourney/StableDiffusion/DALL-E image generation prompt with camera angle, lighting, and art style",
  "callToAction": "A natural, non-annoying subscriber/comment call to action"
}
Output only the raw JSON, without markdown code fences or conversational intro.
""".trimIndent()

        return when (val result = callGeminiApi(prompt)) {
            is AiResult.NotConfigured -> AiResult.NotConfigured(result.message)
            is AiResult.Error -> AiResult.Error(result.message)
            is AiResult.Success -> {
                try {
                    val cleaned = cleanJsonString(result.data)
                    val json = JSONObject(cleaned)
                    AiResult.Success(
                        FullContentResult(
                            hook = json.optString("hook"),
                            videoIdea = json.optString("videoIdea"),
                            fullScript = json.optString("fullScript"),
                            title = json.optString("title"),
                            description = json.optString("description"),
                            hashtags = json.optString("hashtags"),
                            keywords = json.optString("keywords"),
                            thumbnailConcept = json.optString("thumbnailConcept"),
                            thumbnailPrompt = json.optString("thumbnailPrompt"),
                            callToAction = json.optString("callToAction")
                        )
                    )
                } catch (e: Exception) {
                    AiResult.Error("Failed to parse AI output: ${e.message}")
                }
            }
        }
    }

    override suspend fun generateScript(
        topic: String,
        game: String,
        durationSeconds: Int,
        voiceStyle: String,
        tone: String,
        language: String,
        ttsFriendly: Boolean
    ): AiResult<ScriptResult> {
        val isArabic = language == "ar"
        val ttsRule = if (ttsFriendly) {
            "CRITICAL: The output MUST be 100% TTS-friendly (Text-To-Speech friendly). Avoid complex punctuation, avoid difficult abbreviations, use short clear phonetic sentences, and omit symbols."
        } else {
            "Include natural pacing, dramatic pauses, and expressive delivery markers."
        }

        val langRule = if (isArabic) "Language: Arabic (fluent and engaging gaming tone)." else "Language: English."

        val prompt = """
You are SanX Studio's professional gaming scriptwriter.
Write a $durationSeconds-second gaming script:
Topic: $topic
Game: $game
Voice Style: $voiceStyle
Tone: $tone
$langRule
$ttsRule

Respond strictly with JSON containing these keys:
{
  "hook": "Attention-grabbing opening 3-5 seconds",
  "intro": "Quick setup of why the viewer needs to watch",
  "mainContent": "The core gameplay action, tip, or story steps",
  "climax": "The most intense or surprising moment",
  "ending": "Resolution and final takeaway",
  "cta": "Closing call to action"
}
Output only raw JSON.
""".trimIndent()

        return when (val result = callGeminiApi(prompt)) {
            is AiResult.NotConfigured -> AiResult.NotConfigured(result.message)
            is AiResult.Error -> AiResult.Error(result.message)
            is AiResult.Success -> {
                try {
                    val json = JSONObject(cleanJsonString(result.data))
                    AiResult.Success(
                        ScriptResult(
                            hook = json.optString("hook"),
                            intro = json.optString("intro"),
                            mainContent = json.optString("mainContent"),
                            climax = json.optString("climax"),
                            ending = json.optString("ending"),
                            cta = json.optString("cta"),
                            isTtsFriendly = ttsFriendly
                        )
                    )
                } catch (e: Exception) {
                    AiResult.Error("Failed to parse script: ${e.message}")
                }
            }
        }
    }

    override suspend fun generateTitles(
        game: String,
        topic: String,
        category: String,
        language: String
    ): AiResult<List<TitleOption>> {
        val isArabic = language == "ar"
        val langRule = if (isArabic) "Generate titles in Arabic." else "Generate titles in English."
        val prompt = """
You are SanX Studio's YouTube/TikTok title strategist.
Generate 7 distinct gaming titles for:
Game: $game
Topic: $topic
Category focus: $category
$langRule
Do NOT guarantee viral results. Make them engaging, curiosity-driven, and high CTR.

Categories to cover:
- Curiosity
- Mystery
- Horror
- Viral-style
- Professional
- Short
- Dramatic

Respond strictly in JSON format:
{
  "titles": [
    {"title": "Title text here", "category": "Curiosity"},
    {"title": "Title text here", "category": "Mystery"},
    {"title": "Title text here", "category": "Horror"},
    {"title": "Title text here", "category": "Viral-style"},
    {"title": "Title text here", "category": "Professional"},
    {"title": "Title text here", "category": "Short"},
    {"title": "Title text here", "category": "Dramatic"}
  ]
}
Output only raw JSON.
""".trimIndent()

        return when (val result = callGeminiApi(prompt)) {
            is AiResult.NotConfigured -> AiResult.NotConfigured(result.message)
            is AiResult.Error -> AiResult.Error(result.message)
            is AiResult.Success -> {
                try {
                    val json = JSONObject(cleanJsonString(result.data))
                    val arr = json.getJSONArray("titles")
                    val list = mutableListOf<TitleOption>()
                    for (i in 0 until arr.length()) {
                        val item = arr.getJSONObject(i)
                        list.add(
                            TitleOption(
                                title = item.getString("title"),
                                category = item.optString("category", "General")
                            )
                        )
                    }
                    AiResult.Success(list)
                } catch (e: Exception) {
                    AiResult.Error("Failed to parse titles: ${e.message}")
                }
            }
        }
    }

    override suspend fun generateThumbnailConcept(
        topic: String,
        game: String,
        mainSubject: String,
        emotion: String,
        background: String,
        mainText: String,
        visualEffects: String,
        aspectRatio: String
    ): AiResult<ThumbnailConceptResult> {
        val prompt = """
You are SanX Studio's thumbnail art director.
Create a structured high-CTR gaming thumbnail concept:
Topic: $topic
Game: $game
Main Subject: $mainSubject
Emotion: $emotion
Background: $background
Overlay Text: $mainText
Visual Effects: $visualEffects
Aspect Ratio: $aspectRatio

Respond strictly in JSON:
{
  "composition": "Rule of thirds layout breakdown",
  "foreground": "Detailed foreground elements",
  "background": "Background scenery, lighting, and blur depth",
  "lighting": "Rim lights, colored backlight, shadows",
  "characterPosition": "Position and pose of character or vehicle",
  "textPosition": "Big bold placement, font weight, and contrast outline",
  "effects": "Particles, smoke, sparks, or speed lines",
  "cameraAngle": "Low angle, dynamic Dutch angle, or extreme close-up",
  "colorDirection": "Complementary color palette (e.g., cyan and orange)",
  "overallMood": "Intensity, mystery, or excitement",
  "generatedPrompt": "A ready-to-paste AI image generation prompt for Midjourney/Stable Diffusion formatted with aspect ratio --ar $aspectRatio"
}
Output only raw JSON.
""".trimIndent()

        return when (val result = callGeminiApi(prompt)) {
            is AiResult.NotConfigured -> AiResult.NotConfigured(result.message)
            is AiResult.Error -> AiResult.Error(result.message)
            is AiResult.Success -> {
                try {
                    val json = JSONObject(cleanJsonString(result.data))
                    AiResult.Success(
                        ThumbnailConceptResult(
                            composition = json.optString("composition"),
                            foreground = json.optString("foreground"),
                            background = json.optString("background"),
                            lighting = json.optString("lighting"),
                            characterPosition = json.optString("characterPosition"),
                            textPosition = json.optString("textPosition"),
                            effects = json.optString("effects"),
                            cameraAngle = json.optString("cameraAngle"),
                            colorDirection = json.optString("colorDirection"),
                            overallMood = json.optString("overallMood"),
                            generatedPrompt = json.optString("generatedPrompt")
                        )
                    )
                } catch (e: Exception) {
                    AiResult.Error("Failed to parse thumbnail concept: ${e.message}")
                }
            }
        }
    }

    override suspend fun generateHashtags(
        game: String,
        topic: String,
        platform: String,
        language: String
    ): AiResult<HashtagsResult> {
        val prompt = """
You are SanX Studio's gaming social media strategist.
Generate targeted hashtags for:
Game: $game
Topic: $topic
Platform: $platform
Language: $language

Do NOT claim hashtags guarantee views.

Respond strictly in JSON:
{
  "gamingTags": ["#Gaming", "#Gamer", "#GamingCommunity", "#Gameplay"],
  "gameSpecificTags": ["#Tag1", "#Tag2", "#Tag3"],
  "topicSpecificTags": ["#Topic1", "#Topic2", "#Topic3"],
  "arabicTags": ["#ألعاب", "#قيمرز", "#العاب_فيديو"],
  "englishTags": ["#GamingClips", "#ShortsGaming", "#ViralGaming"]
}
Output only raw JSON.
""".trimIndent()

        return when (val result = callGeminiApi(prompt)) {
            is AiResult.NotConfigured -> AiResult.NotConfigured(result.message)
            is AiResult.Error -> AiResult.Error(result.message)
            is AiResult.Success -> {
                try {
                    val json = JSONObject(cleanJsonString(result.data))
                    fun jsonArrayToList(arr: JSONArray?): List<String> {
                        if (arr == null) return emptyList()
                        val list = mutableListOf<String>()
                        for (i in 0 until arr.length()) {
                            list.add(arr.getString(i))
                        }
                        return list
                    }
                    AiResult.Success(
                        HashtagsResult(
                            gamingTags = jsonArrayToList(json.optJSONArray("gamingTags")),
                            gameSpecificTags = jsonArrayToList(json.optJSONArray("gameSpecificTags")),
                            topicSpecificTags = jsonArrayToList(json.optJSONArray("topicSpecificTags")),
                            arabicTags = jsonArrayToList(json.optJSONArray("arabicTags")),
                            englishTags = jsonArrayToList(json.optJSONArray("englishTags"))
                        )
                    )
                } catch (e: Exception) {
                    AiResult.Error("Failed to parse hashtags: ${e.message}")
                }
            }
        }
    }

    override suspend fun generateKeywords(
        game: String,
        topic: String,
        platform: String
    ): AiResult<KeywordsResult> {
        val prompt = """
Generate search SEO keywords for gaming video:
Game: $game
Topic: $topic
Platform: $platform

Respond strictly in JSON:
{
  "primaryKeywords": ["keyword 1", "keyword 2", "keyword 3"],
  "secondaryKeywords": ["search phrase 1", "search phrase 2", "search phrase 3"],
  "longTailKeywords": ["how to find secret in game", "best location for item 2026", "complete beginner walkthrough"]
}
Output only raw JSON.
""".trimIndent()

        return when (val result = callGeminiApi(prompt)) {
            is AiResult.NotConfigured -> AiResult.NotConfigured(result.message)
            is AiResult.Error -> AiResult.Error(result.message)
            is AiResult.Success -> {
                try {
                    val json = JSONObject(cleanJsonString(result.data))
                    fun jsonArrayToList(arr: JSONArray?): List<String> {
                        if (arr == null) return emptyList()
                        val list = mutableListOf<String>()
                        for (i in 0 until arr.length()) {
                            list.add(arr.getString(i))
                        }
                        return list
                    }
                    AiResult.Success(
                        KeywordsResult(
                            primaryKeywords = jsonArrayToList(json.optJSONArray("primaryKeywords")),
                            secondaryKeywords = jsonArrayToList(json.optJSONArray("secondaryKeywords")),
                            longTailKeywords = jsonArrayToList(json.optJSONArray("longTailKeywords"))
                        )
                    )
                } catch (e: Exception) {
                    AiResult.Error("Failed to parse keywords: ${e.message}")
                }
            }
        }
    }

    override suspend fun testConnection(): AiResult<String> {
        return when (val result = callGeminiApi("Respond with: Connected successfully to SanX Studio Gemini Engine.")) {
            is AiResult.NotConfigured -> AiResult.NotConfigured(result.message)
            is AiResult.Error -> AiResult.Error(result.message)
            is AiResult.Success -> AiResult.Success("Connected successfully!")
        }
    }

    private fun cleanJsonString(raw: String): String {
        var trimmed = raw.trim()
        if (trimmed.startsWith("```json")) {
            trimmed = trimmed.removePrefix("```json")
        } else if (trimmed.startsWith("```")) {
            trimmed = trimmed.removePrefix("```")
        }
        if (trimmed.endsWith("```")) {
            trimmed = trimmed.removeSuffix("```")
        }
        return trimmed.trim()
    }
}
