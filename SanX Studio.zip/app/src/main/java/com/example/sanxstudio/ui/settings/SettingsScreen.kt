package com.example.sanxstudio.ui.settings

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.sanxstudio.ui.components.SanXButton
import com.example.sanxstudio.ui.components.SanXCard
import com.example.sanxstudio.ui.components.SanXSecondaryButton
import com.example.sanxstudio.ui.components.SanXTopBar
import com.example.sanxstudio.ui.localization.LocalStrings
import com.example.sanxstudio.ui.projects.FilterChip
import com.example.ui.theme.SanXBlack
import com.example.ui.theme.SanXCardBorder
import com.example.ui.theme.SanXCyan
import com.example.ui.theme.SanXGreenDark
import com.example.ui.theme.SanXNeonGreen
import com.example.ui.theme.SanXRed
import com.example.ui.theme.SanXSurface
import com.example.ui.theme.SanXSurfaceVariant
import com.example.ui.theme.SanXTextDim
import com.example.ui.theme.SanXTextMuted
import com.example.ui.theme.SanXTextWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: (() -> Unit)? = null,
    viewModel: SettingsViewModel = viewModel()
) {
    val context = LocalContext.current
    val strings = LocalStrings.current

    val currentLang by viewModel.currentLanguage.collectAsState()
    val savedApiKey by viewModel.apiKey.collectAsState()
    val selectedModel by viewModel.selectedModel.collectAsState()
    val notificationsEnabled by viewModel.notificationsEnabled.collectAsState()
    val testState by viewModel.testState.collectAsState()

    var apiKeyInput by remember(savedApiKey) { mutableStateOf(savedApiKey) }
    var keyVisible by remember { mutableStateOf(false) }
    var modelDropdownExpanded by remember { mutableStateOf(false) }

    val models = listOf(
        "gemini-2.5-flash" to "Gemini 2.5 Flash (Fastest, Recommended)",
        "gemini-2.5-pro" to "Gemini 2.5 Pro (Deep Logic & Reasoning)",
        "gemini-1.5-flash" to "Gemini 1.5 Flash",
        "gemini-1.5-pro" to "Gemini 1.5 Pro"
    )

    Scaffold(
        topBar = {
            SanXTopBar(
                title = strings.navSettings,
                showBack = onBack != null,
                onBackClick = { onBack?.invoke() }
            )
        },
        containerColor = SanXBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Language Setting
            SanXCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Language, contentDescription = null, tint = SanXNeonGreen, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(strings.languageOption, fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 15.sp)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FilterChip(
                            text = "English",
                            isSelected = currentLang == "en",
                            onClick = { viewModel.setLanguage("en") }
                        )
                        FilterChip(
                            text = "العربية (Arabic - RTL)",
                            isSelected = currentLang == "ar",
                            onClick = { viewModel.setLanguage("ar") }
                        )
                    }
                }
            }

            // Theme Info
            SanXCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Palette, contentDescription = null, tint = SanXCyan, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(strings.themeOption, fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 15.sp)
                            Text(strings.themeDarkNeon, color = SanXTextMuted, fontSize = 12.sp)
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = SanXGreenDark,
                        border = BorderStroke(1.dp, SanXNeonGreen)
                    ) {
                        Text(
                            text = "Active",
                            color = SanXNeonGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // Notification Reminders
            SanXCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Notifications, contentDescription = null, tint = SanXNeonGreen, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(strings.notificationOption, fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 15.sp)
                            Text("Scheduled production alerts for filming and uploads", color = SanXTextMuted, fontSize = 12.sp)
                        }
                    }

                    Switch(
                        checked = notificationsEnabled,
                        onCheckedChange = { viewModel.setNotificationsEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = SanXBlack,
                            checkedTrackColor = SanXNeonGreen
                        )
                    )
                }
            }

            // AI Provider Configuration (Gemini API)
            SanXCard(modifier = Modifier.fillMaxWidth(), borderGlow = true) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VpnKey, contentDescription = null, tint = SanXNeonGreen, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(strings.aiConfigTitle, fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 15.sp)
                    }

                    Text(
                        text = "SanX Studio connects to Google Gemini models to generate studio-grade scripts, titles, and thumbnails.",
                        color = SanXTextMuted,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )

                    // API Key Input
                    OutlinedTextField(
                        value = apiKeyInput,
                        onValueChange = {
                            apiKeyInput = it
                            viewModel.setApiKey(it)
                        },
                        label = { Text(strings.apiKeyLabel) },
                        placeholder = { Text(strings.apiKeyHint, color = SanXTextDim) },
                        modifier = Modifier.fillMaxWidth().testTag("settings_api_key_input"),
                        singleLine = true,
                        visualTransformation = if (keyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            IconButton(onClick = { keyVisible = !keyVisible }) {
                                Icon(
                                    imageVector = if (keyVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = "Toggle Key Visibility",
                                    tint = SanXTextDim
                                )
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SanXNeonGreen,
                            unfocusedBorderColor = SanXCardBorder,
                            focusedTextColor = SanXTextWhite,
                            unfocusedTextColor = SanXTextWhite
                        )
                    )

                    // Model Selector Dropdown
                    ExposedDropdownMenuBox(
                        expanded = modelDropdownExpanded,
                        onExpandedChange = { modelDropdownExpanded = !modelDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = models.firstOrNull { it.first == selectedModel }?.second ?: selectedModel,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(strings.modelSelectionLabel) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = modelDropdownExpanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SanXNeonGreen,
                                unfocusedBorderColor = SanXCardBorder,
                                focusedTextColor = SanXTextWhite,
                                unfocusedTextColor = SanXTextWhite
                            )
                        )

                        ExposedDropdownMenu(
                            expanded = modelDropdownExpanded,
                            onDismissRequest = { modelDropdownExpanded = false }
                        ) {
                            models.forEach { (id, label) ->
                                DropdownMenuItem(
                                    text = { Text(label, color = SanXTextWhite, fontSize = 13.sp) },
                                    onClick = {
                                        viewModel.setSelectedModel(id)
                                        modelDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Test Connection Button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        SanXButton(
                            text = strings.testConnection,
                            onClick = { viewModel.testConnection() },
                            icon = Icons.Default.Wifi,
                            modifier = Modifier.testTag("test_ai_connection_button")
                        )

                        if (testState is ConnectionTestState.Testing) {
                            CircularProgressIndicator(color = SanXNeonGreen, modifier = Modifier.size(24.dp))
                        }
                    }

                    // Test Result Feedback
                    when (val ts = testState) {
                        is ConnectionTestState.Success -> {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SanXNeonGreen, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(ts.message, color = SanXNeonGreen, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                        is ConnectionTestState.Error -> {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Error, contentDescription = null, tint = SanXRed, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(ts.message, color = SanXRed, fontSize = 12.sp)
                            }
                        }
                        else -> {}
                    }
                }
            }

            // About SanX Studio Card
            SanXCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(strings.aboutTitle, fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(strings.versionLabel, color = SanXNeonGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(strings.aboutDesc, color = SanXTextMuted, fontSize = 13.sp, lineHeight = 18.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "100% offline capability for local workspace, templates, calendar, analytics, and content vault.",
                        color = SanXTextDim,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(50.dp))
        }
    }
}
