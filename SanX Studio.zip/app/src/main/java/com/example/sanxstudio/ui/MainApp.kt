package com.example.sanxstudio.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.sanxstudio.data.repository.PreferencesRepository
import com.example.sanxstudio.ui.analytics.AnalyticsScreen
import com.example.sanxstudio.ui.calendar.CalendarScreen
import com.example.sanxstudio.ui.create.AiGeneratorScreen
import com.example.sanxstudio.ui.create.CreateHubScreen
import com.example.sanxstudio.ui.create.HashtagGeneratorScreen
import com.example.sanxstudio.ui.create.KeywordGeneratorScreen
import com.example.sanxstudio.ui.create.ScriptGeneratorScreen
import com.example.sanxstudio.ui.create.ThumbnailStudioScreen
import com.example.sanxstudio.ui.create.TitleGeneratorScreen
import com.example.sanxstudio.ui.home.HomeScreen
import com.example.sanxstudio.ui.localization.ArabicStrings
import com.example.sanxstudio.ui.localization.EnglishStrings
import com.example.sanxstudio.ui.localization.LocalStrings
import com.example.sanxstudio.ui.navigation.Screen
import com.example.sanxstudio.ui.onboarding.OnboardingScreen
import com.example.sanxstudio.ui.projects.ProjectCreatorScreen
import com.example.sanxstudio.ui.projects.ProjectWorkspaceScreen
import com.example.sanxstudio.ui.projects.ProjectsScreen
import com.example.sanxstudio.ui.search.GlobalSearchScreen
import com.example.sanxstudio.ui.settings.SettingsScreen
import com.example.sanxstudio.ui.vault.VaultScreen
import com.example.ui.theme.SanXBlack
import com.example.ui.theme.SanXCardBorder
import com.example.ui.theme.SanXGreenDark
import com.example.ui.theme.SanXGreenGlow
import com.example.ui.theme.SanXNeonGreen
import com.example.ui.theme.SanXSurface
import com.example.ui.theme.SanXTextDim
import com.example.ui.theme.SanXTextMuted
import com.example.ui.theme.SanXTextWhite

@Composable
fun MainApp(
    preferencesRepository: PreferencesRepository
) {
    val currentLang by preferencesRepository.appLanguageFlow.collectAsState(initial = "en")
    val hasCompletedOnboarding by preferencesRepository.hasCompletedOnboardingFlow.collectAsState(initial = null)

    if (hasCompletedOnboarding == null) {
        return // Wait for datastore
    }

    val strings = if (currentLang == "ar") ArabicStrings else EnglishStrings
    val layoutDirection = if (currentLang == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr

    CompositionLocalProvider(
        LocalStrings provides strings,
        LocalLayoutDirection provides layoutDirection
    ) {
        val navController = rememberNavController()
        val coroutineScope = rememberCoroutineScope()
        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = navBackStackEntry?.destination?.route

        val topLevelRoutes = listOf(
            Screen.Home.route,
            Screen.Projects.route,
            Screen.Create.route,
            Screen.Favorites.route,
            Screen.Settings.route
        )
        val showBottomBar = currentRoute in topLevelRoutes

        Scaffold(
            containerColor = SanXBlack,
            bottomBar = {
                AnimatedVisibility(
                    visible = showBottomBar,
                    enter = slideInVertically(initialOffsetY = { it }),
                    exit = slideOutVertically(targetOffsetY = { it })
                ) {
                    Surface(
                        color = SanXSurface,
                        border = BorderStroke(1.dp, SanXCardBorder)
                    ) {
                        NavigationBar(
                            containerColor = SanXSurface,
                            contentColor = SanXNeonGreen,
                            tonalElevation = 0.dp
                        ) {
                            // 1. Home
                            NavigationBarItem(
                                icon = { Icon(Icons.Default.Home, contentDescription = strings.navHome) },
                                label = { Text(strings.navHome, fontSize = 11.sp) },
                                selected = currentRoute == Screen.Home.route,
                                onClick = {
                                    navController.navigate(Screen.Home.route) {
                                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                colors = navItemColors()
                            )

                            // 2. Projects
                            NavigationBarItem(
                                icon = { Icon(Icons.Default.Folder, contentDescription = strings.navProjects) },
                                label = { Text(strings.navProjects, fontSize = 11.sp) },
                                selected = currentRoute == Screen.Projects.route,
                                onClick = {
                                    navController.navigate(Screen.Projects.route) {
                                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                colors = navItemColors()
                            )

                            // 3. Create (Highlighted Action)
                            NavigationBarItem(
                                icon = {
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .background(if (currentRoute == Screen.Create.route) SanXNeonGreen else SanXGreenDark),
                                        contentAlignment = androidx.compose.ui.Alignment.Center
                                    ) {
                                        Icon(
                                            Icons.Default.AutoAwesome,
                                            contentDescription = strings.navCreate,
                                            tint = if (currentRoute == Screen.Create.route) SanXBlack else SanXNeonGreen,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                },
                                label = { Text(strings.navCreate, fontSize = 11.sp, color = SanXNeonGreen) },
                                selected = currentRoute == Screen.Create.route,
                                onClick = {
                                    navController.navigate(Screen.Create.route) {
                                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                colors = navItemColors()
                            )

                            // 4. Vault (Favorites)
                            NavigationBarItem(
                                icon = { Icon(Icons.Default.FolderSpecial, contentDescription = strings.navVault) },
                                label = { Text(strings.navVault, fontSize = 11.sp) },
                                selected = currentRoute == Screen.Favorites.route,
                                onClick = {
                                    navController.navigate(Screen.Favorites.route) {
                                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                colors = navItemColors()
                            )

                            // 5. Settings
                            NavigationBarItem(
                                icon = { Icon(Icons.Default.Settings, contentDescription = strings.navSettings) },
                                label = { Text(strings.navSettings, fontSize = 11.sp) },
                                selected = currentRoute == Screen.Settings.route,
                                onClick = {
                                    navController.navigate(Screen.Settings.route) {
                                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                colors = navItemColors()
                            )
                        }
                    }
                }
            }
        ) { paddingValues ->
            NavHost(
                navController = navController,
                startDestination = if (hasCompletedOnboarding == true) Screen.Home.route else Screen.Onboarding.route,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // Onboarding
                composable(Screen.Onboarding.route) {
                    OnboardingScreen(
                        currentLanguage = currentLang,
                        onLanguageChange = { lang ->
                            coroutineScope.launch {
                                preferencesRepository.setSelectedLanguage(lang)
                            }
                        },
                        onFinishOnboarding = { games ->
                            coroutineScope.launch {
                                preferencesRepository.setPreferredContentTypes(games)
                                preferencesRepository.setOnboardingCompleted(true)
                            }
                            navController.navigate(Screen.Home.route) {
                                popUpTo(Screen.Onboarding.route) { inclusive = true }
                            }
                        }
                    )
                }

                // 1. Home
                composable(Screen.Home.route) {
                    HomeScreen(
                        onNavigateToNewProject = { navController.navigate(Screen.ProjectCreator.route) },
                        onNavigateToProject = { id -> navController.navigate(Screen.ProjectWorkspace.createRoute(id)) },
                        onNavigateToProjectsList = { navController.navigate(Screen.Projects.route) },
                        onNavigateToAiGenerator = { id -> navController.navigate(Screen.AiGenerator.createRoute(id)) },
                        onNavigateToScriptStudio = { id -> navController.navigate(Screen.ScriptStudio.createRoute(id)) },
                        onNavigateToTitleStudio = { id -> navController.navigate(Screen.TitleStudio.createRoute(id)) },
                        onNavigateToThumbnailStudio = { id -> navController.navigate(Screen.ThumbnailStudio.createRoute(id)) },
                        onNavigateToHashtags = { navController.navigate(Screen.HashtagStudio.route) },
                        onNavigateToKeywords = { navController.navigate(Screen.KeywordStudio.route) },
                        onNavigateToCalendar = { navController.navigate(Screen.ContentCalendar.route) },
                        onNavigateToAnalytics = { navController.navigate(Screen.Analytics.route) },
                        onNavigateToSearch = { navController.navigate(Screen.GlobalSearch.route) },
                        onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
                    )
                }

                // 2. Projects List
                composable(Screen.Projects.route) {
                    ProjectsScreen(
                        onNavigateToNewProject = { navController.navigate(Screen.ProjectCreator.route) },
                        onNavigateToProject = { id -> navController.navigate(Screen.ProjectWorkspace.createRoute(id)) }
                    )
                }

                // 3. Create Hub
                composable(Screen.Create.route) {
                    CreateHubScreen(
                        onNavigateToAiGenerator = { id -> navController.navigate(Screen.AiGenerator.createRoute(id)) },
                        onNavigateToScriptStudio = { id -> navController.navigate(Screen.ScriptStudio.createRoute(id)) },
                        onNavigateToTitleStudio = { id -> navController.navigate(Screen.TitleStudio.createRoute(id)) },
                        onNavigateToThumbnailStudio = { id -> navController.navigate(Screen.ThumbnailStudio.createRoute(id)) },
                        onNavigateToHashtags = { navController.navigate(Screen.HashtagStudio.route) },
                        onNavigateToKeywords = { navController.navigate(Screen.KeywordStudio.route) },
                        onNavigateToCalendar = { navController.navigate(Screen.ContentCalendar.route) },
                        onNavigateToAnalytics = { navController.navigate(Screen.Analytics.route) }
                    )
                }

                // 4. Vault (Favorites)
                composable(Screen.Favorites.route) {
                    VaultScreen()
                }

                // 5. Settings
                composable(Screen.Settings.route) {
                    SettingsScreen()
                }

                // Project Creator
                composable(Screen.ProjectCreator.route) {
                    ProjectCreatorScreen(
                        onBack = { navController.popBackStack() },
                        onProjectCreated = { id ->
                            navController.navigate(Screen.ProjectWorkspace.createRoute(id)) {
                                popUpTo(Screen.ProjectCreator.route) { inclusive = true }
                            }
                        }
                    )
                }

                // Project Workspace
                composable(
                    route = Screen.ProjectWorkspace.route,
                    arguments = listOf(navArgument("projectId") { type = NavType.LongType })
                ) { backStackEntry ->
                    val projectId = backStackEntry.arguments?.getLong("projectId") ?: 0L
                    ProjectWorkspaceScreen(
                        projectId = projectId,
                        onBack = { navController.popBackStack() },
                        onNavigateToAiGenerator = { id -> navController.navigate(Screen.AiGenerator.createRoute(id)) },
                        onNavigateToScriptStudio = { id -> navController.navigate(Screen.ScriptStudio.createRoute(id)) }
                    )
                }

                // AI Generator
                composable(
                    route = Screen.AiGenerator.route,
                    arguments = listOf(navArgument("projectId") {
                        type = NavType.LongType
                        defaultValue = -1L
                    })
                ) { backStackEntry ->
                    val pid = backStackEntry.arguments?.getLong("projectId")?.takeIf { it != -1L }
                    AiGeneratorScreen(
                        initialProjectId = pid,
                        onBack = { navController.popBackStack() },
                        onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
                    )
                }

                // Script Studio
                composable(
                    route = Screen.ScriptStudio.route,
                    arguments = listOf(navArgument("projectId") {
                        type = NavType.LongType
                        defaultValue = -1L
                    })
                ) { backStackEntry ->
                    val pid = backStackEntry.arguments?.getLong("projectId")?.takeIf { it != -1L }
                    ScriptGeneratorScreen(
                        initialProjectId = pid,
                        onBack = { navController.popBackStack() },
                        onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
                    )
                }

                // Title Studio
                composable(
                    route = Screen.TitleStudio.route,
                    arguments = listOf(navArgument("projectId") {
                        type = NavType.LongType
                        defaultValue = -1L
                    })
                ) { backStackEntry ->
                    val pid = backStackEntry.arguments?.getLong("projectId")?.takeIf { it != -1L }
                    TitleGeneratorScreen(
                        initialProjectId = pid,
                        onBack = { navController.popBackStack() },
                        onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
                    )
                }

                // Thumbnail Studio
                composable(
                    route = Screen.ThumbnailStudio.route,
                    arguments = listOf(navArgument("projectId") {
                        type = NavType.LongType
                        defaultValue = -1L
                    })
                ) { backStackEntry ->
                    val pid = backStackEntry.arguments?.getLong("projectId")?.takeIf { it != -1L }
                    ThumbnailStudioScreen(
                        initialProjectId = pid,
                        onBack = { navController.popBackStack() },
                        onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
                    )
                }

                // Hashtags
                composable(Screen.HashtagStudio.route) {
                    HashtagGeneratorScreen(
                        onBack = { navController.popBackStack() },
                        onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
                    )
                }

                // Keywords
                composable(Screen.KeywordStudio.route) {
                    KeywordGeneratorScreen(
                        onBack = { navController.popBackStack() },
                        onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
                    )
                }

                // Calendar
                composable(Screen.ContentCalendar.route) {
                    CalendarScreen(onBack = { navController.popBackStack() })
                }

                // Analytics
                composable(Screen.Analytics.route) {
                    AnalyticsScreen(onBack = { navController.popBackStack() })
                }

                // Global Search
                composable(Screen.GlobalSearch.route) {
                    GlobalSearchScreen(
                        onBack = { navController.popBackStack() },
                        onNavigateToProject = { id -> navController.navigate(Screen.ProjectWorkspace.createRoute(id)) }
                    )
                }
            }
        }
    }
}

@Composable
private fun navItemColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = SanXNeonGreen,
    unselectedIconColor = SanXTextMuted,
    selectedTextColor = SanXNeonGreen,
    unselectedTextColor = SanXTextMuted,
    indicatorColor = SanXGreenDark
)
