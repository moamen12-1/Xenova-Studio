package com.example.sanxstudio.ui.create

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.sanxstudio.data.ai.KeywordsResult
import com.example.sanxstudio.ui.components.LoadingStateView
import com.example.sanxstudio.ui.components.SanXButton
import com.example.sanxstudio.ui.components.SanXCard
import com.example.sanxstudio.ui.components.SanXTopBar
import com.example.sanxstudio.ui.localization.LocalStrings
import com.example.sanxstudio.ui.projects.FilterChip
import com.example.ui.theme.SanXBlack
import com.example.ui.theme.SanXCardBorder
import com.example.ui.theme.SanXCyan
import com.example.ui.theme.SanXGold
import com.example.ui.theme.SanXNeonGreen
import com.example.ui.theme.SanXSurface
import com.example.ui.theme.SanXSurfaceVariant
import com.example.ui.theme.SanXTextMuted
import com.example.ui.theme.SanXTextWhite

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun KeywordGeneratorScreen(
    onBack: () -> Unit,
    onNavigateToSettings: () -> Unit,
    viewModel: CreateViewModel = viewModel()
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val strings = LocalStrings.current
    val state by viewModel.keywordState.collectAsState()

    var game by remember { mutableStateOf("Resident Evil 4") }
    var topic by remember { mutableStateOf("Professional S+ Rank Guide") }
    var selectedPlatform by remember { mutableStateOf("YouTube") }

    val platforms = listOf("YouTube", "Google Search", "TikTok", "Twitch")

    val fallbackKeywords = remember(game, topic) {
        KeywordsResult(
            primaryKeywords = listOf("$game guide", "$game walkthrough", "$topic"),
            secondaryKeywords = listOf("$game tips and tricks", "$game speedrun", "how to beat $game", "$game 2026"),
            longTailKeywords = listOf(
                "how to get S+ rank in $game easily",
                "best weapon upgrades for $game",
                "$game secret skip locations"
            ),
            searchIntentExplanation = "High-intent viewers seeking step-by-step optimization, boss strategies, and time-saving shortcuts."
        )
    }

    Scaffold(
        topBar = {
            SanXTopBar(
                title = strings.keywordStudioTitle,
                showBack = true,
                onBackClick = onBack,
                onSettingsClick = onNavigateToSettings
            )
        },
        containerColor = SanXBlack
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                SanXCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Search Directives", fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 15.sp)

                        OutlinedTextField(
                            value = game,
                            onValueChange = { game = it },
                            label = { Text(strings.gameLabel) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SanXNeonGreen,
                                unfocusedBorderColor = SanXCardBorder,
                                focusedTextColor = SanXTextWhite,
                                unfocusedTextColor = SanXTextWhite
                            )
                        )

                        OutlinedTextField(
                            value = topic,
                            onValueChange = { topic = it },
                            label = { Text(strings.topicLabel) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SanXNeonGreen,
                                unfocusedBorderColor = SanXCardBorder,
                                focusedTextColor = SanXTextWhite,
                                unfocusedTextColor = SanXTextWhite
                            )
                        )

                        // Platform
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            platforms.forEach { p ->
                                FilterChip(
                                    text = p,
                                    isSelected = selectedPlatform == p,
                                    onClick = { selectedPlatform = p }
                                )
                            }
                        }

                        SanXButton(
                            text = "Analyze & Generate Keywords",
                            onClick = {
                                viewModel.generateKeywords(game, topic, selectedPlatform)
                            },
                            icon = Icons.Default.AutoAwesome,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            val activeKw = when (val s = state) {
                is GeneratorState.Success -> s.data
                else -> fallbackKeywords
            }

            if (state is GeneratorState.Loading) {
                item { LoadingStateView(message = "Extracting ranking search queries...") }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Target Search Terms", fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 16.sp)
                    SanXButton(
                        text = strings.copyKeywords,
                        onClick = {
                            val all = (activeKw.primary + activeKw.secondary + activeKw.longTail).joinToString(", ")
                            clipboardManager.setText(AnnotatedString(all))
                            Toast.makeText(context, "All keywords copied!", Toast.LENGTH_SHORT).show()
                        },
                        icon = Icons.Default.ContentCopy
                    )
                }
            }

            // Primary Keywords
            item {
                KeywordGroupCard(
                    title = "Primary High-Volume Keywords",
                    keywords = activeKw.primary,
                    color = SanXNeonGreen,
                    onCopy = {
                        clipboardManager.setText(AnnotatedString(activeKw.primary.joinToString(", ")))
                        Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                    }
                )
            }

            // Secondary Keywords
            item {
                KeywordGroupCard(
                    title = "Secondary Competitive Terms",
                    keywords = activeKw.secondary,
                    color = SanXCyan,
                    onCopy = {
                        clipboardManager.setText(AnnotatedString(activeKw.secondary.joinToString(", ")))
                        Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                    }
                )
            }

            // Long-Tail Keywords
            item {
                KeywordGroupCard(
                    title = "High-Conversion Long-Tail Queries",
                    keywords = activeKw.longTail,
                    color = SanXGold,
                    onCopy = {
                        clipboardManager.setText(AnnotatedString(activeKw.longTail.joinToString("\n")))
                        Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                    }
                )
            }

            // Search Intent Explanation
            item {
                SanXCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Audience Search Intent", fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = activeKw.intentExplanation,
                            color = SanXTextMuted,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun KeywordGroupCard(
    title: String,
    keywords: List<String>,
    color: androidx.compose.ui.graphics.Color,
    onCopy: () -> Unit
) {
    SanXCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, fontWeight = FontWeight.Bold, color = color, fontSize = 14.sp)
                IconButton(onClick = onCopy, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy Group", tint = SanXNeonGreen, modifier = Modifier.size(18.dp))
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                keywords.forEach { kw ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = SanXSurfaceVariant,
                        border = BorderStroke(1.dp, SanXCardBorder)
                    ) {
                        Text(
                            text = kw,
                            color = SanXTextWhite,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }
        }
    }
}
