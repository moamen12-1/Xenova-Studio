package com.example.sanxstudio.data.repository

import com.example.sanxstudio.data.db.AnalyticsDao
import com.example.sanxstudio.data.db.CalendarDao
import com.example.sanxstudio.data.db.FavoriteDao
import com.example.sanxstudio.data.db.IdeaDao
import com.example.sanxstudio.data.db.ProjectDao
import com.example.sanxstudio.data.db.ScriptDao
import com.example.sanxstudio.data.model.AnalyticsEntity
import com.example.sanxstudio.data.model.CalendarEntryEntity
import com.example.sanxstudio.data.model.ContentType
import com.example.sanxstudio.data.model.ContentTone
import com.example.sanxstudio.data.model.FavoriteEntity
import com.example.sanxstudio.data.model.FavoriteType
import com.example.sanxstudio.data.model.IdeaEntity
import com.example.sanxstudio.data.model.IdeaPriority
import com.example.sanxstudio.data.model.ProjectEntity
import com.example.sanxstudio.data.model.ProjectStatus
import com.example.sanxstudio.data.model.ScriptEntity
import com.example.sanxstudio.data.model.VideoFormat
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class SanXRepository(
    private val projectDao: ProjectDao,
    private val ideaDao: IdeaDao,
    private val scriptDao: ScriptDao,
    private val favoriteDao: FavoriteDao,
    private val analyticsDao: AnalyticsDao,
    private val calendarDao: CalendarDao
) {
    // Projects
    val allProjects: Flow<List<ProjectEntity>> = projectDao.getAllProjects()
    val favoriteProjects: Flow<List<ProjectEntity>> = projectDao.getFavoriteProjects()
    val projectCount: Flow<Int> = projectDao.getProjectCount()

    suspend fun getProjectById(id: Long): ProjectEntity? = projectDao.getProjectById(id)
    fun observeProjectById(id: Long): Flow<ProjectEntity?> = projectDao.observeProjectById(id)
    suspend fun insertProject(project: ProjectEntity): Long = projectDao.insertProject(project)
    suspend fun updateProject(project: ProjectEntity) = projectDao.updateProject(project)
    suspend fun deleteProject(project: ProjectEntity) = projectDao.deleteProject(project)
    suspend fun deleteProjectById(id: Long) = projectDao.deleteProjectById(id)
    fun searchProjects(query: String): Flow<List<ProjectEntity>> = projectDao.searchProjects(query)

    suspend fun toggleProjectFavorite(project: ProjectEntity) {
        val updated = project.copy(isFavorite = !project.isFavorite, updatedAt = System.currentTimeMillis())
        projectDao.updateProject(updated)
        if (updated.isFavorite) {
            favoriteDao.insertFavorite(
                FavoriteEntity(
                    type = FavoriteType.PROJECT.name,
                    targetId = updated.id,
                    title = updated.name,
                    subtitle = updated.game,
                    content = updated.description
                )
            )
        } else {
            favoriteDao.deleteByTypeAndTargetId(FavoriteType.PROJECT.name, updated.id)
        }
    }

    // Ideas
    val allIdeas: Flow<List<IdeaEntity>> = ideaDao.getAllIdeas()
    val favoriteIdeas: Flow<List<IdeaEntity>> = ideaDao.getFavoriteIdeas()
    val ideaCount: Flow<Int> = ideaDao.getIdeaCount()

    suspend fun insertIdea(idea: IdeaEntity): Long = ideaDao.insertIdea(idea)
    suspend fun updateIdea(idea: IdeaEntity) = ideaDao.updateIdea(idea)
    suspend fun deleteIdea(idea: IdeaEntity) = ideaDao.deleteIdea(idea)
    suspend fun deleteIdeaById(id: Long) = ideaDao.deleteIdeaById(id)
    fun searchIdeas(query: String): Flow<List<IdeaEntity>> = ideaDao.searchIdeas(query)

    suspend fun toggleIdeaFavorite(idea: IdeaEntity) {
        val updated = idea.copy(isFavorite = !idea.isFavorite)
        ideaDao.updateIdea(updated)
        if (updated.isFavorite) {
            favoriteDao.insertFavorite(
                FavoriteEntity(
                    type = FavoriteType.IDEA.name,
                    targetId = updated.id,
                    title = updated.title,
                    subtitle = updated.game,
                    content = updated.description
                )
            )
        } else {
            favoriteDao.deleteByTypeAndTargetId(FavoriteType.IDEA.name, updated.id)
        }
    }

    // Scripts
    val allScripts: Flow<List<ScriptEntity>> = scriptDao.getAllScripts()
    val favoriteScripts: Flow<List<ScriptEntity>> = scriptDao.getFavoriteScripts()
    val scriptCount: Flow<Int> = scriptDao.getScriptCount()

    suspend fun getScriptById(id: Long): ScriptEntity? = scriptDao.getScriptById(id)
    suspend fun insertScript(script: ScriptEntity): Long = scriptDao.insertScript(script)
    suspend fun updateScript(script: ScriptEntity) = scriptDao.updateScript(script)
    suspend fun deleteScript(script: ScriptEntity) = scriptDao.deleteScript(script)
    suspend fun deleteScriptById(id: Long) = scriptDao.deleteScriptById(id)
    fun searchScripts(query: String): Flow<List<ScriptEntity>> = scriptDao.searchScripts(query)

    suspend fun toggleScriptFavorite(script: ScriptEntity) {
        val updated = script.copy(isFavorite = !script.isFavorite)
        scriptDao.updateScript(updated)
        if (updated.isFavorite) {
            favoriteDao.insertFavorite(
                FavoriteEntity(
                    type = FavoriteType.SCRIPT.name,
                    targetId = updated.id,
                    title = updated.title,
                    subtitle = updated.game,
                    content = "${script.hook}\n\n${script.mainContent}"
                )
            )
        } else {
            favoriteDao.deleteByTypeAndTargetId(FavoriteType.SCRIPT.name, updated.id)
        }
    }

    // Favorites
    val allFavorites: Flow<List<FavoriteEntity>> = favoriteDao.getAllFavorites()
    fun getFavoritesByType(type: String): Flow<List<FavoriteEntity>> = favoriteDao.getFavoritesByType(type)
    val favoriteCount: Flow<Int> = favoriteDao.getFavoriteCount()

    suspend fun insertFavorite(favorite: FavoriteEntity): Long = favoriteDao.insertFavorite(favorite)
    suspend fun updateFavorite(favorite: FavoriteEntity) = favoriteDao.updateFavorite(favorite)
    suspend fun deleteFavorite(favorite: FavoriteEntity) = favoriteDao.deleteFavorite(favorite)
    suspend fun deleteFavoriteById(id: Long) = favoriteDao.deleteFavoriteById(id)

    // Analytics
    val allAnalytics: Flow<List<AnalyticsEntity>> = analyticsDao.getAllAnalytics()
    suspend fun insertAnalytics(analytics: AnalyticsEntity): Long = analyticsDao.insertAnalytics(analytics)
    suspend fun updateAnalytics(analytics: AnalyticsEntity) = analyticsDao.updateAnalytics(analytics)
    suspend fun deleteAnalytics(analytics: AnalyticsEntity) = analyticsDao.deleteAnalytics(analytics)
    suspend fun deleteAnalyticsById(id: Long) = analyticsDao.deleteAnalyticsById(id)

    // Calendar
    val allCalendarEntries: Flow<List<CalendarEntryEntity>> = calendarDao.getAllCalendarEntries()
    suspend fun insertCalendarEntry(entry: CalendarEntryEntity): Long = calendarDao.insertCalendarEntry(entry)
    suspend fun updateCalendarEntry(entry: CalendarEntryEntity) = calendarDao.updateCalendarEntry(entry)
    suspend fun deleteCalendarEntry(entry: CalendarEntryEntity) = calendarDao.deleteCalendarEntry(entry)
    suspend fun deleteCalendarEntryById(id: Long) = calendarDao.deleteCalendarEntryById(id)

    // Seed sample demo content on initial launch if empty
    suspend fun checkAndSeedSampleDataIfNeeded() {
        val existingCount = projectDao.getProjectCount().first()
        if (existingCount == 0) {
            // Seed 1 demo project (clearly labeled DEMO as required by prompt)
            val demoProject = ProjectEntity(
                name = "[DEMO] GTA San Andreas Rare Motorcycle",
                game = "GTA San Andreas",
                contentType = ContentType.YOUTUBE_SHORTS.name,
                language = "en",
                videoFormat = VideoFormat.RATIO_9_16.name,
                targetPlatform = "YouTube Shorts",
                description = "Demonstration project: Locating the secret hidden FCR-900 sports motorcycle on the Las Venturas rooftop.",
                status = ProjectStatus.WRITING.name,
                hook = "Did you know there is a secret motorcycle hidden on this Las Venturas roof that 99% of GTA players walked right past?",
                idea = "Show the exact map coordinates and stunt jump needed to get the rare FCR-900 with customized midnight purple livery.",
                script = "HOOK: Stop driving that slow rusty sedan in GTA San Andreas!\n\nINTRO: In today's quick guide, I'll reveal the rarest hidden motorcycle spawn location that was tucked away by Rockstar.\n\nMAIN: Head over to northern Las Venturas near the Julius Thruway. Look for the multi-level parking garage. Instead of driving up normally, take the side ramp with full nitro.\n\nCLIMAX: Land right on the private penthouse deck, and boom—there sits the pristine custom-painted FCR-900 ready to ride!\n\nCTA: Drop a like and subscribe for more secret GTA gaming locations!",
                title = "The SECRET GTA Motorcycle 99% of Players Missed!",
                thumbnailPrompt = "A cinematic dramatic low-angle shot of a sleek purple sports motorcycle parked on a high neon Las Venturas penthouse roof, rainy midnight reflections, neon sign glow, 9:16 aspect ratio, vibrant colors, gaming concept art.",
                thumbnailConcept = "Center foreground: Neon purple motorcycle glowing under night rain. Background: Las Venturas skyline blur with huge bold text: 'SECRET BIKE?!'",
                hashtags = "#GTASanAndreas #GamingShorts #GTASecrets #GamingTips #GTAGaming #RockstarGames",
                keywords = "GTA San Andreas rare motorcycle, GTA hidden locations, GTA secret vehicles, FCR-900 location, GTA tips 2026",
                callToAction = "Drop your favorite GTA vehicle in the comments and subscribe for part 2!",
                notes = "Sample demo project for SanX Studio testing. Feel free to edit or delete.",
                isFavorite = true
            )
            val pId = projectDao.insertProject(demoProject)

            // Seed demo ideas
            ideaDao.insertIdea(
                IdeaEntity(
                    title = "Top 5 Secret Minecraft Caves Most Players Never Explore",
                    game = "Minecraft",
                    description = "A deep dive exploration comparing deep dark biome ancient cities with custom lush caverns.",
                    category = "Guide / Secrets",
                    priority = IdeaPriority.HIGH.name,
                    isFavorite = false
                )
            )
            ideaDao.insertIdea(
                IdeaEntity(
                    title = "Scariest Easter Egg in Horror Games: The Silent Radio",
                    game = "Horror Games",
                    description = "Exploring mysterious audio frequencies hidden in classic psychological horror titles.",
                    category = "Lore / Mystery",
                    priority = IdeaPriority.TOP.name,
                    isFavorite = true
                )
            )

            // Seed demo analytics
            analyticsDao.insertAnalytics(
                AnalyticsEntity(
                    projectId = pId,
                    title = "[DEMO] Secret GTA Motorcycle Short",
                    platform = "YouTube Shorts",
                    views = 12450,
                    likes = 1420,
                    comments = 184,
                    shares = 96,
                    followersGained = 310,
                    avgWatchTimeSeconds = 38,
                    videoDurationSeconds = 45
                )
            )

            // Seed demo calendar entry
            calendarDao.insertCalendarEntry(
                CalendarEntryEntity(
                    projectId = pId,
                    title = "Publish GTA Secrets Short",
                    game = "GTA San Andreas",
                    plannedDate = System.currentTimeMillis() + 86400000L * 2,
                    platform = "YouTube Shorts",
                    status = "PLANNED",
                    notes = "Schedule for Friday 6 PM peak creator gaming hours"
                )
            )
        }
    }
}
