package com.example.sanxstudio.ui.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.Title
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.sanxstudio.data.model.ProjectEntity
import com.example.sanxstudio.ui.components.EmptyStateView
import com.example.sanxstudio.ui.components.SanXButton
import com.example.sanxstudio.ui.components.SanXCard
import com.example.sanxstudio.ui.components.SanXTopBar
import com.example.sanxstudio.ui.components.StatusBadge
import com.example.sanxstudio.ui.localization.LocalStrings
import com.example.ui.theme.SanXBlack
import com.example.ui.theme.SanXBlue
import com.example.ui.theme.SanXCardBorder
import com.example.ui.theme.SanXCyan
import com.example.ui.theme.SanXGold
import com.example.ui.theme.SanXGreenDark
import com.example.ui.theme.SanXGreenGlow
import com.example.ui.theme.SanXNeonGreen
import com.example.ui.theme.SanXPurple
import com.example.ui.theme.SanXRed
import com.example.ui.theme.SanXSurface
import com.example.ui.theme.SanXSurfaceVariant
import com.example.ui.theme.SanXTextDim
import com.example.ui.theme.SanXTextMuted
import com.example.ui.theme.SanXTextWhite
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    onNavigateToNewProject: () -> Unit,
    onNavigateToProject: (Long) -> Unit,
    onNavigateToProjectsList: () -> Unit,
    onNavigateToAiGenerator: (Long?) -> Unit,
    onNavigateToScriptStudio: (Long?) -> Unit,
    onNavigateToTitleStudio: (Long?) -> Unit,
    onNavigateToThumbnailStudio: (Long?) -> Unit,
    onNavigateToHashtags: () -> Unit,
    onNavigateToKeywords: () -> Unit,
    onNavigateToCalendar: () -> Unit,
    onNavigateToAnalytics: () -> Unit,
    onNavigateToSearch: () -> Unit,
    onNavigateToSettings: () -> Unit,
    viewModel: HomeViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val strings = LocalStrings.current

    Scaffold(
        topBar = {
            SanXTopBar(
                title = "SanX Studio",
                onSearchClick = onNavigateToSearch,
                onSettingsClick = onNavigateToSettings
            )
        },
        containerColor = SanXBlack
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Hero Banner & New Project Button
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    color = SanXSurface,
                    border = BorderStroke(1.dp, SanXCardBorder)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.horizontalGradient(
                                    listOf(SanXGreenDark.copy(alpha = 0.5f), Color.Transparent)
                                )
                            )
                            .padding(18.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = strings.welcomeBack,
                                        fontSize = 13.sp,
                                        color = SanXTextMuted,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = strings.appTagline,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Black,
                                        color = SanXTextWhite
                                    )
                                }
                                SanXButton(
                                    text = strings.newProject,
                                    onClick = onNavigateToNewProject,
                                    icon = Icons.Default.Add,
                                    modifier = Modifier.testTag("home_new_project_button")
                                )
                            }
                        }
                    }
                }
            }

            // Creator Quick Stats Grid
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatCard(
                        count = uiState.projectCount,
                        label = strings.statProjects,
                        icon = Icons.Default.Folder,
                        accentColor = SanXNeonGreen,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        count = uiState.ideaCount,
                        label = strings.statIdeas,
                        icon = Icons.Default.Lightbulb,
                        accentColor = SanXGold,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        count = uiState.scriptCount,
                        label = strings.statScripts,
                        icon = Icons.Default.EditNote,
                        accentColor = SanXCyan,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        count = uiState.favoriteCount,
                        label = strings.statFavorites,
                        icon = Icons.Default.Star,
                        accentColor = SanXPurple,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Quick Create Grid
            item {
                Column {
                    Text(
                        text = strings.quickCreate,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = SanXTextWhite,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        maxItemsInEachRow = 2
                    ) {
                        QuickActionItem(
                            icon = Icons.Default.Lightbulb,
                            title = strings.generateIdea,
                            color = SanXGold,
                            onClick = { onNavigateToAiGenerator(null) },
                            modifier = Modifier.weight(1f)
                        )
                        QuickActionItem(
                            icon = Icons.Default.EditNote,
                            title = strings.generateScript,
                            color = SanXCyan,
                            onClick = { onNavigateToScriptStudio(null) },
                            modifier = Modifier.weight(1f)
                        )
                        QuickActionItem(
                            icon = Icons.Default.Title,
                            title = strings.generateTitle,
                            color = SanXPurple,
                            onClick = { onNavigateToTitleStudio(null) },
                            modifier = Modifier.weight(1f)
                        )
                        QuickActionItem(
                            icon = Icons.Default.Image,
                            title = strings.thumbnailPrompt,
                            color = SanXNeonGreen,
                            onClick = { onNavigateToThumbnailStudio(null) },
                            modifier = Modifier.weight(1f)
                        )
                        QuickActionItem(
                            icon = Icons.Default.Tag,
                            title = strings.hashtags,
                            color = SanXBlue,
                            onClick = onNavigateToHashtags,
                            modifier = Modifier.weight(1f)
                        )
                        QuickActionItem(
                            icon = Icons.Default.Key,
                            title = strings.keywords,
                            color = SanXGold,
                            onClick = onNavigateToKeywords,
                            modifier = Modifier.weight(1f)
                        )
                        QuickActionItem(
                            icon = Icons.Default.CalendarMonth,
                            title = strings.calendar,
                            color = SanXCyan,
                            onClick = onNavigateToCalendar,
                            modifier = Modifier.weight(1f)
                        )
                        QuickActionItem(
                            icon = Icons.Default.Insights,
                            title = strings.analytics,
                            color = SanXRed,
                            onClick = onNavigateToAnalytics,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Recent Projects
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.recentProjects,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = SanXTextWhite
                    )
                    if (uiState.projects.isNotEmpty()) {
                        TextButton(onClick = onNavigateToProjectsList) {
                            Text(
                                text = strings.viewAll,
                                color = SanXNeonGreen,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            if (uiState.projects.isEmpty()) {
                item {
                    SanXCard(modifier = Modifier.fillMaxWidth()) {
                        EmptyStateView(
                            icon = Icons.Default.Folder,
                            title = strings.noProjectsYet,
                            description = strings.createFirstProject,
                            buttonText = strings.newProject,
                            onButtonClick = onNavigateToNewProject
                        )
                    }
                }
            } else {
                items(uiState.projects, key = { it.id }) { project ->
                    ProjectCardItem(
                        project = project,
                        onClick = { onNavigateToProject(project.id) },
                        onFavoriteClick = { viewModel.toggleFavorite(project) },
                        onDeleteClick = { viewModel.deleteProject(project) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun StatCard(
    count: Int,
    label: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = SanXSurface,
        border = BorderStroke(1.dp, SanXCardBorder)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = count.toString(),
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                color = SanXTextWhite
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = SanXTextMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun QuickActionItem(
    icon: ImageVector,
    title: String,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = SanXSurface,
        border = BorderStroke(1.dp, SanXCardBorder)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = SanXTextWhite,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun ProjectCardItem(
    project: ProjectEntity,
    onClick: () -> Unit,
    onFavoriteClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val dateString = remember(project.updatedAt) {
        SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(project.updatedAt))
    }

    SanXCard(
        modifier = Modifier.fillMaxWidth(),
        borderGlow = project.isFavorite,
        onClick = onClick
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = project.name,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = SanXTextWhite,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        if (project.name.startsWith("[DEMO]")) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(SanXGreenDark)
                                    .padding(horizontal = 5.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "DEMO",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black,
                                    color = SanXNeonGreen
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${project.game} • ${project.targetPlatform}",
                        fontSize = 12.sp,
                        color = SanXTextMuted
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onFavoriteClick, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = if (project.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = "Favorite",
                            tint = if (project.isFavorite) SanXGold else SanXTextDim,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    IconButton(onClick = onDeleteClick, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Delete",
                            tint = SanXTextDim,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            if (project.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = project.description,
                    fontSize = 13.sp,
                    color = SanXTextMuted,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusBadge(status = project.status)
                Text(
                    text = dateString,
                    fontSize = 11.sp,
                    color = SanXTextDim
                )
            }
        }
    }
}
