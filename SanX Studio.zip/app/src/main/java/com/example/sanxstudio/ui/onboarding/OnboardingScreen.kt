package com.example.sanxstudio.ui.onboarding

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.Title
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.sanxstudio.ui.components.SanXButton
import com.example.sanxstudio.ui.components.SanXSecondaryButton
import com.example.ui.theme.SanXBlack
import com.example.ui.theme.SanXCardBorder
import com.example.ui.theme.SanXCyan
import com.example.ui.theme.SanXGreenDark
import com.example.ui.theme.SanXNeonGreen
import com.example.ui.theme.SanXSurface
import com.example.ui.theme.SanXSurfaceVariant
import com.example.ui.theme.SanXTextDim
import com.example.ui.theme.SanXTextMuted
import com.example.ui.theme.SanXTextWhite

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OnboardingScreen(
    currentLanguage: String,
    onLanguageChange: (String) -> Unit,
    onFinishOnboarding: (Set<String>) -> Unit
) {
    var step by remember { mutableIntStateOf(0) }
    var selectedLanguage by remember { mutableStateOf(currentLanguage) }
    val selectedGames = remember {
        mutableStateOf(mutableSetOf("GTA", "Minecraft", "PC Games", "Mobile Games"))
    }

    val availableGames = listOf(
        "GTA",
        "Minecraft",
        "Horror Games",
        "Football (FC/eFootball)",
        "Shooters (Valorant/CS/COD)",
        "Mobile Games (PUBG/FreeFire)",
        "Roblox",
        "Story & RPG",
        "Other Games"
    )

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = SanXBlack
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(24.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Step Indicator
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                repeat(4) { index ->
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 4.dp)
                            .height(4.dp)
                            .width(if (step == index) 28.dp else 14.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(if (step == index) SanXNeonGreen else SanXCardBorder)
                    )
                }
            }

            // Animated Step Content
            AnimatedContent(
                targetState = step,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                modifier = Modifier.weight(1f),
                label = "onboarding_steps"
            ) { currentStep ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    when (currentStep) {
                        0 -> {
                            // Step 1: Welcome & Logo
                            Box(
                                modifier = Modifier
                                    .size(96.dp)
                                    .clip(RoundedCornerShape(24.dp))
                                    .background(
                                        Brush.linearGradient(
                                            listOf(SanXNeonGreen, SanXCyan)
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "SX",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 42.sp,
                                    color = SanXBlack
                                )
                            }
                            Spacer(modifier = Modifier.height(28.dp))
                            Text(
                                text = "SanX Studio",
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Black,
                                color = SanXTextWhite,
                                letterSpacing = (-0.5).sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (selectedLanguage == "ar") "اصنع محتوى ألعاب أفضل" else "Create Better Gaming Content",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = SanXNeonGreen
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = if (selectedLanguage == "ar")
                                    "المساعد المحمول المتكامل لصناع محتوى الألعاب والستريمرز. خطط، ولّد السكربتات، وابنِ مشاريعك من مكان واحد."
                                else
                                    "The premier mobile creator suite built specifically for gaming creators. Brainstorm, script, design, and organize your channel from one place.",
                                fontSize = 14.sp,
                                color = SanXTextMuted,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 16.dp),
                                lineHeight = 22.sp
                            )
                        }

                        1 -> {
                            // Step 2: What you can do
                            Text(
                                text = if (selectedLanguage == "ar") "كل ما تحتاجه للإنشاء" else "Everything You Need to Create",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = SanXTextWhite,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(24.dp))
                            FeaturePill(
                                icon = Icons.Default.AutoAwesome,
                                title = if (selectedLanguage == "ar") "أفكار وفكك فيديو ذكية" else "Hooks & Viral Video Ideas",
                                subtitle = if (selectedLanguage == "ar") "بدايات قوية تجذب المشاهد في أول 3 ثوانٍ" else "Hook viewers in the first 3 crucial seconds"
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            FeaturePill(
                                icon = Icons.Default.EditNote,
                                title = if (selectedLanguage == "ar") "استوديو السكربتات الشامل" else "Full Gaming Script Studio",
                                subtitle = if (selectedLanguage == "ar") "سكربتات جاهزة مع نمط مخصص للصوت الآلي (TTS)" else "Timestamps, climax cues, and TTS-friendly mode"
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            FeaturePill(
                                icon = Icons.Default.Title,
                                title = if (selectedLanguage == "ar") "عناوين عالية النقر (CTR)" else "Clickable Gaming Titles",
                                subtitle = if (selectedLanguage == "ar") "عناوين تصنيفية: غموض، رعب، حماس، فضول" else "Curiosity, mystery, dramatic, and short categories"
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            FeaturePill(
                                icon = Icons.Default.Image,
                                title = if (selectedLanguage == "ar") "تصميم ومفاهيم المصغرات" else "Thumbnail Concepts & Prompts",
                                subtitle = if (selectedLanguage == "ar") "أبعاد مخصصة وبرومبت جاهز لمولدات الذكاء الاصطناعي" else "Composition, lighting, and AI generator prompts"
                            )
                        }

                        2 -> {
                            // Step 3: Language Choice
                            Text(
                                text = if (selectedLanguage == "ar") "اختر لغتك المفضلة" else "Select Your Language",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = SanXTextWhite
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (selectedLanguage == "ar") "يمكنك تغيير اللغة لاحقاً من الإعدادات" else "You can always change this later in Settings",
                                fontSize = 14.sp,
                                color = SanXTextMuted
                            )
                            Spacer(modifier = Modifier.height(32.dp))

                            LanguageCard(
                                title = "English",
                                subtitle = "Left-to-Right layout",
                                isSelected = selectedLanguage == "en",
                                onClick = {
                                    selectedLanguage = "en"
                                    onLanguageChange("en")
                                }
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            LanguageCard(
                                title = "العربية (Arabic)",
                                subtitle = "تنسيق متكامل يدعم اليمين لليسار (RTL)",
                                isSelected = selectedLanguage == "ar",
                                onClick = {
                                    selectedLanguage = "ar"
                                    onLanguageChange("ar")
                                }
                            )
                        }

                        3 -> {
                            // Step 4: Preferred Content Types
                            Text(
                                text = if (selectedLanguage == "ar") "ما هي الألعاب التي تصنع عنها محتوى؟" else "What games do you create content for?",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = SanXTextWhite,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (selectedLanguage == "ar") "اختر واحدة أو أكثر لتخصيص اقتراحاتك" else "Select your favorites to customize your creator workspace",
                                fontSize = 13.sp,
                                color = SanXTextMuted,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(24.dp))

                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                availableGames.forEach { game ->
                                    val isSelected = selectedGames.value.contains(game)
                                    Box(
                                        modifier = Modifier
                                            .padding(horizontal = 4.dp)
                                            .clip(RoundedCornerShape(20.dp))
                                            .background(if (isSelected) SanXGreenDark else SanXSurfaceVariant)
                                            .border(
                                                width = if (isSelected) 1.5.dp else 1.dp,
                                                color = if (isSelected) SanXNeonGreen else SanXCardBorder,
                                                shape = RoundedCornerShape(20.dp)
                                            )
                                            .clickable {
                                                val newSet = selectedGames.value.toMutableSet()
                                                if (isSelected) newSet.remove(game) else newSet.add(game)
                                                selectedGames.value = newSet
                                            }
                                            .padding(horizontal = 14.dp, vertical = 9.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            if (isSelected) {
                                                Icon(
                                                    imageVector = Icons.Default.Check,
                                                    contentDescription = null,
                                                    tint = SanXNeonGreen,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                            }
                                            Text(
                                                text = game,
                                                color = if (isSelected) SanXNeonGreen else SanXTextWhite,
                                                fontSize = 13.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Navigation Buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (step > 0) {
                    SanXSecondaryButton(
                        text = if (selectedLanguage == "ar") "السابق" else "Back",
                        onClick = { step-- }
                    )
                } else {
                    Spacer(modifier = Modifier.width(8.dp))
                }

                if (step < 3) {
                    SanXButton(
                        text = if (selectedLanguage == "ar") "التالي" else "Next",
                        onClick = { step++ }
                    )
                } else {
                    SanXButton(
                        text = if (selectedLanguage == "ar") "ابدأ الآن" else "Get Started",
                        onClick = {
                            onFinishOnboarding(selectedGames.value)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun FeaturePill(
    icon: ImageVector,
    title: String,
    subtitle: String
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = SanXSurface,
        border = BorderStroke(1.dp, SanXCardBorder)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(SanXSurfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = SanXNeonGreen, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = subtitle, color = SanXTextMuted, fontSize = 12.sp, lineHeight = 16.sp)
            }
        }
    }
}

@Composable
private fun LanguageCard(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = if (isSelected) SanXGreenDark else SanXSurface,
        border = BorderStroke(
            width = if (isSelected) 1.8.dp else 1.dp,
            color = if (isSelected) SanXNeonGreen else SanXCardBorder
        )
    ) {
        Row(
            modifier = Modifier.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Language,
                    contentDescription = null,
                    tint = if (isSelected) SanXNeonGreen else SanXTextMuted,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) SanXNeonGreen else SanXTextWhite,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = subtitle,
                        color = SanXTextMuted,
                        fontSize = 12.sp
                    )
                }
            }

            if (isSelected) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(SanXNeonGreen),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = SanXBlack,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
