package com.example.sanxstudio.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.sanxstudio.data.model.ProjectStatus
import com.example.sanxstudio.ui.localization.LocalStrings
import com.example.ui.theme.SanXBlack
import com.example.ui.theme.SanXBlue
import com.example.ui.theme.SanXCardBorder
import com.example.ui.theme.SanXCardBorderGlow
import com.example.ui.theme.SanXCharcoal
import com.example.ui.theme.SanXCyan
import com.example.ui.theme.SanXGold
import com.example.ui.theme.SanXGreenGlow
import com.example.ui.theme.SanXNeonGreen
import com.example.ui.theme.SanXPurple
import com.example.ui.theme.SanXRed
import com.example.ui.theme.SanXSurface
import com.example.ui.theme.SanXSurfaceVariant
import com.example.ui.theme.SanXTextDim
import com.example.ui.theme.SanXTextMuted
import com.example.ui.theme.SanXTextWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SanXTopBar(
    title: String,
    showBack: Boolean = false,
    onBackClick: () -> Unit = {},
    onSearchClick: (() -> Unit)? = null,
    onNotificationClick: (() -> Unit)? = null,
    onSettingsClick: (() -> Unit)? = null,
    actions: @Composable () -> Unit = {}
) {
    TopAppBar(
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!showBack) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(SanXNeonGreen, SanXCyan)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "SX",
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            color = SanXBlack
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                }
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 19.sp,
                    color = SanXTextWhite,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        },
        navigationIcon = {
            if (showBack) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("top_bar_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = SanXTextWhite
                    )
                }
            }
        },
        actions = {
            if (onSearchClick != null) {
                IconButton(onClick = onSearchClick, modifier = Modifier.testTag("top_bar_search_button")) {
                    Icon(Icons.Default.Search, contentDescription = "Search", tint = SanXTextMuted)
                }
            }
            if (onNotificationClick != null) {
                IconButton(onClick = onNotificationClick, modifier = Modifier.testTag("top_bar_notif_button")) {
                    Icon(Icons.Default.Notifications, contentDescription = "Notifications", tint = SanXTextMuted)
                }
            }
            if (onSettingsClick != null) {
                IconButton(onClick = onSettingsClick, modifier = Modifier.testTag("top_bar_settings_button")) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = SanXTextMuted)
                }
            }
            actions()
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = SanXBlack
        )
    )
}

@Composable
fun SanXCard(
    modifier: Modifier = Modifier,
    borderGlow: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val border = if (borderGlow) {
        BorderStroke(1.5.dp, SanXNeonGreen)
    } else {
        BorderStroke(1.dp, SanXCardBorder)
    }

    Surface(
        modifier = modifier
            .then(
                if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
            ),
        shape = RoundedCornerShape(16.dp),
        color = SanXSurface,
        border = border,
        tonalElevation = 2.dp
    ) {
        content()
    }
}

@Composable
fun SanXButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        modifier = modifier
            .height(50.dp)
            .shadow(elevation = if (enabled) 6.dp else 0.dp, shape = RoundedCornerShape(14.dp), ambientColor = SanXNeonGreen, spotColor = SanXNeonGreen),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = SanXNeonGreen,
            contentColor = SanXBlack,
            disabledContainerColor = SanXCardBorder,
            disabledContentColor = SanXTextDim
        ),
        enabled = enabled,
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp)
    ) {
        if (icon != null) {
            Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
        }
        Text(
            text = text,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
        )
    }
}

@Composable
fun SanXSecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(48.dp),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.2.dp, SanXCardBorder),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = SanXSurfaceVariant,
            contentColor = SanXTextWhite
        ),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
    ) {
        if (icon != null) {
            Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(18.dp), tint = SanXNeonGreen)
            Spacer(modifier = Modifier.width(6.dp))
        }
        Text(
            text = text,
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp
        )
    }
}

@Composable
fun StatusBadge(status: String) {
    val (bgColor, textColor) = when (status) {
        ProjectStatus.IDEA.name -> Pair(Color(0xFF263042), SanXTextMuted)
        ProjectStatus.WRITING.name -> Pair(Color(0xFF3B2F10), SanXGold)
        ProjectStatus.RECORDING.name -> Pair(Color(0xFF3F1720), SanXRed)
        ProjectStatus.EDITING.name -> Pair(Color(0xFF2E1940), SanXPurple)
        ProjectStatus.READY.name -> Pair(Color(0xFF0F323D), SanXCyan)
        ProjectStatus.PUBLISHED.name -> Pair(Color(0xFF0C381E), SanXNeonGreen)
        else -> Pair(SanXSurfaceVariant, SanXTextMuted)
    }

    val display = when (status) {
        ProjectStatus.IDEA.name -> "IDEA"
        ProjectStatus.WRITING.name -> "WRITING"
        ProjectStatus.RECORDING.name -> "RECORDING"
        ProjectStatus.EDITING.name -> "EDITING"
        ProjectStatus.READY.name -> "READY"
        ProjectStatus.PUBLISHED.name -> "PUBLISHED"
        else -> status
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(0.8.dp, textColor.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = display,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = textColor,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun EmptyStateView(
    icon: ImageVector,
    title: String,
    description: String,
    buttonText: String? = null,
    onButtonClick: (() -> Unit)? = null
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(SanXSurfaceVariant)
                .border(1.dp, SanXCardBorder, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = SanXNeonGreen,
                modifier = Modifier.size(34.dp)
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = title,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = SanXTextWhite,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = description,
            fontSize = 14.sp,
            color = SanXTextMuted,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        if (buttonText != null && onButtonClick != null) {
            Spacer(modifier = Modifier.height(20.dp))
            SanXButton(text = buttonText, onClick = onButtonClick)
        }
    }
}

@Composable
fun LoadingStateView(message: String) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(80.dp)
                .scale(scale)
                .clip(CircleShape)
                .background(SanXGreenGlow),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(
                modifier = Modifier.size(48.dp),
                color = SanXNeonGreen,
                strokeWidth = 3.5.dp
            )
        }
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = message,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            color = SanXNeonGreen,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun SanXBottomBar(
    currentRoute: String,
    onNavigate: (String) -> Unit,
    onCreateClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding(),
        color = SanXBlack,
        border = BorderStroke(1.dp, SanXCardBorder.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Home
            BottomNavItem(
                iconSelected = Icons.Filled.Home,
                iconUnselected = Icons.Outlined.Home,
                label = LocalStrings.current.navHome,
                isSelected = currentRoute == "home",
                onClick = { onNavigate("home") }
            )

            // Projects
            BottomNavItem(
                iconSelected = Icons.Filled.Folder,
                iconUnselected = Icons.Outlined.Folder,
                label = LocalStrings.current.navProjects,
                isSelected = currentRoute == "projects",
                onClick = { onNavigate("projects") }
            )

            // Central Glowing Create Button
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .shadow(elevation = 12.dp, shape = CircleShape, ambientColor = SanXNeonGreen, spotColor = SanXNeonGreen)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(SanXNeonGreen, Color(0xFF00C868))
                        )
                    )
                    .clickable(onClick = onCreateClick),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Create",
                    tint = SanXBlack,
                    modifier = Modifier.size(28.dp)
                )
            }

            // Ideas
            BottomNavItem(
                iconSelected = Icons.Filled.Lightbulb,
                iconUnselected = Icons.Outlined.Lightbulb,
                label = LocalStrings.current.navIdeas,
                isSelected = currentRoute == "ideas",
                onClick = { onNavigate("ideas") }
            )

            // Settings
            BottomNavItem(
                iconSelected = Icons.Filled.Settings,
                iconUnselected = Icons.Outlined.Settings,
                label = LocalStrings.current.navSettings,
                isSelected = currentRoute == "settings",
                onClick = { onNavigate("settings") }
            )
        }
    }
}

@Composable
private fun BottomNavItem(
    iconSelected: ImageVector,
    iconUnselected: ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = if (isSelected) iconSelected else iconUnselected,
            contentDescription = label,
            tint = if (isSelected) SanXNeonGreen else SanXTextDim,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) SanXNeonGreen else SanXTextDim
        )
    }
}
