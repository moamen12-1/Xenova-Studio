package com.example.sanxstudio.ui.projects

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.sanxstudio.data.model.ProjectStatus
import com.example.sanxstudio.ui.components.EmptyStateView
import com.example.sanxstudio.ui.components.SanXTopBar
import com.example.sanxstudio.ui.home.ProjectCardItem
import com.example.sanxstudio.ui.localization.LocalStrings
import com.example.ui.theme.SanXBlack
import com.example.ui.theme.SanXCardBorder
import com.example.ui.theme.SanXGreenDark
import com.example.ui.theme.SanXNeonGreen
import com.example.ui.theme.SanXSurface
import com.example.ui.theme.SanXSurfaceVariant
import com.example.ui.theme.SanXTextDim
import com.example.ui.theme.SanXTextMuted
import com.example.ui.theme.SanXTextWhite

@Composable
fun ProjectsScreen(
    onNavigateToNewProject: () -> Unit,
    onNavigateToProject: (Long) -> Unit,
    viewModel: ProjectsViewModel = viewModel()
) {
    val uiState by viewModel.projectsUiState.collectAsState()
    val strings = LocalStrings.current

    Scaffold(
        topBar = {
            SanXTopBar(
                title = strings.navProjects,
                actions = {
                    IconButton(
                        onClick = onNavigateToNewProject,
                        modifier = Modifier.testTag("projects_top_add_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "New Project", tint = SanXNeonGreen)
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onNavigateToNewProject,
                containerColor = SanXNeonGreen,
                contentColor = SanXBlack,
                shape = CircleShape,
                modifier = Modifier
                    .shadow(12.dp, CircleShape, ambientColor = SanXNeonGreen, spotColor = SanXNeonGreen)
                    .testTag("projects_fab_add")
            ) {
                Icon(Icons.Default.Add, contentDescription = "New Project", modifier = Modifier.size(28.dp))
            }
        },
        containerColor = SanXBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Search Bar
            OutlinedTextField(
                value = uiState.searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("projects_search_input"),
                placeholder = {
                    Text(strings.searchHint, color = SanXTextDim, fontSize = 14.sp)
                },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = null, tint = SanXTextDim)
                },
                trailingIcon = {
                    if (uiState.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.setSearchQuery("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = SanXTextDim)
                        }
                    }
                },
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = SanXNeonGreen,
                    unfocusedBorderColor = SanXCardBorder,
                    focusedContainerColor = SanXSurface,
                    unfocusedContainerColor = SanXSurface,
                    focusedTextColor = SanXTextWhite,
                    unfocusedTextColor = SanXTextWhite
                ),
                singleLine = true
            )

            // Status Filter Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    text = strings.allFilter,
                    isSelected = uiState.selectedStatus == null,
                    onClick = { viewModel.setStatusFilter(null) }
                )
                ProjectStatus.values().forEach { status ->
                    FilterChip(
                        text = status.displayName,
                        isSelected = uiState.selectedStatus == status.name,
                        onClick = { viewModel.setStatusFilter(status.name) }
                    )
                }
            }

            // Game Filter Chips (if any games exist)
            if (uiState.availableGames.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    uiState.availableGames.forEach { game ->
                        FilterChip(
                            text = game,
                            isSelected = uiState.selectedGame == game,
                            onClick = { viewModel.setGameFilter(game) },
                            accent = false
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Projects List
            if (uiState.filteredProjects.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyStateView(
                        icon = Icons.Default.Folder,
                        title = strings.noProjectsYet,
                        description = strings.createFirstProject,
                        buttonText = strings.newProject,
                        onButtonClick = onNavigateToNewProject
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(uiState.filteredProjects, key = { it.id }) { project ->
                        ProjectCardItem(
                            project = project,
                            onClick = { onNavigateToProject(project.id) },
                            onFavoriteClick = { viewModel.toggleFavorite(project) },
                            onDeleteClick = { viewModel.deleteProject(project) }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(72.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun FilterChip(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    accent: Boolean = true
) {
    val bg = if (isSelected) {
        if (accent) SanXGreenDark else SanXSurfaceVariant
    } else {
        SanXSurface
    }
    val textColor = if (isSelected) {
        if (accent) SanXNeonGreen else SanXTextWhite
    } else {
        SanXTextMuted
    }
    val borderColor = if (isSelected) {
        if (accent) SanXNeonGreen else SanXTextWhite.copy(alpha = 0.5f)
    } else {
        SanXCardBorder
    }

    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        color = bg,
        border = androidx.compose.foundation.BorderStroke(1.dp, borderColor)
    ) {
        Text(
            text = text,
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = textColor,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}
