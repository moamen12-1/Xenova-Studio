package com.example.sanxstudio.ui.projects

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults.SecondaryIndicator
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.sanxstudio.data.model.ProjectEntity
import com.example.sanxstudio.data.model.ProjectStatus
import com.example.sanxstudio.ui.components.SanXButton
import com.example.sanxstudio.ui.components.SanXCard
import com.example.sanxstudio.ui.components.SanXTopBar
import com.example.sanxstudio.ui.components.StatusBadge
import com.example.sanxstudio.ui.localization.LocalStrings
import com.example.ui.theme.SanXBlack
import com.example.ui.theme.SanXCardBorder
import com.example.ui.theme.SanXCyan
import com.example.ui.theme.SanXGold
import com.example.ui.theme.SanXNeonGreen
import com.example.ui.theme.SanXRed
import com.example.ui.theme.SanXSurface
import com.example.ui.theme.SanXSurfaceVariant
import com.example.ui.theme.SanXTextDim
import com.example.ui.theme.SanXTextMuted
import com.example.ui.theme.SanXTextWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectWorkspaceScreen(
    projectId: Long,
    onBack: () -> Unit,
    onNavigateToAiGenerator: (Long) -> Unit,
    onNavigateToScriptStudio: (Long) -> Unit,
    viewModel: ProjectsViewModel = viewModel()
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val strings = LocalStrings.current

    val projectFlow = remember(projectId) { viewModel.repository.observeProjectById(projectId) }
    val projectState by projectFlow.collectAsState(initial = null)

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var showStatusDropdown by remember { mutableStateOf(false) }

    // Editable fields bound to local state
    var projectName by remember { mutableStateOf("") }
    var projectGame by remember { mutableStateOf("") }
    var projectStatus by remember { mutableStateOf(ProjectStatus.IDEA.name) }
    var hookText by remember { mutableStateOf("") }
    var ideaText by remember { mutableStateOf("") }
    var scriptText by remember { mutableStateOf("") }
    var titleText by remember { mutableStateOf("") }
    var descriptionText by remember { mutableStateOf("") }
    var thumbnailConceptText by remember { mutableStateOf("") }
    var thumbnailPromptText by remember { mutableStateOf("") }
    var hashtagsText by remember { mutableStateOf("") }
    var keywordsText by remember { mutableStateOf("") }
    var callToActionText by remember { mutableStateOf("") }
    var notesText by remember { mutableStateOf("") }

    // Synchronize initial state once loaded
    LaunchedEffect(projectState) {
        projectState?.let { p ->
            projectName = p.name
            projectGame = p.game
            projectStatus = p.status
            hookText = p.hook
            ideaText = p.idea
            scriptText = p.script
            titleText = p.title
            descriptionText = p.description
            thumbnailConceptText = p.thumbnailConcept
            thumbnailPromptText = p.thumbnailPrompt
            hashtagsText = p.hashtags
            keywordsText = p.keywords
            callToActionText = p.callToAction
            notesText = p.notes
        }
    }

    fun saveCurrentChanges() {
        projectState?.let { p ->
            val updated = p.copy(
                name = projectName,
                game = projectGame,
                status = projectStatus,
                hook = hookText,
                idea = ideaText,
                script = scriptText,
                title = titleText,
                description = descriptionText,
                thumbnailConcept = thumbnailConceptText,
                thumbnailPrompt = thumbnailPromptText,
                hashtags = hashtagsText,
                keywords = keywordsText,
                callToAction = callToActionText,
                notes = notesText
            )
            viewModel.updateProject(updated) {
                Toast.makeText(context, strings.changesSaved, Toast.LENGTH_SHORT).show()
            }
        }
    }

    val tabs = listOf(
        strings.tabOverview,
        strings.tabIdea,
        strings.tabScript,
        strings.tabTitle,
        strings.tabDescription,
        strings.tabThumbnail,
        strings.tabHashtags,
        strings.tabKeywords,
        strings.tabNotes
    )

    if (projectState == null) {
        Scaffold(containerColor = SanXBlack) { padding ->
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = SanXNeonGreen)
            }
        }
        return
    }

    val currentProject = projectState!!

    Scaffold(
        topBar = {
            SanXTopBar(
                title = projectName.ifEmpty { "Workspace" },
                showBack = true,
                onBackClick = {
                    saveCurrentChanges()
                    onBack()
                },
                actions = {
                    IconButton(onClick = { viewModel.toggleFavorite(currentProject) }) {
                        Icon(
                            imageVector = if (currentProject.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = "Favorite",
                            tint = if (currentProject.isFavorite) SanXGold else SanXTextDim
                        )
                    }
                    IconButton(onClick = { viewModel.exportProjectTxt(context, currentProject) }) {
                        Icon(Icons.Default.Share, contentDescription = "Export", tint = SanXNeonGreen)
                    }
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = SanXRed)
                    }
                }
            )
        },
        bottomBar = {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = SanXSurface,
                border = BorderStroke(1.dp, SanXCardBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Quick Status selector
                    Box {
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(SanXSurfaceVariant)
                                .clickable { showStatusDropdown = true }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "${strings.statusLabel}: ", fontSize = 12.sp, color = SanXTextMuted)
                            StatusBadge(status = projectStatus)
                        }

                        DropdownMenu(
                            expanded = showStatusDropdown,
                            onDismissRequest = { showStatusDropdown = false }
                        ) {
                            ProjectStatus.values().forEach { st ->
                                DropdownMenuItem(
                                    text = { Text(st.displayName, color = SanXTextWhite) },
                                    onClick = {
                                        projectStatus = st.name
                                        showStatusDropdown = false
                                        saveCurrentChanges()
                                    }
                                )
                            }
                        }
                    }

                    SanXButton(
                        text = strings.saveChanges,
                        onClick = { saveCurrentChanges() },
                        icon = Icons.Default.Save,
                        modifier = Modifier.testTag("workspace_save_button")
                    )
                }
            }
        },
        containerColor = SanXBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Scrollable Tabs
            ScrollableTabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = SanXSurface,
                contentColor = SanXNeonGreen,
                edgePadding = 12.dp,
                indicator = { tabPositions ->
                    if (selectedTabIndex < tabPositions.size) {
                        SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                            color = SanXNeonGreen
                        )
                    }
                }
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 13.sp,
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Medium,
                                color = if (selectedTabIndex == index) SanXNeonGreen else SanXTextMuted
                            )
                        }
                    )
                }
            }

            // Tab Content
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                when (selectedTabIndex) {
                    0 -> {
                        // 1. Overview Tab
                        SanXCard(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("Project Information", fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 16.sp)

                                OutlinedTextField(
                                    value = projectName,
                                    onValueChange = { projectName = it },
                                    label = { Text(strings.projectNameLabel) },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = SanXNeonGreen,
                                        unfocusedBorderColor = SanXCardBorder,
                                        focusedTextColor = SanXTextWhite,
                                        unfocusedTextColor = SanXTextWhite
                                    )
                                )

                                OutlinedTextField(
                                    value = projectGame,
                                    onValueChange = { projectGame = it },
                                    label = { Text(strings.gameLabel) },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = SanXNeonGreen,
                                        unfocusedBorderColor = SanXCardBorder,
                                        focusedTextColor = SanXTextWhite,
                                        unfocusedTextColor = SanXTextWhite
                                    )
                                )

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Platform: ${currentProject.targetPlatform}", fontSize = 13.sp, color = SanXTextMuted)
                                    Text("Format: ${currentProject.videoFormat}", fontSize = 13.sp, color = SanXCyan)
                                }
                            }
                        }

                        // AI Shortcut Card
                        SanXCard(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { onNavigateToAiGenerator(currentProject.id) }
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = SanXNeonGreen, modifier = Modifier.size(28.dp))
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(strings.aiGeneratorTitle, fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 15.sp)
                                    Text("Generate or refine hook, script, thumbnail and tags with AI", color = SanXTextMuted, fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    1 -> {
                        // 2. Idea & Hook
                        WorkspaceEditorCard(
                            title = "Opening Hook (0-5s)",
                            value = hookText,
                            onValueChange = { hookText = it },
                            placeholder = "The high-impact opening line that stops the scroll...",
                            onCopy = {
                                clipboardManager.setText(AnnotatedString(hookText))
                                Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                            }
                        )

                        WorkspaceEditorCard(
                            title = strings.tabIdea,
                            value = ideaText,
                            onValueChange = { ideaText = it },
                            placeholder = "Core concept, angle, and why viewers care...",
                            onCopy = {
                                clipboardManager.setText(AnnotatedString(ideaText))
                                Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                            }
                        )
                    }

                    2 -> {
                        // 3. Script
                        WorkspaceEditorCard(
                            title = strings.tabScript,
                            value = scriptText,
                            onValueChange = { scriptText = it },
                            placeholder = "Full video script with timestamps, dialogue, and instructions...",
                            minLines = 10,
                            onCopy = {
                                clipboardManager.setText(AnnotatedString(scriptText))
                                Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                            },
                            extraAction = {
                                TextButton(onClick = { onNavigateToScriptStudio(currentProject.id) }) {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = SanXNeonGreen, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Script Studio", color = SanXNeonGreen, fontSize = 12.sp)
                                }
                            }
                        )
                    }

                    3 -> {
                        // 4. Title
                        WorkspaceEditorCard(
                            title = strings.tabTitle,
                            value = titleText,
                            onValueChange = { titleText = it },
                            placeholder = "Catchy gaming title (e.g. 5 Secret Rooms in GTA)",
                            minLines = 2,
                            onCopy = {
                                clipboardManager.setText(AnnotatedString(titleText))
                                Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                            }
                        )
                    }

                    4 -> {
                        // 5. Description & CTA
                        WorkspaceEditorCard(
                            title = strings.tabDescription,
                            value = descriptionText,
                            onValueChange = { descriptionText = it },
                            placeholder = "YouTube or TikTok description with timestamps and links...",
                            minLines = 6,
                            onCopy = {
                                clipboardManager.setText(AnnotatedString(descriptionText))
                                Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                            }
                        )

                        WorkspaceEditorCard(
                            title = "Call To Action (CTA)",
                            value = callToActionText,
                            onValueChange = { callToActionText = it },
                            placeholder = "Follow for part 2, drop your favorite weapon in comments...",
                            minLines = 2,
                            onCopy = {
                                clipboardManager.setText(AnnotatedString(callToActionText))
                                Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                            }
                        )
                    }

                    5 -> {
                        // 6. Thumbnail
                        WorkspaceEditorCard(
                            title = "Thumbnail Concept & Composition",
                            value = thumbnailConceptText,
                            onValueChange = { thumbnailConceptText = it },
                            placeholder = "Composition, background, character pose, big text layout...",
                            minLines = 4,
                            onCopy = {
                                clipboardManager.setText(AnnotatedString(thumbnailConceptText))
                                Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                            }
                        )

                        WorkspaceEditorCard(
                            title = "AI Thumbnail Image Prompt",
                            value = thumbnailPromptText,
                            onValueChange = { thumbnailPromptText = it },
                            placeholder = "Midjourney/DALL-E prompt with lighting, camera angle, and aspect ratio...",
                            minLines = 4,
                            onCopy = {
                                clipboardManager.setText(AnnotatedString(thumbnailPromptText))
                                Toast.makeText(context, strings.promptCopied, Toast.LENGTH_SHORT).show()
                            }
                        )
                    }

                    6 -> {
                        // 7. Hashtags
                        WorkspaceEditorCard(
                            title = strings.tabHashtags,
                            value = hashtagsText,
                            onValueChange = { hashtagsText = it },
                            placeholder = "#GTASanAndreas #GamingShorts #Gamer",
                            minLines = 3,
                            onCopy = {
                                clipboardManager.setText(AnnotatedString(hashtagsText))
                                Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                            }
                        )
                    }

                    7 -> {
                        // 8. Keywords
                        WorkspaceEditorCard(
                            title = strings.tabKeywords,
                            value = keywordsText,
                            onValueChange = { keywordsText = it },
                            placeholder = "GTA secret motorcycle, Las Venturas map secrets, GTA 2026",
                            minLines = 3,
                            onCopy = {
                                clipboardManager.setText(AnnotatedString(keywordsText))
                                Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                            }
                        )
                    }

                    8 -> {
                        // 9. Notes
                        WorkspaceEditorCard(
                            title = strings.tabNotes,
                            value = notesText,
                            onValueChange = { notesText = it },
                            placeholder = "Filming reminders, mods used, editor cues, audio tracks...",
                            minLines = 6,
                            onCopy = {
                                clipboardManager.setText(AnnotatedString(notesText))
                                Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }

    // Delete Confirmation Dialog
    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text(strings.delete, color = SanXTextWhite, fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to delete '${currentProject.name}'? This cannot be undone.", color = SanXTextMuted) },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteProject(currentProject)
                        showDeleteDialog = false
                        onBack()
                    }
                ) {
                    Text(strings.delete, color = SanXRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text(strings.cancel, color = SanXTextWhite)
                }
            },
            containerColor = SanXSurface
        )
    }
}

@Composable
fun WorkspaceEditorCard(
    title: String,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    minLines: Int = 3,
    onCopy: () -> Unit,
    extraAction: (@Composable () -> Unit)? = null
) {
    SanXCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 14.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    extraAction?.invoke()
                    IconButton(onClick = onCopy, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = SanXNeonGreen, modifier = Modifier.size(18.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                placeholder = { Text(placeholder, color = SanXTextDim, fontSize = 13.sp) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = SanXNeonGreen,
                    unfocusedBorderColor = SanXCardBorder,
                    focusedTextColor = SanXTextWhite,
                    unfocusedTextColor = SanXTextWhite,
                    focusedContainerColor = SanXSurfaceVariant,
                    unfocusedContainerColor = SanXSurfaceVariant
                ),
                minLines = minLines
            )
        }
    }
}
