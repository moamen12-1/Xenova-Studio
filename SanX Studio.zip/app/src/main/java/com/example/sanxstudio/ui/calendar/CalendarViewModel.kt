package com.example.sanxstudio.ui.calendar

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.sanxstudio.data.db.SanXDatabase
import com.example.sanxstudio.data.model.CalendarEntryEntity
import com.example.sanxstudio.data.model.ContentType
import com.example.sanxstudio.data.model.ProjectStatus
import com.example.sanxstudio.data.notification.SanXNotificationManager
import com.example.sanxstudio.data.repository.SanXRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

class CalendarViewModel(application: Application) : AndroidViewModel(application) {
    private val database = SanXDatabase.getInstance(application)
    private val repository = SanXRepository(
        database.projectDao(),
        database.ideaDao(),
        database.scriptDao(),
        database.favoriteDao(),
        database.analyticsDao(),
        database.calendarDao()
    )
    private val notificationManager = SanXNotificationManager(application)

    val allEvents: StateFlow<List<CalendarEntryEntity>> = repository.allCalendarEntries
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        // Seed sample event if none exist
        viewModelScope.launch {
            if (repository.projectCount.first() == 0) {
                val cal = Calendar.getInstance()
                cal.add(Calendar.DAY_OF_YEAR, 2)
                repository.insertCalendarEntry(
                    CalendarEntryEntity(
                        title = "Film GTA San Andreas Secrets",
                        game = "GTA San Andreas",
                        platform = ContentType.YOUTUBE_SHORTS.name,
                        plannedDate = cal.timeInMillis,
                        status = ProjectStatus.RECORDING.name,
                        notes = "Use the jetpack code and record 60fps rooftop jump",
                        hasReminder = true
                    )
                )
            }
        }
    }

    fun addEvent(
        title: String,
        game: String,
        platform: String,
        plannedDate: Long,
        status: String,
        notes: String,
        hasReminder: Boolean
    ) {
        viewModelScope.launch {
            val event = CalendarEntryEntity(
                title = title,
                game = game,
                platform = platform,
                plannedDate = plannedDate,
                status = status,
                hasReminder = hasReminder,
                notes = notes
            )
            val id = repository.insertCalendarEntry(event)

            if (hasReminder) {
                notificationManager.sendCreatorReminder(
                    "Creator Production Alert: $title",
                    "Scheduled gaming recording for $game is set for $platform!"
                )
            }
        }
    }

    fun deleteEvent(event: CalendarEntryEntity) {
        viewModelScope.launch {
            repository.deleteCalendarEntry(event)
        }
    }
}
