package com.example.sanxstudio.ui.create

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.sanxstudio.data.model.VideoFormat
import com.example.sanxstudio.ui.components.SanXButton
import com.example.sanxstudio.ui.components.SanXCard
import com.example.sanxstudio.ui.components.SanXTopBar
import com.example.sanxstudio.ui.localization.LocalStrings
import com.example.sanxstudio.ui.projects.FilterChip
import com.example.ui.theme.SanXBlack
import com.example.ui.theme.SanXCardBorder
import com.example.ui.theme.SanXCyan
import com.example.ui.theme.SanXGold
import com.example.ui.theme.SanXGreenDark
import com.example.ui.theme.SanXNeonGreen
import com.example.ui.theme.SanXSurface
import com.example.ui.theme.SanXSurfaceVariant
import com.example.ui.theme.SanXTextDim
import com.example.ui.theme.SanXTextMuted
import com.example.ui.theme.SanXTextWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThumbnailStudioScreen(
    initialProjectId: Long? = null,
    onBack: () -> Unit,
    onNavigateToSettings: () -> Unit,
    viewModel: CreateViewModel = viewModel()
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val strings = LocalStrings.current

    var topic by remember { mutableStateOf("Secret Supercar in Abandoned Garage") }
    var game by remember { mutableStateOf("GTA San Andreas") }
    var mainSubject by remember { mutableStateOf("CJ reacting with glowing eyes next to neon purple sports car") }
    var emotion by remember { mutableStateOf("Shocked / Intense Excitement") }
    var background by remember { mutableStateOf("Dark rainy midnight alley with neon reflections") }
    var mainText by remember { mutableStateOf("IMPOSSIBLE?!") }
    var visualEffects by remember { mutableStateOf("Neon rim glow, lightning sparks, cinematic lens flare") }
    var selectedFormat by remember { mutableStateOf(VideoFormat.RATIO_16_9) }

    val formats = listOf(VideoFormat.RATIO_16_9, VideoFormat.RATIO_9_16, VideoFormat.RATIO_1_1, VideoFormat.RATIO_4_5)

    val generatedPrompt = remember(topic, game, mainSubject, emotion, background, visualEffects, selectedFormat) {
        "A hyper-realistic cinematic 3D gaming thumbnail for $game: $mainSubject with expression of $emotion, set against $background. Visual effects including $visualEffects. Dynamic Dutch camera angle, vivid complementary color grading (cyan & neon orange), high contrast, 8k resolution, rule of thirds composition, commercial gaming poster aesthetic --ar ${selectedFormat.ratio}"
    }

    Scaffold(
        topBar = {
            SanXTopBar(
                title = strings.thumbnailStudioTitle,
                showBack = true,
                onBackClick = onBack,
                onSettingsClick = onNavigateToSettings
            )
        },
        containerColor = SanXBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Aspect Ratio Canvas Preview
            SanXCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(strings.aspectPreview, fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Ratio selection chips
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        formats.forEach { fmt ->
                            FilterChip(
                                text = "${fmt.ratio} (${if (fmt == VideoFormat.RATIO_16_9) "YouTube" else if (fmt == VideoFormat.RATIO_9_16) "Shorts/TikTok" else "Feed"})",
                                isSelected = selectedFormat == fmt,
                                onClick = { selectedFormat = fmt }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Simulated Canvas Card
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(if (selectedFormat == VideoFormat.RATIO_9_16) 0.55f else 0.95f)
                            .aspectRatio(selectedFormat.widthRatio / selectedFormat.heightRatio)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(SanXGreenDark, SanXSurfaceVariant, Color(0xFF0F1E2E))
                                )
                            )
                            .border(1.5.dp, SanXNeonGreen, RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Image,
                                contentDescription = null,
                                tint = SanXNeonGreen,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = mainText.ifBlank { "TEXT OVERLAY" },
                                color = SanXGold,
                                fontWeight = FontWeight.Black,
                                fontSize = if (selectedFormat == VideoFormat.RATIO_9_16) 18.sp else 22.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = game,
                                color = SanXTextWhite,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Thumbnail Parameter Controls
            SanXCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Composition Parameters", fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 15.sp)

                    OutlinedTextField(
                        value = topic,
                        onValueChange = { topic = it },
                        label = { Text(strings.topicLabel) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SanXNeonGreen,
                            unfocusedBorderColor = SanXCardBorder,
                            focusedTextColor = SanXTextWhite,
                            unfocusedTextColor = SanXTextWhite
                        )
                    )

                    OutlinedTextField(
                        value = game,
                        onValueChange = { game = it },
                        label = { Text(strings.gameLabel) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SanXNeonGreen,
                            unfocusedBorderColor = SanXCardBorder,
                            focusedTextColor = SanXTextWhite,
                            unfocusedTextColor = SanXTextWhite
                        )
                    )

                    OutlinedTextField(
                        value = mainSubject,
                        onValueChange = { mainSubject = it },
                        label = { Text(strings.mainSubjectLabel) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SanXNeonGreen,
                            unfocusedBorderColor = SanXCardBorder,
                            focusedTextColor = SanXTextWhite,
                            unfocusedTextColor = SanXTextWhite
                        )
                    )

                    OutlinedTextField(
                        value = emotion,
                        onValueChange = { emotion = it },
                        label = { Text(strings.emotionLabel) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SanXNeonGreen,
                            unfocusedBorderColor = SanXCardBorder,
                            focusedTextColor = SanXTextWhite,
                            unfocusedTextColor = SanXTextWhite
                        )
                    )

                    OutlinedTextField(
                        value = background,
                        onValueChange = { background = it },
                        label = { Text(strings.backgroundLabel) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SanXNeonGreen,
                            unfocusedBorderColor = SanXCardBorder,
                            focusedTextColor = SanXTextWhite,
                            unfocusedTextColor = SanXTextWhite
                        )
                    )

                    OutlinedTextField(
                        value = mainText,
                        onValueChange = { mainText = it },
                        label = { Text(strings.mainTextLabel) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SanXNeonGreen,
                            unfocusedBorderColor = SanXCardBorder,
                            focusedTextColor = SanXTextWhite,
                            unfocusedTextColor = SanXTextWhite
                        )
                    )

                    OutlinedTextField(
                        value = visualEffects,
                        onValueChange = { visualEffects = it },
                        label = { Text(strings.visualEffectsLabel) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SanXNeonGreen,
                            unfocusedBorderColor = SanXCardBorder,
                            focusedTextColor = SanXTextWhite,
                            unfocusedTextColor = SanXTextWhite
                        )
                    )
                }
            }

            // Generated Image Prompt Card
            SanXCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("AI Image Generation Prompt", fontWeight = FontWeight.Bold, color = SanXNeonGreen, fontSize = 15.sp)
                        IconButton(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(generatedPrompt))
                                Toast.makeText(context, strings.promptCopied, Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = SanXNeonGreen)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = generatedPrompt,
                        color = SanXTextWhite,
                        fontSize = 13.sp,
                        lineHeight = 19.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    SanXButton(
                        text = strings.copyPrompt,
                        onClick = {
                            clipboardManager.setText(AnnotatedString(generatedPrompt))
                            Toast.makeText(context, strings.promptCopied, Toast.LENGTH_SHORT).show()
                        },
                        icon = Icons.Default.ContentCopy,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}
