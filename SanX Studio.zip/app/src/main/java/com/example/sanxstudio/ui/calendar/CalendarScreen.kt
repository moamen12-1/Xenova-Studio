package com.example.sanxstudio.ui.calendar

import android.app.DatePickerDialog
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults.SecondaryIndicator
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.sanxstudio.data.model.CalendarEntity
import com.example.sanxstudio.data.model.ContentType
import com.example.sanxstudio.data.model.ProjectStatus
import com.example.sanxstudio.ui.components.EmptyStateView
import com.example.sanxstudio.ui.components.SanXButton
import com.example.sanxstudio.ui.components.SanXCard
import com.example.sanxstudio.ui.components.SanXTopBar
import com.example.sanxstudio.ui.components.StatusBadge
import com.example.sanxstudio.ui.localization.LocalStrings
import com.example.sanxstudio.ui.projects.FilterChip
import com.example.ui.theme.SanXBlack
import com.example.ui.theme.SanXCardBorder
import com.example.ui.theme.SanXCyan
import com.example.ui.theme.SanXNeonGreen
import com.example.ui.theme.SanXRed
import com.example.ui.theme.SanXSurface
import com.example.ui.theme.SanXSurfaceVariant
import com.example.ui.theme.SanXTextDim
import com.example.ui.theme.SanXTextMuted
import com.example.ui.theme.SanXTextWhite
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun CalendarScreen(
    onBack: (() -> Unit)? = null,
    viewModel: CalendarViewModel = viewModel()
) {
    val context = LocalContext.current
    val strings = LocalStrings.current
    val events by viewModel.allEvents.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var selectedViewTab by remember { mutableIntStateOf(0) } // 0: List, 1: Weekly, 2: Monthly

    Scaffold(
        topBar = {
            SanXTopBar(
                title = strings.calendarTitle,
                showBack = onBack != null,
                onBackClick = { onBack?.invoke() }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = SanXNeonGreen,
                contentColor = SanXBlack,
                shape = CircleShape,
                modifier = Modifier.testTag("calendar_add_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Schedule Content", modifier = Modifier.size(28.dp))
            }
        },
        containerColor = SanXBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // View Mode TabRow (Monthly / Weekly / List)
            TabRow(
                selectedTabIndex = selectedViewTab,
                containerColor = SanXSurface,
                contentColor = SanXNeonGreen,
                indicator = { tabPositions ->
                    if (selectedViewTab < tabPositions.size) {
                        SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedViewTab]),
                            color = SanXNeonGreen
                        )
                    }
                }
            ) {
                listOf(strings.listView, strings.weeklyView, strings.monthlyView).forEachIndexed { index, title ->
                    Tab(
                        selected = selectedViewTab == index,
                        onClick = { selectedViewTab = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedViewTab == index) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 13.sp,
                                color = if (selectedViewTab == index) SanXNeonGreen else SanXTextMuted
                            )
                        }
                    )
                }
            }

            if (events.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyStateView(
                        icon = Icons.Default.CalendarMonth,
                        title = strings.noScheduledContent,
                        description = strings.scheduleFirstVideo,
                        buttonText = strings.scheduleContent,
                        onButtonClick = { showAddDialog = true }
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(events, key = { it.id }) { event ->
                        CalendarEventItem(
                            event = event,
                            onDelete = { viewModel.deleteEvent(event) }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(72.dp))
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddCalendarEventDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { title, game, type, date, status, notes, reminder ->
                viewModel.addEvent(title, game, type, date, status, notes, reminder)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun CalendarEventItem(
    event: CalendarEntity,
    onDelete: () -> Unit
) {
    val dateFormatted = remember(event.scheduledDate) {
        SimpleDateFormat("EEE, MMM dd, yyyy", Locale.getDefault()).format(Date(event.scheduledDate))
    }

    SanXCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = event.title,
                        fontWeight = FontWeight.Bold,
                        color = SanXTextWhite,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${event.game} • ${event.contentType}",
                        fontSize = 12.sp,
                        color = SanXTextMuted
                    )
                }

                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = SanXRed, modifier = Modifier.size(18.dp))
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusBadge(status = event.status)
                    if (event.hasReminder) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(Icons.Default.Alarm, contentDescription = "Reminder", tint = SanXCyan, modifier = Modifier.size(16.dp))
                    }
                }

                Text(
                    text = dateFormatted,
                    fontSize = 11.sp,
                    color = SanXNeonGreen,
                    fontWeight = FontWeight.Medium
                )
            }

            if (event.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = event.notes,
                    fontSize = 12.sp,
                    color = SanXTextDim
                )
            }
        }
    }
}

@Composable
fun AddCalendarEventDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, Long, String, String, Boolean) -> Unit
) {
    val context = LocalContext.current
    val strings = LocalStrings.current

    var title by remember { mutableStateOf("") }
    var game by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(ContentType.YOUTUBE_SHORTS.name) }
    var scheduledDate by remember { mutableLongStateOf(System.currentTimeMillis() + 86400000L) }
    var selectedStatus by remember { mutableStateOf(ProjectStatus.IDEA.name) }
    var notes by remember { mutableStateOf("") }
    var reminder by remember { mutableStateOf(true) }

    val dateStr = remember(scheduledDate) {
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(scheduledDate))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.scheduleContent, fontWeight = FontWeight.Bold, color = SanXTextWhite) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(strings.titleLabel) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SanXNeonGreen,
                        unfocusedBorderColor = SanXCardBorder,
                        focusedTextColor = SanXTextWhite,
                        unfocusedTextColor = SanXTextWhite
                    )
                )

                OutlinedTextField(
                    value = game,
                    onValueChange = { game = it },
                    label = { Text(strings.gameLabel) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SanXNeonGreen,
                        unfocusedBorderColor = SanXCardBorder,
                        focusedTextColor = SanXTextWhite,
                        unfocusedTextColor = SanXTextWhite
                    )
                )

                // Date Picker Trigger
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            val cal = Calendar.getInstance()
                            cal.timeInMillis = scheduledDate
                            DatePickerDialog(
                                context,
                                { _, y, m, d ->
                                    val newCal = Calendar.getInstance()
                                    newCal.set(y, m, d, 14, 0)
                                    scheduledDate = newCal.timeInMillis
                                },
                                cal.get(Calendar.YEAR),
                                cal.get(Calendar.MONTH),
                                cal.get(Calendar.DAY_OF_MONTH)
                            ).show()
                        },
                    color = SanXSurfaceVariant,
                    border = BorderStroke(1.dp, SanXCardBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Date: $dateStr", color = SanXTextWhite, fontSize = 13.sp)
                        Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = SanXNeonGreen)
                    }
                }

                // Reminder Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = strings.reminderOption, color = SanXTextWhite, fontSize = 13.sp)
                    Switch(
                        checked = reminder,
                        onCheckedChange = { reminder = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = SanXBlack,
                            checkedTrackColor = SanXNeonGreen
                        )
                    )
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text(strings.notesLabel) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SanXNeonGreen,
                        unfocusedBorderColor = SanXCardBorder,
                        focusedTextColor = SanXTextWhite,
                        unfocusedTextColor = SanXTextWhite
                    )
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (title.isNotBlank()) {
                        onConfirm(title, if (game.isBlank()) "General Gaming" else game, selectedType, scheduledDate, selectedStatus, notes, reminder)
                    }
                }
            ) {
                Text(strings.saveChanges, color = SanXNeonGreen, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancel, color = SanXTextMuted)
            }
        },
        containerColor = SanXSurface
    )
}
