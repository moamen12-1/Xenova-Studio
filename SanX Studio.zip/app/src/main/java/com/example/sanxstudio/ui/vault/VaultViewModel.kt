package com.example.sanxstudio.ui.vault

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.sanxstudio.data.db.SanXDatabase
import com.example.sanxstudio.data.export.SanXExporter
import com.example.sanxstudio.data.model.FavoriteEntity
import com.example.sanxstudio.data.model.FavoriteType
import com.example.sanxstudio.data.repository.SanXRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class VaultUiState(
    val items: List<FavoriteEntity> = emptyList(),
    val filteredItems: List<FavoriteEntity> = emptyList(),
    val selectedCategory: String? = null,
    val searchQuery: String = ""
)

class VaultViewModel(application: Application) : AndroidViewModel(application) {
    private val database = SanXDatabase.getInstance(application)
    private val repository = SanXRepository(
        database.projectDao(),
        database.ideaDao(),
        database.scriptDao(),
        database.favoriteDao(),
        database.analyticsDao(),
        database.calendarDao()
    )

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow<String?>(null)
    val selectedCategory = _selectedCategory.asStateFlow()

    val uiState: StateFlow<VaultUiState> = combine(
        repository.allFavorites,
        _searchQuery,
        _selectedCategory
    ) { favs, query, cat ->
        val filtered = favs.filter { f ->
            val matchesQuery = query.isBlank() ||
                    f.title.contains(query, ignoreCase = true) ||
                    f.content.contains(query, ignoreCase = true) ||
                    f.subtitle.contains(query, ignoreCase = true)

            val matchesCat = cat == null || f.type == cat

            matchesQuery && matchesCat
        }

        VaultUiState(
            items = favs,
            filteredItems = filtered,
            selectedCategory = cat,
            searchQuery = query
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = VaultUiState()
    )

    init {
        // Seed default saved item if empty
        viewModelScope.launch {
            if (repository.projectCount.first() == 0) {
                repository.insertFavorite(
                    FavoriteEntity(
                        type = FavoriteType.HOOK.name,
                        title = "99% of GTA players never unlocked this weapon...",
                        subtitle = "GTA San Andreas Hook",
                        content = "Stop scrolling. If you've been playing GTA San Andreas for years, you probably missed this secret military weapon hidden inside..."
                    )
                )
            }
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setCategory(category: String?) {
        _selectedCategory.value = if (_selectedCategory.value == category) null else category
    }

    fun updateFavorite(favorite: FavoriteEntity) {
        viewModelScope.launch {
            repository.updateFavorite(favorite)
        }
    }

    fun deleteFavorite(favorite: FavoriteEntity) {
        viewModelScope.launch {
            repository.deleteFavorite(favorite)
        }
    }

    fun exportVault(context: Context) {
        val list = uiState.value.items
        val sb = StringBuilder()
        sb.append("SANX STUDIO - CONTENT VAULT EXPORT\n")
        sb.append("Generated on: ${java.util.Date()}\n\n")
        list.forEach { item ->
            sb.append("=== [${item.type}] ${item.title} ===\n")
            if (item.subtitle.isNotBlank()) sb.append("Category/Game: ${item.subtitle}\n")
            sb.append("${item.content}\n\n")
        }
        SanXExporter.shareText(context, "SanX Studio Content Vault", sb.toString())
    }
}
