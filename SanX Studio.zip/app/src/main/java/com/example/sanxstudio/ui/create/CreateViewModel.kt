package com.example.sanxstudio.ui.create

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.sanxstudio.data.ai.AiContentService
import com.example.sanxstudio.data.ai.AiResult
import com.example.sanxstudio.data.ai.FullContentResult
import com.example.sanxstudio.data.ai.HashtagsResult
import com.example.sanxstudio.data.ai.KeywordsResult
import com.example.sanxstudio.data.ai.SanXAiContentServiceImpl
import com.example.sanxstudio.data.ai.ScriptResult
import com.example.sanxstudio.data.ai.TitleOption
import com.example.sanxstudio.data.db.SanXDatabase
import com.example.sanxstudio.data.model.FavoriteEntity
import com.example.sanxstudio.data.model.FavoriteType
import com.example.sanxstudio.data.model.ProjectEntity
import com.example.sanxstudio.data.model.ScriptEntity
import com.example.sanxstudio.data.repository.PreferencesRepository
import com.example.sanxstudio.data.repository.SanXRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface GeneratorState<out T> {
    object Idle : GeneratorState<Nothing>
    object Loading : GeneratorState<Nothing>
    data class Success<T>(val data: T) : GeneratorState<T>
    data class NotConfigured(val message: String) : GeneratorState<Nothing>
    data class Error(val message: String) : GeneratorState<Nothing>
}

class CreateViewModel(application: Application) : AndroidViewModel(application) {
    val database = SanXDatabase.getInstance(application)
    val preferencesRepository = PreferencesRepository(application)
    val repository = SanXRepository(
        database.projectDao(),
        database.ideaDao(),
        database.scriptDao(),
        database.favoriteDao(),
        database.analyticsDao(),
        database.calendarDao()
    )

    private val aiService: AiContentService = SanXAiContentServiceImpl(preferencesRepository)

    // Full Content State
    private val _fullContentState = MutableStateFlow<GeneratorState<FullContentResult>>(GeneratorState.Idle)
    val fullContentState: StateFlow<GeneratorState<FullContentResult>> = _fullContentState.asStateFlow()

    // Script State
    private val _scriptState = MutableStateFlow<GeneratorState<ScriptResult>>(GeneratorState.Idle)
    val scriptState: StateFlow<GeneratorState<ScriptResult>> = _scriptState.asStateFlow()

    // Title State
    private val _titleState = MutableStateFlow<GeneratorState<List<TitleOption>>>(GeneratorState.Idle)
    val titleState: StateFlow<GeneratorState<List<TitleOption>>> = _titleState.asStateFlow()

    // Hashtags State
    private val _hashtagState = MutableStateFlow<GeneratorState<HashtagsResult>>(GeneratorState.Idle)
    val hashtagState: StateFlow<GeneratorState<HashtagsResult>> = _hashtagState.asStateFlow()

    // Keywords State
    private val _keywordState = MutableStateFlow<GeneratorState<KeywordsResult>>(GeneratorState.Idle)
    val keywordState: StateFlow<GeneratorState<KeywordsResult>> = _keywordState.asStateFlow()

    fun generateFullContent(
        game: String,
        topic: String,
        tone: String,
        durationSeconds: Int,
        platform: String,
        language: String
    ) {
        viewModelScope.launch {
            _fullContentState.value = GeneratorState.Loading
            when (val res = aiService.generateFullContent(game, topic, tone, durationSeconds, platform, language)) {
                is AiResult.Success -> _fullContentState.value = GeneratorState.Success(res.data)
                is AiResult.NotConfigured -> _fullContentState.value = GeneratorState.NotConfigured(res.message)
                is AiResult.Error -> _fullContentState.value = GeneratorState.Error(res.message)
            }
        }
    }

    fun generateScript(
        topic: String,
        game: String,
        durationSeconds: Int,
        voiceStyle: String,
        tone: String,
        language: String,
        ttsFriendly: Boolean
    ) {
        viewModelScope.launch {
            _scriptState.value = GeneratorState.Loading
            when (val res = aiService.generateScript(topic, game, durationSeconds, voiceStyle, tone, language, ttsFriendly)) {
                is AiResult.Success -> _scriptState.value = GeneratorState.Success(res.data)
                is AiResult.NotConfigured -> _scriptState.value = GeneratorState.NotConfigured(res.message)
                is AiResult.Error -> _scriptState.value = GeneratorState.Error(res.message)
            }
        }
    }

    fun generateTitles(
        game: String,
        topic: String,
        category: String,
        language: String
    ) {
        viewModelScope.launch {
            _titleState.value = GeneratorState.Loading
            when (val res = aiService.generateTitles(game, topic, category, language)) {
                is AiResult.Success -> _titleState.value = GeneratorState.Success(res.data)
                is AiResult.NotConfigured -> _titleState.value = GeneratorState.NotConfigured(res.message)
                is AiResult.Error -> _titleState.value = GeneratorState.Error(res.message)
            }
        }
    }

    fun generateHashtags(
        game: String,
        topic: String,
        platform: String,
        language: String
    ) {
        viewModelScope.launch {
            _hashtagState.value = GeneratorState.Loading
            when (val res = aiService.generateHashtags(game, topic, platform, language)) {
                is AiResult.Success -> _hashtagState.value = GeneratorState.Success(res.data)
                is AiResult.NotConfigured -> _hashtagState.value = GeneratorState.NotConfigured(res.message)
                is AiResult.Error -> _hashtagState.value = GeneratorState.Error(res.message)
            }
        }
    }

    fun generateKeywords(
        game: String,
        topic: String,
        platform: String
    ) {
        viewModelScope.launch {
            _keywordState.value = GeneratorState.Loading
            when (val res = aiService.generateKeywords(game, topic, platform)) {
                is AiResult.Success -> _keywordState.value = GeneratorState.Success(res.data)
                is AiResult.NotConfigured -> _keywordState.value = GeneratorState.NotConfigured(res.message)
                is AiResult.Error -> _keywordState.value = GeneratorState.Error(res.message)
            }
        }
    }

    fun saveScriptToDatabase(
        title: String,
        game: String,
        topic: String,
        scriptResult: ScriptResult,
        projectId: Long? = null
    ) {
        viewModelScope.launch {
            val scriptEntity = ScriptEntity(
                projectId = projectId,
                title = title.ifBlank { "Script - $game" },
                game = game,
                topic = topic,
                hook = scriptResult.hook,
                intro = scriptResult.intro,
                mainContent = scriptResult.mainContent,
                climax = scriptResult.climax,
                ending = scriptResult.ending,
                cta = scriptResult.cta,
                isTtsFriendly = scriptResult.isTtsFriendly
            )
            repository.insertScript(scriptEntity)
        }
    }

    fun saveTitleToFavorites(title: String, category: String) {
        viewModelScope.launch {
            repository.insertFavorite(
                FavoriteEntity(
                    type = FavoriteType.TITLE.name,
                    title = title,
                    subtitle = category,
                    content = title
                )
            )
        }
    }

    fun applyFullContentToProject(projectId: Long, result: FullContentResult, onDone: () -> Unit) {
        viewModelScope.launch {
            val project = repository.getProjectById(projectId)
            if (project != null) {
                val updated = project.copy(
                    hook = result.hook,
                    idea = result.videoIdea,
                    script = result.fullScript,
                    title = result.title,
                    description = result.description,
                    hashtags = result.hashtags,
                    keywords = result.keywords,
                    thumbnailConcept = result.thumbnailConcept,
                    thumbnailPrompt = result.thumbnailPrompt,
                    callToAction = result.callToAction,
                    updatedAt = System.currentTimeMillis()
                )
                repository.updateProject(updated)
                onDone()
            }
        }
    }
}
