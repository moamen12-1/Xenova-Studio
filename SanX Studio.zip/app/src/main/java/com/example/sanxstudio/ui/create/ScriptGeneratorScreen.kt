package com.example.sanxstudio.ui.create

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.sanxstudio.data.model.ContentTone
import com.example.sanxstudio.ui.components.LoadingStateView
import com.example.sanxstudio.ui.components.SanXButton
import com.example.sanxstudio.ui.components.SanXCard
import com.example.sanxstudio.ui.components.SanXSecondaryButton
import com.example.sanxstudio.ui.components.SanXTopBar
import com.example.sanxstudio.ui.localization.LocalStrings
import com.example.sanxstudio.ui.projects.FilterChip
import com.example.ui.theme.SanXBlack
import com.example.ui.theme.SanXCardBorder
import com.example.ui.theme.SanXCyan
import com.example.ui.theme.SanXNeonGreen
import com.example.ui.theme.SanXRed
import com.example.ui.theme.SanXSurface
import com.example.ui.theme.SanXTextDim
import com.example.ui.theme.SanXTextMuted
import com.example.ui.theme.SanXTextWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScriptGeneratorScreen(
    initialProjectId: Long? = null,
    onBack: () -> Unit,
    onNavigateToSettings: () -> Unit,
    viewModel: CreateViewModel = viewModel()
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val strings = LocalStrings.current
    val state by viewModel.scriptState.collectAsState()

    var game by remember { mutableStateOf("Minecraft") }
    var topic by remember { mutableStateOf("Ancient City Warden Secret Loot") }
    var durationSeconds by remember { mutableIntStateOf(45) }
    var voiceStyle by remember { mutableStateOf("Fast & punchy") }
    var selectedTone by remember { mutableStateOf(ContentTone.ENERGETIC.name) }
    var selectedLanguage by remember { mutableStateOf("en") }
    var ttsFriendly by remember { mutableStateOf(false) }

    val durations = listOf(30, 45, 60, 90, 180)

    fun runGenerate() {
        viewModel.generateScript(
            topic = topic,
            game = game,
            durationSeconds = durationSeconds,
            voiceStyle = voiceStyle,
            tone = selectedTone,
            language = selectedLanguage,
            ttsFriendly = ttsFriendly
        )
    }

    Scaffold(
        topBar = {
            SanXTopBar(
                title = strings.scriptStudioTitle,
                showBack = true,
                onBackClick = onBack,
                onSettingsClick = onNavigateToSettings
            )
        },
        containerColor = SanXBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Inputs Card
            SanXCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Script Directives", fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 15.sp)

                    OutlinedTextField(
                        value = topic,
                        onValueChange = { topic = it },
                        label = { Text(strings.topicLabel) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SanXNeonGreen,
                            unfocusedBorderColor = SanXCardBorder,
                            focusedTextColor = SanXTextWhite,
                            unfocusedTextColor = SanXTextWhite
                        )
                    )

                    OutlinedTextField(
                        value = game,
                        onValueChange = { game = it },
                        label = { Text(strings.gameLabel) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SanXNeonGreen,
                            unfocusedBorderColor = SanXCardBorder,
                            focusedTextColor = SanXTextWhite,
                            unfocusedTextColor = SanXTextWhite
                        )
                    )

                    OutlinedTextField(
                        value = voiceStyle,
                        onValueChange = { voiceStyle = it },
                        label = { Text(strings.voiceStyleLabel) },
                        placeholder = { Text(strings.voiceStyleHint, color = SanXTextDim) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SanXNeonGreen,
                            unfocusedBorderColor = SanXCardBorder,
                            focusedTextColor = SanXTextWhite,
                            unfocusedTextColor = SanXTextWhite
                        )
                    )

                    // Tone Row
                    Column {
                        Text(strings.toneLabel, fontSize = 12.sp, color = SanXTextMuted)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            ContentTone.values().forEach { tone ->
                                FilterChip(
                                    text = tone.displayName,
                                    isSelected = selectedTone == tone.name,
                                    onClick = { selectedTone = tone.name }
                                )
                            }
                        }
                    }

                    // Duration Row
                    Column {
                        Text(strings.durationLabel, fontSize = 12.sp, color = SanXTextMuted)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            durations.forEach { dur ->
                                FilterChip(
                                    text = "${dur}s",
                                    isSelected = durationSeconds == dur,
                                    onClick = { durationSeconds = dur }
                                )
                            }
                        }
                    }

                    // TTS Friendly Mode Switch
                    SanXCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = SanXCyan)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(strings.ttsFriendlyLabel, fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 13.sp)
                                    Text(strings.ttsFriendlyDesc, color = SanXTextMuted, fontSize = 11.sp)
                                }
                            }
                            Switch(
                                checked = ttsFriendly,
                                onCheckedChange = { ttsFriendly = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = SanXBlack,
                                    checkedTrackColor = SanXNeonGreen
                                )
                            )
                        }
                    }

                    // Language Selector
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            text = "English",
                            isSelected = selectedLanguage == "en",
                            onClick = { selectedLanguage = "en" }
                        )
                        FilterChip(
                            text = "العربية (Arabic)",
                            isSelected = selectedLanguage == "ar",
                            onClick = { selectedLanguage = "ar" }
                        )
                    }

                    SanXButton(
                        text = "Generate Script",
                        onClick = { runGenerate() },
                        icon = Icons.Default.AutoAwesome,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Results
            when (val current = state) {
                is GeneratorState.Idle -> {}
                is GeneratorState.Loading -> LoadingStateView(message = "Writing professional gaming script...")
                is GeneratorState.NotConfigured -> {
                    SanXCard(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(strings.aiNotConfiguredTitle, fontWeight = FontWeight.Bold, color = SanXTextWhite)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(current.message, color = SanXTextMuted, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(14.dp))
                            SanXButton(text = strings.goToSettings, onClick = onNavigateToSettings)
                        }
                    }
                }
                is GeneratorState.Error -> {
                    SanXCard(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Script Error", color = SanXRed, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(current.message, color = SanXTextMuted, fontSize = 13.sp)
                        }
                    }
                }
                is GeneratorState.Success -> {
                    val script = current.data

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Script Breakdown", fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 16.sp)
                        Row {
                            SanXSecondaryButton(
                                text = "Copy Full",
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(script.fullText))
                                    Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                                },
                                icon = Icons.Default.ContentCopy
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            SanXButton(
                                text = "Save",
                                onClick = {
                                    viewModel.saveScriptToDatabase(topic, game, topic, script, initialProjectId)
                                    Toast.makeText(context, "Script saved to Vault!", Toast.LENGTH_SHORT).show()
                                },
                                icon = Icons.Default.Save
                            )
                        }
                    }

                    ContentSectionCard(title = strings.hookSection, content = script.hook, onCopy = {
                        clipboardManager.setText(AnnotatedString(script.hook))
                        Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                    })

                    ContentSectionCard(title = strings.introSection, content = script.intro, onCopy = {
                        clipboardManager.setText(AnnotatedString(script.intro))
                        Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                    })

                    ContentSectionCard(title = strings.mainSection, content = script.mainContent, onCopy = {
                        clipboardManager.setText(AnnotatedString(script.mainContent))
                        Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                    })

                    ContentSectionCard(title = strings.climaxSection, content = script.climax, onCopy = {
                        clipboardManager.setText(AnnotatedString(script.climax))
                        Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                    })

                    ContentSectionCard(title = strings.endingSection, content = script.ending, onCopy = {
                        clipboardManager.setText(AnnotatedString(script.ending))
                        Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                    })

                    ContentSectionCard(title = strings.ctaSection, content = script.cta, onCopy = {
                        clipboardManager.setText(AnnotatedString(script.cta))
                        Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                    })
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}
