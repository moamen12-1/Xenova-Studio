package com.example.sanxstudio.ui.search

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.sanxstudio.ui.components.EmptyStateView
import com.example.sanxstudio.ui.components.SanXTopBar
import com.example.sanxstudio.ui.home.ProjectCardItem
import com.example.sanxstudio.ui.localization.LocalStrings
import com.example.sanxstudio.ui.projects.ProjectsViewModel
import com.example.ui.theme.SanXBlack
import com.example.ui.theme.SanXCardBorder
import com.example.ui.theme.SanXNeonGreen
import com.example.ui.theme.SanXSurface
import com.example.ui.theme.SanXTextDim
import com.example.ui.theme.SanXTextMuted
import com.example.ui.theme.SanXTextWhite

@Composable
fun GlobalSearchScreen(
    onBack: () -> Unit,
    onNavigateToProject: (Long) -> Unit,
    viewModel: ProjectsViewModel = viewModel()
) {
    val strings = LocalStrings.current
    val uiState by viewModel.projectsUiState.collectAsState()

    Scaffold(
        topBar = {
            SanXTopBar(
                title = strings.searchHint,
                showBack = true,
                onBackClick = onBack
            )
        },
        containerColor = SanXBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            OutlinedTextField(
                value = uiState.searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                placeholder = { Text("Search projects, games, topics...", color = SanXTextDim) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = SanXNeonGreen) },
                trailingIcon = {
                    if (uiState.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.setSearchQuery("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = SanXTextDim)
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .testTag("global_search_input"),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = SanXNeonGreen,
                    unfocusedBorderColor = SanXCardBorder,
                    focusedTextColor = SanXTextWhite,
                    unfocusedTextColor = SanXTextWhite,
                    focusedContainerColor = SanXSurface,
                    unfocusedContainerColor = SanXSurface
                ),
                singleLine = true
            )

            if (uiState.searchQuery.isBlank()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Type keywords, game titles, or ideas to search across all projects.",
                        color = SanXTextMuted,
                        fontSize = 14.sp
                    )
                }
            } else if (uiState.filteredProjects.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyStateView(
                        icon = Icons.Default.Folder,
                        title = "No results found",
                        description = "No projects match '${uiState.searchQuery}'",
                        buttonText = null,
                        onButtonClick = {}
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Text(
                            text = "Results (${uiState.filteredProjects.size})",
                            fontWeight = FontWeight.Bold,
                            color = SanXTextWhite,
                            fontSize = 15.sp
                        )
                    }

                    items(uiState.filteredProjects, key = { it.id }) { project ->
                        ProjectCardItem(
                            project = project,
                            onClick = { onNavigateToProject(project.id) },
                            onFavoriteClick = { viewModel.toggleFavorite(project) },
                            onDeleteClick = { viewModel.deleteProject(project) }
                        )
                    }
                }
            }
        }
    }
}
