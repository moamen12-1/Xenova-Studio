package com.example.sanxstudio.ui.projects

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.sanxstudio.data.db.SanXDatabase
import com.example.sanxstudio.data.export.SanXExporter
import com.example.sanxstudio.data.model.ContentType
import com.example.sanxstudio.data.model.ProjectEntity
import com.example.sanxstudio.data.model.ProjectStatus
import com.example.sanxstudio.data.model.VideoFormat
import com.example.sanxstudio.data.repository.SanXRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ProjectsListUiState(
    val projects: List<ProjectEntity> = emptyList(),
    val filteredProjects: List<ProjectEntity> = emptyList(),
    val selectedStatus: String? = null,
    val searchQuery: String = "",
    val availableGames: List<String> = emptyList(),
    val selectedGame: String? = null,
    val isLoading: Boolean = false
)

class ProjectsViewModel(application: Application) : AndroidViewModel(application) {
    private val database = SanXDatabase.getInstance(application)
    val repository = SanXRepository(
        database.projectDao(),
        database.ideaDao(),
        database.scriptDao(),
        database.favoriteDao(),
        database.analyticsDao(),
        database.calendarDao()
    )

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedStatus = MutableStateFlow<String?>(null)
    val selectedStatus = _selectedStatus.asStateFlow()

    private val _selectedGame = MutableStateFlow<String?>(null)
    val selectedGame = _selectedGame.asStateFlow()

    val projectsUiState: StateFlow<ProjectsListUiState> = combine(
        repository.allProjects,
        _searchQuery,
        _selectedStatus,
        _selectedGame
    ) { projects, query, status, game ->
        val games = projects.map { it.game }.filter { it.isNotBlank() }.distinct()
        val filtered = projects.filter { p ->
            val matchesQuery = query.isBlank() ||
                    p.name.contains(query, ignoreCase = true) ||
                    p.game.contains(query, ignoreCase = true) ||
                    p.description.contains(query, ignoreCase = true)

            val matchesStatus = status == null || p.status == status
            val matchesGame = game == null || p.game.equals(game, ignoreCase = true)

            matchesQuery && matchesStatus && matchesGame
        }

        ProjectsListUiState(
            projects = projects,
            filteredProjects = filtered,
            selectedStatus = status,
            searchQuery = query,
            availableGames = games,
            selectedGame = game,
            isLoading = false
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = ProjectsListUiState(isLoading = true)
    )

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setStatusFilter(status: String?) {
        _selectedStatus.value = if (_selectedStatus.value == status) null else status
    }

    fun setGameFilter(game: String?) {
        _selectedGame.value = if (_selectedGame.value == game) null else game
    }

    fun toggleFavorite(project: ProjectEntity) {
        viewModelScope.launch {
            repository.toggleProjectFavorite(project)
        }
    }

    fun deleteProject(project: ProjectEntity) {
        viewModelScope.launch {
            repository.deleteProject(project)
        }
    }

    fun createProject(
        name: String,
        game: String,
        contentType: String,
        language: String,
        videoFormat: String,
        targetPlatform: String,
        description: String,
        onCreated: (Long) -> Unit
    ) {
        viewModelScope.launch {
            val project = ProjectEntity(
                name = name.trim(),
                game = game.trim(),
                contentType = contentType,
                language = language,
                videoFormat = videoFormat,
                targetPlatform = targetPlatform,
                description = description.trim(),
                status = ProjectStatus.IDEA.name
            )
            val id = repository.insertProject(project)
            onCreated(id)
        }
    }

    fun updateProject(project: ProjectEntity, onSaved: (() -> Unit)? = null) {
        viewModelScope.launch {
            repository.updateProject(project.copy(updatedAt = System.currentTimeMillis()))
            onSaved?.invoke()
        }
    }

    fun exportProjectTxt(context: Context, project: ProjectEntity) {
        val txt = SanXExporter.generateTxt(project)
        SanXExporter.shareText(context, "${project.name} - SanX Studio", txt)
    }

    fun exportProjectJson(context: Context, project: ProjectEntity) {
        val json = SanXExporter.generateJson(project)
        SanXExporter.shareText(context, "${project.name} (JSON) - SanX Studio", json)
    }
}
