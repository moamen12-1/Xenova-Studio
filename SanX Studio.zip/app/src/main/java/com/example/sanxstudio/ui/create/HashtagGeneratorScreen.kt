package com.example.sanxstudio.ui.create

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.sanxstudio.data.ai.HashtagsResult
import com.example.sanxstudio.ui.components.LoadingStateView
import com.example.sanxstudio.ui.components.SanXButton
import com.example.sanxstudio.ui.components.SanXCard
import com.example.sanxstudio.ui.components.SanXSecondaryButton
import com.example.sanxstudio.ui.components.SanXTopBar
import com.example.sanxstudio.ui.localization.LocalStrings
import com.example.sanxstudio.ui.projects.FilterChip
import com.example.ui.theme.SanXBlack
import com.example.ui.theme.SanXCardBorder
import com.example.ui.theme.SanXCyan
import com.example.ui.theme.SanXGreenDark
import com.example.ui.theme.SanXNeonGreen
import com.example.ui.theme.SanXRed
import com.example.ui.theme.SanXSurface
import com.example.ui.theme.SanXSurfaceVariant
import com.example.ui.theme.SanXTextMuted
import com.example.ui.theme.SanXTextWhite

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun HashtagGeneratorScreen(
    onBack: () -> Unit,
    onNavigateToSettings: () -> Unit,
    viewModel: CreateViewModel = viewModel()
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val strings = LocalStrings.current
    val state by viewModel.hashtagState.collectAsState()

    var game by remember { mutableStateOf("GTA San Andreas") }
    var topic by remember { mutableStateOf("Secret Supercars") }
    var selectedPlatform by remember { mutableStateOf("YouTube Shorts") }
    var selectedLanguage by remember { mutableStateOf("en") }

    val platforms = listOf("YouTube Shorts", "TikTok", "Instagram Reels", "YouTube Video")

    // Default rich fallback tags in case user wants instant offline results
    val localTags = remember(game, topic) {
        val gClean = game.replace(" ", "")
        val tClean = topic.replace(" ", "")
        HashtagsResult(
            gamingTags = listOf("#Gaming", "#Gamer", "#GamingCommunity", "#Gameplay", "#GameReview", "#GamingClips"),
            gameSpecificTags = listOf("#$gClean", "#${gClean}Gaming", "#${gClean}Secrets", "#${gClean}Tips"),
            topicSpecificTags = listOf("#$tClean", "#GamingGuide", "#SecretGamingLocations", "#EpicMoments"),
            arabicTags = listOf("#ألعاب", "#قيمرز", "#العاب_فيديو", "#قيمنق", "#شورتس_العاب"),
            englishTags = listOf("#ShortsGaming", "#ViralGaming", "#GamingTrends", "#GamingDaily")
        )
    }

    Scaffold(
        topBar = {
            SanXTopBar(
                title = strings.hashtagStudioTitle,
                showBack = true,
                onBackClick = onBack,
                onSettingsClick = onNavigateToSettings
            )
        },
        containerColor = SanXBlack
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                SanXCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Hashtag Directives", fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 15.sp)

                        OutlinedTextField(
                            value = game,
                            onValueChange = { game = it },
                            label = { Text(strings.gameLabel) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SanXNeonGreen,
                                unfocusedBorderColor = SanXCardBorder,
                                focusedTextColor = SanXTextWhite,
                                unfocusedTextColor = SanXTextWhite
                            )
                        )

                        OutlinedTextField(
                            value = topic,
                            onValueChange = { topic = it },
                            label = { Text(strings.topicLabel) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SanXNeonGreen,
                                unfocusedBorderColor = SanXCardBorder,
                                focusedTextColor = SanXTextWhite,
                                unfocusedTextColor = SanXTextWhite
                            )
                        )

                        // Platforms
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            platforms.forEach { plat ->
                                FilterChip(
                                    text = plat,
                                    isSelected = selectedPlatform == plat,
                                    onClick = { selectedPlatform = plat }
                                )
                            }
                        }

                        SanXButton(
                            text = "Generate AI Hashtags",
                            onClick = {
                                viewModel.generateHashtags(game, topic, selectedPlatform, selectedLanguage)
                            },
                            icon = Icons.Default.AutoAwesome,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // Results: Display generated if available, or local smart tags
            val activeTags = when (val s = state) {
                is GeneratorState.Success -> s.data
                else -> localTags
            }

            if (state is GeneratorState.Loading) {
                item { LoadingStateView(message = "Searching high-engagement hashtags...") }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Hashtag Categories", fontWeight = FontWeight.Bold, color = SanXTextWhite, fontSize = 16.sp)
                    SanXButton(
                        text = strings.copyAllTags,
                        onClick = {
                            clipboardManager.setText(AnnotatedString(activeTags.allFormatted))
                            Toast.makeText(context, "All hashtags copied!", Toast.LENGTH_SHORT).show()
                        },
                        icon = Icons.Default.ContentCopy
                    )
                }
            }

            // Category 1: Gaming
            item {
                HashtagCategoryCard(
                    title = "General Gaming Hashtags",
                    tags = activeTags.gamingTags,
                    onCopy = {
                        clipboardManager.setText(AnnotatedString(activeTags.gamingTags.joinToString(" ")))
                        Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                    }
                )
            }

            // Category 2: Game-Specific
            item {
                HashtagCategoryCard(
                    title = "Game-Specific Hashtags ($game)",
                    tags = activeTags.gameSpecificTags,
                    onCopy = {
                        clipboardManager.setText(AnnotatedString(activeTags.gameSpecificTags.joinToString(" ")))
                        Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                    }
                )
            }

            // Category 3: Topic-Specific
            item {
                HashtagCategoryCard(
                    title = "Topic-Specific Hashtags",
                    tags = activeTags.topicSpecificTags,
                    onCopy = {
                        clipboardManager.setText(AnnotatedString(activeTags.topicSpecificTags.joinToString(" ")))
                        Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                    }
                )
            }

            // Category 4: Arabic Hashtags
            item {
                HashtagCategoryCard(
                    title = "Arabic Gaming Hashtags (هاشتاغات عربية)",
                    tags = activeTags.arabicTags,
                    onCopy = {
                        clipboardManager.setText(AnnotatedString(activeTags.arabicTags.joinToString(" ")))
                        Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                    }
                )
            }

            // Category 5: English & Trending
            item {
                HashtagCategoryCard(
                    title = "English & Discovery Tags",
                    tags = activeTags.englishTags,
                    onCopy = {
                        clipboardManager.setText(AnnotatedString(activeTags.englishTags.joinToString(" ")))
                        Toast.makeText(context, strings.contentCopied, Toast.LENGTH_SHORT).show()
                    }
                )
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun HashtagCategoryCard(
    title: String,
    tags: List<String>,
    onCopy: () -> Unit
) {
    SanXCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, fontWeight = FontWeight.Bold, color = SanXCyan, fontSize = 14.sp)
                IconButton(onClick = onCopy, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy Category", tint = SanXNeonGreen, modifier = Modifier.size(18.dp))
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                tags.forEach { tag ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = SanXSurfaceVariant,
                        border = BorderStroke(1.dp, SanXCardBorder)
                    ) {
                        Text(
                            text = tag,
                            color = SanXTextWhite,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }
        }
    }
}
