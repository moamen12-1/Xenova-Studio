package com.example.sanxstudio.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "sanx_studio_preferences")

class PreferencesRepository(private val context: Context) {

    private object Keys {
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
        val SELECTED_LANGUAGE = stringPreferencesKey("selected_language")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val PREFERRED_CONTENT_TYPES = stringSetPreferencesKey("preferred_content_types")
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val REMINDER_HOUR = intPreferencesKey("reminder_hour")
        val REMINDER_MINUTE = intPreferencesKey("reminder_minute")
        val AI_API_KEY = stringPreferencesKey("ai_api_key")
        val AI_MODEL = stringPreferencesKey("ai_model")
    }

    val isOnboardingCompleted: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[Keys.ONBOARDING_COMPLETED] ?: false
    }

    val selectedLanguage: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[Keys.SELECTED_LANGUAGE] ?: "en"
    }

    val themeMode: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[Keys.THEME_MODE] ?: "DARK"
    }

    val preferredContentTypes: Flow<Set<String>> = context.dataStore.data.map { preferences ->
        preferences[Keys.PREFERRED_CONTENT_TYPES] ?: setOf("GTA", "Minecraft", "PC Games", "Mobile Games")
    }

    val notificationsEnabled: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[Keys.NOTIFICATIONS_ENABLED] ?: true
    }

    val reminderHour: Flow<Int> = context.dataStore.data.map { preferences ->
        preferences[Keys.REMINDER_HOUR] ?: 18
    }

    val reminderMinute: Flow<Int> = context.dataStore.data.map { preferences ->
        preferences[Keys.REMINDER_MINUTE] ?: 0
    }

    val aiApiKey: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[Keys.AI_API_KEY] ?: ""
    }

    val aiModel: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[Keys.AI_MODEL] ?: "gemini-2.5-flash"
    }

    suspend fun setOnboardingCompleted(completed: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[Keys.ONBOARDING_COMPLETED] = completed
        }
    }

    suspend fun setSelectedLanguage(lang: String) {
        context.dataStore.edit { preferences ->
            preferences[Keys.SELECTED_LANGUAGE] = lang
        }
    }

    suspend fun setThemeMode(mode: String) {
        context.dataStore.edit { preferences ->
            preferences[Keys.THEME_MODE] = mode
        }
    }

    suspend fun setPreferredContentTypes(types: Set<String>) {
        context.dataStore.edit { preferences ->
            preferences[Keys.PREFERRED_CONTENT_TYPES] = types
        }
    }

    suspend fun setNotificationsEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[Keys.NOTIFICATIONS_ENABLED] = enabled
        }
    }

    suspend fun setReminderTime(hour: Int, minute: Int) {
        context.dataStore.edit { preferences ->
            preferences[Keys.REMINDER_HOUR] = hour
            preferences[Keys.REMINDER_MINUTE] = minute
        }
    }

    suspend fun setAiApiKey(apiKey: String) {
        context.dataStore.edit { preferences ->
            preferences[Keys.AI_API_KEY] = apiKey.trim()
        }
    }

    suspend fun setAiModel(model: String) {
        context.dataStore.edit { preferences ->
            preferences[Keys.AI_MODEL] = model
        }
    }

    suspend fun clearAllData() {
        context.dataStore.edit { preferences ->
            preferences.clear()
        }
    }

    // Compatibility aliases
    val appLanguageFlow: Flow<String> get() = selectedLanguage
    val geminiApiKeyFlow: Flow<String> get() = aiApiKey
    val selectedModelFlow: Flow<String> get() = aiModel
    val reminderNotificationsEnabledFlow: Flow<Boolean> get() = notificationsEnabled
    val hasCompletedOnboardingFlow: Flow<Boolean> get() = isOnboardingCompleted

    suspend fun setAppLanguage(lang: String) = setSelectedLanguage(lang)
    suspend fun setGeminiApiKey(key: String) = setAiApiKey(key)
    suspend fun setSelectedModel(model: String) = setAiModel(model)
    suspend fun setReminderNotificationsEnabled(enabled: Boolean) = setNotificationsEnabled(enabled)
}
