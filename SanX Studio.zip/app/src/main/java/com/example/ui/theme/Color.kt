package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SanXNeonGreen = Color(0xFF00FF88)
val SanXNeonGreenHover = Color(0xFF10E778)
val SanXGreenGlow = Color(0x3300FF88)
val SanXGreenDark = Color(0xFF072615)
val SanXGreenBorder = Color(0xFF105C33)

val SanXBlack = Color(0xFF090C10)
val SanXCharcoal = Color(0xFF0E1219)
val SanXSurface = Color(0xFF141923)
val SanXSurfaceVariant = Color(0xFF1C2230)
val SanXCardBorder = Color(0xFF263042)
val SanXCardBorderGlow = Color(0x5500FF88)

val SanXTextWhite = Color(0xFFF8FAFC)
val SanXTextLight = Color(0xFFE2E8F0)
val SanXTextMuted = Color(0xFF94A3B8)
val SanXTextDim = Color(0xFF64748B)

val SanXCyan = Color(0xFF00E5FF)
val SanXPurple = Color(0xFFA855F7)
val SanXGold = Color(0xFFFFB703)
val SanXRed = Color(0xFFFF4D6D)
val SanXBlue = Color(0xFF38BDF8)

