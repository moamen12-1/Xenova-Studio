package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SanXDarkColorScheme = darkColorScheme(
    primary = SanXNeonGreen,
    onPrimary = SanXBlack,
    primaryContainer = SanXGreenDark,
    onPrimaryContainer = SanXNeonGreen,
    secondary = SanXCyan,
    onSecondary = SanXBlack,
    secondaryContainer = Color(0xFF003844),
    onSecondaryContainer = SanXCyan,
    tertiary = SanXPurple,
    onTertiary = Color.White,
    background = SanXBlack,
    onBackground = SanXTextWhite,
    surface = SanXSurface,
    onSurface = SanXTextWhite,
    surfaceVariant = SanXSurfaceVariant,
    onSurfaceVariant = SanXTextMuted,
    outline = SanXCardBorder,
    error = SanXRed,
    onError = Color.White
)

private val SanXLightColorScheme = lightColorScheme(
    primary = Color(0xFF009650),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFC7F9D6),
    onPrimaryContainer = Color(0xFF00391A),
    secondary = Color(0xFF007A8A),
    onSecondary = Color.White,
    background = Color(0xFFF8FAFC),
    onBackground = Color(0xFF0F172A),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFCBD5E1),
    error = SanXRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to dark gaming theme
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) SanXDarkColorScheme else SanXLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

