package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Shadow House: Escape", appName)
  }

  @Test
  fun `house map architecture and rooms defined`() {
    val houseMap = com.example.shadowhouse.engine3d.HouseMap()
    assert(houseMap.rooms.isNotEmpty())
    assert(houseMap.walls.isNotEmpty())
    assert(houseMap.interactiveObjects.isNotEmpty())
  }
}
